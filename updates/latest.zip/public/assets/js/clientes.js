'use strict';

const elementos = {
    nombreNegocioSuperior: document.getElementById(
        'nombreNegocioSuperior'
    ),

    estadoLicenciaSuperior: document.getElementById(
        'estadoLicenciaSuperior'
    ),

    estadoActualizacionSuperior: document.getElementById(
        'estadoActualizacionSuperior'
    ),

    avatarUsuarioLateral: document.getElementById(
        'avatarUsuarioLateral'
    ),

    nombreUsuarioLateral: document.getElementById(
        'nombreUsuarioLateral'
    ),

    rolUsuarioLateral: document.getElementById(
        'rolUsuarioLateral'
    ),

    botonCerrarSesion: document.getElementById(
        'botonCerrarSesion'
    ),

    busquedaClientes: document.getElementById(
        'busquedaClientes'
    ),

    filtroEstadoClientes: document.getElementById(
        'filtroEstadoClientes'
    ),

    filtroRegistradosSemana: document.getElementById(
        'filtroRegistradosSemana'
    ),

    botonLimpiarBusqueda: document.getElementById(
        'botonLimpiarBusqueda'
    ),

    botonNuevoCliente: document.getElementById(
        'botonNuevoCliente'
    ),

    resumenClientes: document.getElementById(
        'resumenClientes'
    ),

    cuerpoTablaClientes: document.getElementById(
        'cuerpoTablaClientes'
    ),

    mensajePaginacionClientes: document.getElementById(
        'mensajePaginacionClientes'
    ),

    paginaActualClientes: document.getElementById(
        'paginaActualClientes'
    ),

    botonPaginaAnterior: document.getElementById(
        'botonPaginaAnterior'
    ),

    botonPaginaSiguiente: document.getElementById(
        'botonPaginaSiguiente'
    ),

    modalCliente: document.getElementById(
        'modalCliente'
    ),

    fondoModalCliente: document.getElementById(
        'fondoModalCliente'
    ),

    botonCerrarPanelCliente: document.getElementById(
        'botonCerrarPanelCliente'
    ),

    botonCancelarCliente: document.getElementById(
        'botonCancelarCliente'
    ),

    etiquetaPanelCliente: document.getElementById(
        'etiquetaPanelCliente'
    ),

    tituloPanelCliente: document.getElementById(
        'tituloPanelCliente'
    ),

    formularioCliente: document.getElementById(
        'formularioCliente'
    ),

    tipoPersonaCliente: document.getElementById(
        'tipoPersonaCliente'
    ),

    etiquetaNombreCliente: document.getElementById(
        'etiquetaNombreCliente'
    ),

    nombreCliente: document.getElementById(
        'nombreCliente'
    ),

    identificacionCliente: document.getElementById(
        'identificacionCliente'
    ),

    telefonoCliente: document.getElementById(
        'telefonoCliente'
    ),

    correoCliente: document.getElementById(
        'correoCliente'
    ),

    direccionCliente: document.getElementById(
        'direccionCliente'
    ),

    notasCliente: document.getElementById(
        'notasCliente'
    ),

    detalleAuditoriaCliente: document.getElementById(
        'detalleAuditoriaCliente'
    ),

    mensajeFormularioCliente: document.getElementById(
        'mensajeFormularioCliente'
    ),

    botonGuardarCliente: document.getElementById(
        'botonGuardarCliente'
    ),

    mensajeFlotanteClientes: document.getElementById(
        'mensajeFlotanteClientes'
    )
};

const estadoVista = {
    pagina: 1,
    limite: 20,
    totalPaginas: 1,
    busqueda: '',
    estado: 'ACTIVO',
    soloSemana: false,
    clienteEditandoId: null
};

let temporizadorBusqueda = null;
let temporizadorMensaje = null;

function textoSeguro(valor) {
    return String(valor ?? '').trim();
}

function escaparTexto(valor) {
    return textoSeguro(valor);
}

function obtenerIniciales(nombreCompleto) {
    const palabras = textoSeguro(nombreCompleto)
        .split(/\s+/)
        .filter(Boolean);

    if (palabras.length === 0) {
        return 'TV';
    }

    return palabras
        .slice(0, 2)
        .map((palabra) => palabra.charAt(0))
        .join('')
        .toUpperCase();
}

function formatearRol(rol) {
    const roles = {
        PROPIETARIO: 'Propietario',
        ADMINISTRADOR: 'Administrador',
        CAJERO: 'Cajero'
    };

    return roles[rol] || 'Usuario';
}

function formatearFecha(valor) {
    const fecha = textoSeguro(valor).slice(0, 10);

    if (!/^\d{4}-\d{2}-\d{2}$/.test(fecha)) {
        return 'No disponible';
    }

    const [anio, mes, dia] = fecha.split('-');

    return `${dia}/${mes}/${anio}`;
}

function mostrarMensajeFlotante(mensaje) {
    window.clearTimeout(temporizadorMensaje);

    elementos.mensajeFlotanteClientes.textContent =
        mensaje;

    elementos.mensajeFlotanteClientes.classList.add(
        'mensaje-flotante--visible'
    );

    temporizadorMensaje = window.setTimeout(() => {
        elementos.mensajeFlotanteClientes.classList.remove(
            'mensaje-flotante--visible'
        );
    }, 3400);
}

function mostrarMensajeFormulario(
    mensaje,
    correcto = false
) {
    elementos.mensajeFormularioCliente.textContent =
        mensaje;

    elementos.mensajeFormularioCliente.classList.toggle(
        'mensaje-formulario-cliente--correcto',
        correcto
    );
}

function limpiarMensajeFormulario() {
    elementos.mensajeFormularioCliente.textContent = '';

    elementos.mensajeFormularioCliente.classList.remove(
        'mensaje-formulario-cliente--correcto'
    );
}

function crearElemento(tag, texto = '') {
    const elemento = document.createElement(tag);

    if (texto) {
        elemento.textContent = texto;
    }

    return elemento;
}

function crearCelda(texto = '') {
    const celda = document.createElement('td');

    celda.textContent = texto || '—';

    return celda;
}

function actualizarNombreCampoCliente() {
    const esJuridica =
        elementos.tipoPersonaCliente.value ===
        'JURIDICA';

    elementos.etiquetaNombreCliente.textContent =
        esJuridica
            ? 'Razón social'
            : 'Nombre completo';

    elementos.nombreCliente.placeholder = esJuridica
        ? 'Ej.: Comercial La Estrella, C.A.'
        : 'Ej.: María González';

    elementos.identificacionCliente.placeholder =
        esJuridica
            ? 'Ej.: J-12345678-9'
            : 'Ej.: V-12345678';
}

function limpiarFormularioCliente() {
    estadoVista.clienteEditandoId = null;

    elementos.formularioCliente.reset();

    elementos.tipoPersonaCliente.value = 'NATURAL';

    actualizarNombreCampoCliente();

    elementos.etiquetaPanelCliente.textContent =
        'Nuevo registro';

    elementos.tituloPanelCliente.textContent =
        'Registrar cliente';

    elementos.botonGuardarCliente.textContent =
        'Guardar cliente';

    elementos.detalleAuditoriaCliente.hidden = true;
    elementos.detalleAuditoriaCliente.textContent = '';

    limpiarMensajeFormulario();
}

function abrirPanelNuevoCliente() {
    limpiarFormularioCliente();

    elementos.modalCliente.hidden = false;

    window.setTimeout(() => {
        elementos.nombreCliente.focus();
    }, 50);
}

function cerrarPanelCliente() {
    elementos.modalCliente.hidden = true;

    limpiarMensajeFormulario();
}

function rellenarFormularioCliente(cliente) {
    estadoVista.clienteEditandoId = Number(cliente.id);

    elementos.tipoPersonaCliente.value =
        cliente.tipo_persona || 'NATURAL';

    actualizarNombreCampoCliente();

    elementos.nombreCliente.value =
        cliente.nombre_o_razon_social || '';

    elementos.identificacionCliente.value =
        cliente.identificacion || '';

    elementos.telefonoCliente.value =
        cliente.telefono || '';

    elementos.correoCliente.value =
        cliente.correo || '';

    elementos.direccionCliente.value =
        cliente.direccion || '';

    elementos.notasCliente.value =
        cliente.notas || '';

    elementos.etiquetaPanelCliente.textContent =
        'Edición de registro';

    elementos.tituloPanelCliente.textContent =
        'Editar cliente';

    elementos.botonGuardarCliente.textContent =
        'Guardar cambios';

    const creadoPor = cliente.creado_por_nombre || '—';
    const actualizadoPor =
        cliente.actualizado_por_nombre || '—';

    elementos.detalleAuditoriaCliente.textContent =
        `Creado por ${creadoPor} el ${formatearFecha(
            cliente.creado_en
        )}. Última modificación por ${actualizadoPor} el ${formatearFecha(
            cliente.actualizado_en
        )}.`;

    elementos.detalleAuditoriaCliente.hidden = false;

    elementos.modalCliente.hidden = false;
}

function crearFilaCliente(cliente) {
    const fila = document.createElement('tr');

    const celdaNombre = document.createElement('td');

    const bloqueNombre = crearElemento(
        'div'
    );

    bloqueNombre.className = 'nombre-cliente-tabla';

    const nombre = crearElemento(
        'strong',
        escaparTexto(
            cliente.nombre_o_razon_social
        )
    );

    const tipo = crearElemento(
        'span',
        cliente.tipo_persona === 'JURIDICA'
            ? 'Persona jurídica'
            : 'Persona natural'
    );

    bloqueNombre.append(nombre, tipo);
    celdaNombre.appendChild(bloqueNombre);

    const celdaIdentificacion = crearCelda(
        cliente.identificacion
    );

    const celdaContacto = document.createElement('td');

    const bloqueContacto = crearElemento('div');

    bloqueContacto.className =
        'contacto-cliente-tabla';

    const telefono = crearElemento(
        'span',
        cliente.telefono || 'Sin teléfono'
    );

    const correo = crearElemento(
        'span',
        cliente.correo || 'Sin correo'
    );

    bloqueContacto.append(telefono, correo);
    celdaContacto.appendChild(bloqueContacto);

    const celdaEstado = document.createElement('td');

    const insignia = crearElemento(
        'span',
        cliente.estado === 'ACTIVO'
            ? 'Activo'
            : 'Inactivo'
    );

    insignia.className =
        `insignia-cliente ${cliente.estado === 'ACTIVO'
            ? 'insignia-cliente--activo'
            : 'insignia-cliente--inactivo'
        }`;

    celdaEstado.appendChild(insignia);

    const celdaActualizacion = document.createElement('td');

    const bloqueActualizacion = crearElemento(
        'div'
    );

    bloqueActualizacion.className =
        'contacto-cliente-tabla';

    const quien = crearElemento(
        'span',
        cliente.actualizado_por_nombre || '—'
    );

    const cuando = crearElemento(
        'span',
        formatearFecha(cliente.actualizado_en)
    );

    bloqueActualizacion.append(quien, cuando);
    celdaActualizacion.appendChild(
        bloqueActualizacion
    );

    const celdaAcciones = document.createElement('td');

    const acciones = crearElemento('div');

    acciones.className = 'acciones-tabla';

    const botonEditar = crearElemento(
        'button',
        'Editar'
    );

    botonEditar.type = 'button';
    botonEditar.className = 'boton-accion-tabla';

    botonEditar.addEventListener('click', () => {
        cargarClienteParaEditar(cliente.id);
    });

    const botonEstado = crearElemento(
        'button',
        cliente.estado === 'ACTIVO'
            ? 'Inactivar'
            : 'Reactivar'
    );

    botonEstado.type = 'button';
    botonEstado.className =
        'boton-accion-tabla boton-accion-tabla--estado';

    botonEstado.addEventListener('click', () => {
        cambiarEstadoCliente(
            cliente.id,
            cliente.estado === 'ACTIVO'
                ? 'INACTIVO'
                : 'ACTIVO'
        );
    });

    acciones.append(botonEditar, botonEstado);

    celdaAcciones.appendChild(acciones);

    fila.append(
        celdaNombre,
        celdaIdentificacion,
        celdaContacto,
        celdaEstado,
        celdaActualizacion,
        celdaAcciones
    );

    return fila;
}

function renderizarClientes(clientes) {
    elementos.cuerpoTablaClientes.replaceChildren();

    if (!Array.isArray(clientes) || clientes.length === 0) {
        const fila = document.createElement('tr');

        const celda = document.createElement('td');

        celda.colSpan = 6;
        celda.className = 'tabla-clientes__vacio';

        celda.textContent =
            estadoVista.busqueda
                ? 'No se encontraron clientes con esta búsqueda.'
                : 'Todavía no hay clientes registrados. Use “Nuevo cliente” para crear el primero.';

        fila.appendChild(celda);

        elementos.cuerpoTablaClientes.appendChild(
            fila
        );

        return;
    }

    for (const cliente of clientes) {
        elementos.cuerpoTablaClientes.appendChild(
            crearFilaCliente(cliente)
        );
    }
}

function actualizarPaginacion(paginacion) {
    estadoVista.totalPaginas =
        Number(paginacion.totalPaginas) || 1;

    const total = Number(paginacion.total) || 0;
    const pagina = Number(paginacion.pagina) || 1;

    elementos.resumenClientes.textContent =
        total === 1
            ? '1 cliente encontrado.'
            : `${total} clientes encontrados.`;

    elementos.mensajePaginacionClientes.textContent =
        total > 0
            ? `Página ${pagina} de ${estadoVista.totalPaginas}`
            : 'Sin resultados.';

    elementos.paginaActualClientes.textContent =
        pagina;

    elementos.botonPaginaAnterior.disabled =
        pagina <= 1;

    elementos.botonPaginaSiguiente.disabled =
        pagina >= estadoVista.totalPaginas;
}

async function cargarClientes() {
    try {
        elementos.resumenClientes.textContent =
            'Consultando clientes...';

        const parametros = new URLSearchParams({
            busqueda: estadoVista.busqueda,
            estado: estadoVista.estado,
            pagina: String(estadoVista.pagina),
            limite: String(estadoVista.limite),
            soloSemana: estadoVista.soloSemana ? 'true' : 'false'
        });

        const respuesta = await fetch(
            `/api/clientes?${parametros.toString()}`,
            {
                cache: 'no-store'
            }
        );

        const resultado = await respuesta.json();

        if (!respuesta.ok || !resultado.ok) {
            throw new Error(
                resultado.mensaje ||
                'No fue posible cargar los clientes.'
            );
        }

        renderizarClientes(resultado.clientes);

        actualizarPaginacion(
            resultado.paginacion || {}
        );
    } catch (error) {
        console.error(
            'Error cargando clientes:',
            error
        );

        elementos.cuerpoTablaClientes.replaceChildren();

        const fila = document.createElement('tr');

        const celda = document.createElement('td');

        celda.colSpan = 6;
        celda.className = 'tabla-clientes__vacio';
        celda.textContent =
            error.message ||
            'No fue posible cargar los clientes.';

        fila.appendChild(celda);

        elementos.cuerpoTablaClientes.appendChild(
            fila
        );

        elementos.resumenClientes.textContent =
            'Error consultando clientes.';
    }
}

async function cargarClienteParaEditar(clienteId) {
    try {
        const respuesta = await fetch(
            `/api/clientes/${encodeURIComponent(
                clienteId
            )}`,
            {
                cache: 'no-store'
            }
        );

        const resultado = await respuesta.json();

        if (!respuesta.ok || !resultado.ok) {
            throw new Error(
                resultado.mensaje ||
                'No fue posible consultar el cliente.'
            );
        }

        rellenarFormularioCliente(resultado.cliente);
    } catch (error) {
        console.error(
            'Error consultando cliente:',
            error
        );

        mostrarMensajeFlotante(
            error.message ||
            'No fue posible abrir el cliente.'
        );
    }
}

function construirDatosCliente() {
    return {
        tipoPersona:
            elementos.tipoPersonaCliente.value,

        nombreORazonSocial: textoSeguro(
            elementos.nombreCliente.value
        ),

        identificacion: textoSeguro(
            elementos.identificacionCliente.value
        ),

        telefono: textoSeguro(
            elementos.telefonoCliente.value
        ),

        correo: textoSeguro(
            elementos.correoCliente.value
        ),

        direccion: textoSeguro(
            elementos.direccionCliente.value
        ),

        notas: textoSeguro(
            elementos.notasCliente.value
        )
    };
}

async function guardarCliente(evento) {
    evento.preventDefault();

    limpiarMensajeFormulario();

    const datos = construirDatosCliente();

    if (datos.nombreORazonSocial.length < 2) {
        mostrarMensajeFormulario(
            'Ingrese un nombre o razón social de al menos 2 caracteres.'
        );

        elementos.nombreCliente.focus();

        return;
    }

    const editando =
        Number.isInteger(
            estadoVista.clienteEditandoId
        );

    const ruta = editando
        ? `/api/clientes/${estadoVista.clienteEditandoId}`
        : '/api/clientes';

    const metodo = editando ? 'PUT' : 'POST';

    const textoOriginal =
        elementos.botonGuardarCliente.textContent;

    try {
        elementos.botonGuardarCliente.disabled = true;

        elementos.botonGuardarCliente.textContent =
            editando
                ? 'Guardando cambios...'
                : 'Registrando cliente...';

        const respuesta = await fetch(ruta, {
            method: metodo,

            headers: {
                'Content-Type':
                    'application/json'
            },

            body: JSON.stringify(datos)
        });

        const resultado = await respuesta.json();

        if (!respuesta.ok || !resultado.ok) {
            throw new Error(
                resultado.mensaje ||
                'No fue posible guardar el cliente.'
            );
        }

        mostrarMensajeFormulario(
            resultado.mensaje ||
            'Cliente guardado correctamente.',
            true
        );

        await cargarClientes();

        window.setTimeout(() => {
            cerrarPanelCliente();

            mostrarMensajeFlotante(
                resultado.mensaje ||
                'Cliente guardado correctamente.'
            );
        }, 350);
    } catch (error) {
        console.error(
            'Error guardando cliente:',
            error
        );

        mostrarMensajeFormulario(
            error.message ||
            'No fue posible guardar el cliente.'
        );
    } finally {
        elementos.botonGuardarCliente.disabled = false;

        elementos.botonGuardarCliente.textContent =
            textoOriginal;
    }
}

async function cambiarEstadoCliente(
    clienteId,
    nuevoEstado
) {
    const accion =
        nuevoEstado === 'ACTIVO'
            ? 'reactivar'
            : 'inactivar';

    const confirmado = window.confirm(
        `¿Desea ${accion} este cliente?`
    );

    if (!confirmado) {
        return;
    }

    try {
        const respuesta = await fetch(
            `/api/clientes/${encodeURIComponent(
                clienteId
            )}/estado`,
            {
                method: 'PATCH',

                headers: {
                    'Content-Type':
                        'application/json'
                },

                body: JSON.stringify({
                    estado: nuevoEstado
                })
            }
        );

        const resultado = await respuesta.json();

        if (!respuesta.ok || !resultado.ok) {
            throw new Error(
                resultado.mensaje ||
                'No fue posible cambiar el estado.'
            );
        }

        await cargarClientes();

        mostrarMensajeFlotante(
            resultado.mensaje ||
            'Estado actualizado correctamente.'
        );
    } catch (error) {
        console.error(
            'Error cambiando estado:',
            error
        );

        mostrarMensajeFlotante(
            error.message ||
            'No fue posible cambiar el estado.'
        );
    }
}

async function cargarContextoAplicacion() {
    try {
        const respuesta = await fetch(
            '/api/aplicacion/estado',
            {
                cache: 'no-store'
            }
        );

        const datos = await respuesta.json();

        if (!respuesta.ok || !datos.ok) {
            throw new Error(
                datos.mensaje ||
                'No fue posible consultar Tenvik.'
            );
        }

        const puedeUsarClientes =
            datos.licencia?.activa === true &&
            datos.negocio?.configurado === true &&
            Boolean(datos.sesion?.usuario);

        if (!puedeUsarClientes) {
            window.location.assign(
                datos.destino || '/'
            );

            return;
        }

        const usuario = datos.sesion.usuario;

        elementos.nombreNegocioSuperior.textContent =
            datos.negocio.nombreComercial ||
            'Mi negocio';

        elementos.nombreUsuarioLateral.textContent =
            usuario.nombreCompleto || 'Usuario';

        elementos.rolUsuarioLateral.textContent =
            formatearRol(usuario.rol);

        elementos.avatarUsuarioLateral.textContent =
            obtenerIniciales(usuario.nombreCompleto);

        elementos.estadoLicenciaSuperior.textContent =
            datos.licencia.estado === 'ACTIVA'
                ? 'Licencia activa'
                : 'Licencia no disponible';

        if (elementos.estadoActualizacionSuperior) {
            const disponible = Boolean(datos?.actualizacion?.disponible);
            if (disponible) {
                elementos.estadoActualizacionSuperior.hidden = false;
                elementos.estadoActualizacionSuperior.classList.add('estado-actualizacion--visible');
                elementos.estadoActualizacionSuperior.classList.remove('estado-actualizacion--oculto');
            } else {
                elementos.estadoActualizacionSuperior.hidden = true;
                elementos.estadoActualizacionSuperior.classList.add('estado-actualizacion--oculto');
                elementos.estadoActualizacionSuperior.classList.remove('estado-actualizacion--visible');
            }
        }
    } catch (error) {
        console.error(
            'Error cargando contexto:',
            error
        );

        mostrarMensajeFlotante(
            error.message ||
            'No fue posible preparar Clientes.'
        );
    }
}

async function cerrarSesion() {
    const textoOriginal =
        elementos.botonCerrarSesion.textContent;

    try {
        elementos.botonCerrarSesion.disabled = true;

        elementos.botonCerrarSesion.textContent =
            'Cerrando...';

        const respuesta = await fetch(
            '/api/autenticacion/cerrar-sesion',
            {
                method: 'POST',
                headers: {
                    'Content-Type':
                        'application/json'
                }
            }
        );

        const resultado = await respuesta.json();

        if (!respuesta.ok || !resultado.ok) {
            throw new Error(
                resultado.mensaje ||
                'No fue posible cerrar la sesión.'
            );
        }

        window.location.assign(
            resultado.redireccion || '/iniciar-sesion'
        );
    } catch (error) {
        console.error(
            'Error cerrando sesión:',
            error
        );

        mostrarMensajeFlotante(
            error.message ||
            'No fue posible cerrar la sesión.'
        );
    } finally {
        elementos.botonCerrarSesion.disabled = false;

        elementos.botonCerrarSesion.textContent =
            textoOriginal;
    }
}

function programarBusqueda() {
    window.clearTimeout(temporizadorBusqueda);

    temporizadorBusqueda = window.setTimeout(() => {
        estadoVista.busqueda = textoSeguro(
            elementos.busquedaClientes.value
        );

        estadoVista.pagina = 1;

        cargarClientes();
    }, 280);
}

function navegarModulo(modulo) {
    const rutasDisponibles = {
        'Panel principal': '/panel',
        Clientes: '/clientes',
        Inventario: '/inventario',
        Ventas: '/ventas',
        Reportes: '/reportes',
        Caja: '/caja',
        Usuarios: '/usuarios',
        Configuración: '/configuracion'
    };
    const ruta = rutasDisponibles[modulo];

    if (ruta) {
        window.location.assign(ruta);
        return;
    }

    mostrarMensajeFlotante(
        `${modulo} será construido en el siguiente bloque de Tenvik.`
    );
}

document.querySelectorAll(
    '[data-modulo]'
).forEach((elemento) => {
    elemento.addEventListener('click', () => {
        navegarModulo(
            textoSeguro(elemento.dataset.modulo)
        );
    });
});


elementos.botonNuevoCliente.addEventListener(
    'click',
    abrirPanelNuevoCliente
);

elementos.botonCerrarPanelCliente.addEventListener(
    'click',
    cerrarPanelCliente
);

elementos.botonCancelarCliente.addEventListener(
    'click',
    cerrarPanelCliente
);

elementos.fondoModalCliente.addEventListener(
    'click',
    cerrarPanelCliente
);

elementos.tipoPersonaCliente.addEventListener(
    'change',
    actualizarNombreCampoCliente
);

elementos.formularioCliente.addEventListener(
    'submit',
    guardarCliente
);

elementos.busquedaClientes.addEventListener(
    'input',
    programarBusqueda
);

elementos.filtroEstadoClientes.addEventListener(
    'change',
    () => {
        estadoVista.estado =
            elementos.filtroEstadoClientes.value;

        estadoVista.pagina = 1;

        cargarClientes();
    }
);

elementos.filtroRegistradosSemana.addEventListener(
    'change',
    () => {
        estadoVista.soloSemana =
            elementos.filtroRegistradosSemana.checked;

        estadoVista.pagina = 1;

        cargarClientes();
    }
);

elementos.botonLimpiarBusqueda.addEventListener(
    'click',
    () => {
        elementos.busquedaClientes.value = '';

        estadoVista.busqueda = '';
        estadoVista.soloSemana = false;
        elementos.filtroRegistradosSemana.checked = false;
        estadoVista.pagina = 1;

        cargarClientes();

        elementos.busquedaClientes.focus();
    }
);

elementos.botonPaginaAnterior.addEventListener(
    'click',
    () => {
        if (estadoVista.pagina <= 1) {
            return;
        }

        estadoVista.pagina -= 1;

        cargarClientes();
    }
);

elementos.botonPaginaSiguiente.addEventListener(
    'click',
    () => {
        if (
            estadoVista.pagina >=
            estadoVista.totalPaginas
        ) {
            return;
        }

        estadoVista.pagina += 1;

        cargarClientes();
    }
);

if (elementos.estadoActualizacionSuperior) {
    elementos.estadoActualizacionSuperior.addEventListener(
        'click',
        () => {
            sessionStorage.setItem(
                'tenvik.focus.actualizacion',
                'true'
            );
        }
    );
}

elementos.botonCerrarSesion.addEventListener(
    'click',
    cerrarSesion
);

document.addEventListener('keydown', (evento) => {
    if (
        evento.key === 'Escape' &&
        !elementos.modalCliente.hidden
    ) {
        cerrarPanelCliente();
    }
});

function inicializarFiltroDesdeUrl() {
    const parametros = new URLSearchParams(
        window.location.search
    );

    const soloSemana =
        parametros.get('soloSemana') === '1' ||
        parametros.get('soloSemana') === 'true';

    estadoVista.soloSemana = false;
    elementos.filtroRegistradosSemana.checked = false;

    if (soloSemana) {
        estadoVista.soloSemana = true;
        elementos.filtroRegistradosSemana.checked = true;
    }
}

async function iniciarClientes() {
    actualizarNombreCampoCliente();
    inicializarFiltroDesdeUrl();

    await cargarContextoAplicacion();

    await cargarClientes();
}

iniciarClientes();