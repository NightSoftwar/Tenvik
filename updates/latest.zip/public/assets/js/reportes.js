"use strict";

function textoSeguro(valor) {
    return String(valor ?? "").trim();
}

function navegarModulo(modulo) {
    const rutasDisponibles = {
        'Panel principal': '/panel',
        Clientes: '/clientes',
        Inventario: '/inventario',
        Ventas: '/ventas',
        Reportes: '/reportes',
        Caja: '/caja',
        Usuarios: '/usuarios',
        Configuración: '/configuracion'
    };

    const ruta = rutasDisponibles[modulo];

    if (ruta) {
        window.location.assign(ruta);
        return;
    }

    alert(`${modulo} será construido en el siguiente bloque de Tenvik.`);
}

document.querySelectorAll('[data-modulo]').forEach((elemento) => {
    elemento.addEventListener('click', () => {
        navegarModulo(textoSeguro(elemento.dataset.modulo));
    });
});

// Inicializaciones específicas de reportes se añadirán aquí.

const elementos = {
    nombreNegocioSuperior: document.getElementById('nombreNegocioSuperior'),
    estadoLicenciaSuperior: document.getElementById('estadoLicenciaSuperior'),
    estadoActualizacionSuperior: document.getElementById('estadoActualizacionSuperior'),
    avatarUsuarioLateral: document.getElementById('avatarUsuarioLateral'),
    nombreUsuarioLateral: document.getElementById('nombreUsuarioLateral'),
    rolUsuarioLateral: document.getElementById('rolUsuarioLateral'),
    botonCerrarSesion: document.getElementById('botonCerrarSesion')
};

function obtenerIniciales(nombreCompleto) {
    const palabras = textoSeguro(nombreCompleto).split(/\s+/).filter(Boolean);
    if (palabras.length === 0) return 'TV';
    return palabras.slice(0, 2).map(p => p.charAt(0)).join('').toUpperCase();
}

function formatearRol(rol) {
    const roles = { PROPIETARIO: 'Propietario', ADMINISTRADOR: 'Administrador', CAJERO: 'Cajero' };
    return roles[rol] || 'Usuario';
}

async function cargarContextoAplicacion() {
    try {
        const respuesta = await fetch('/api/aplicacion/estado', { cache: 'no-store', credentials: 'same-origin' });
        const datos = await respuesta.json();

        if (!respuesta.ok || !datos.ok) {
            throw new Error(datos.mensaje || 'No fue posible consultar Tenvik.');
        }

        const usuario = datos.sesion?.usuario || {};

        elementos.nombreNegocioSuperior && (elementos.nombreNegocioSuperior.textContent = datos.negocio?.nombreComercial || 'Mi negocio');
        elementos.nombreUsuarioLateral && (elementos.nombreUsuarioLateral.textContent = usuario.nombreCompleto || 'Usuario');
        elementos.rolUsuarioLateral && (elementos.rolUsuarioLateral.textContent = formatearRol(usuario.rol));
        elementos.avatarUsuarioLateral && (elementos.avatarUsuarioLateral.textContent = obtenerIniciales(usuario.nombreCompleto));

        if (elementos.estadoLicenciaSuperior) {
            const licenciaActiva = datos.licencia?.activa === true && datos.licencia?.estado === 'ACTIVA';
            elementos.estadoLicenciaSuperior.textContent = licenciaActiva ? 'Licencia activa' : 'Licencia no disponible';
        }

        if (elementos.estadoActualizacionSuperior) {
            const disponible = Boolean(datos?.actualizacion?.disponible);
            if (disponible) {
                elementos.estadoActualizacionSuperior.hidden = false;
                elementos.estadoActualizacionSuperior.classList.add('estado-actualizacion--visible');
                elementos.estadoActualizacionSuperior.classList.remove('estado-actualizacion--oculto');
            } else {
                elementos.estadoActualizacionSuperior.hidden = true;
                elementos.estadoActualizacionSuperior.classList.add('estado-actualizacion--oculto');
                elementos.estadoActualizacionSuperior.classList.remove('estado-actualizacion--visible');
            }
        }
    } catch (error) {
        console.error('Error cargando contexto de reportes:', error);
        if (elementos.estadoLicenciaSuperior) {
            elementos.estadoLicenciaSuperior.textContent = 'No fue posible consultar la licencia.';
        }
    }
}

if (elementos.estadoActualizacionSuperior) {
    elementos.estadoActualizacionSuperior.addEventListener('click', () => {
        sessionStorage.setItem('tenvik.focus.actualizacion', 'true');
    });
}

if (elementos.botonCerrarSesion) {
    elementos.botonCerrarSesion.addEventListener('click', async () => {
        try {
            elementos.botonCerrarSesion.disabled = true;
            elementos.botonCerrarSesion.textContent = 'Cerrando...';
            const resp = await fetch('/api/autenticacion/cerrar-sesion', { method: 'POST', credentials: 'same-origin' });
            const resultado = await resp.json();
            window.location.assign(resultado.redireccion || '/iniciar-sesion');
        } catch (e) {
            console.error('Error cerrando sesión:', e);
        } finally {
            elementos.botonCerrarSesion.disabled = false;
        }
    });
}

// Cargar contexto al iniciar
cargarContextoAplicacion();

/* =========================================================
   LÓGICA DE PESTAÑAS, FILTROS, GRÁFICOS Y EXPORT
   ========================================================= */

const estado = {
    tab: 'ventas',
    filtroRango: 'mes',
    filtroSucursal: 'todas',
    desde: null,
    hasta: null,
    datosVentas: []
};

// Elementos UI específicos
const ui = {
    filtroRango: document.getElementById('filtroRangoFechas'),
    filtroSucursal: document.getElementById('filtroSucursal'),
    rangoPersonalizado: document.getElementById('rangoPersonalizado'),
    fechaDesde: document.getElementById('fechaDesde'),
    fechaHasta: document.getElementById('fechaHasta'),
    aplicarRangoPersonalizado: document.getElementById('aplicarRangoPersonalizado'),
    pestanas: Array.from(document.querySelectorAll('.pestana')),
    tabContenedores: {
        resumen: document.getElementById('tab-resumen'),
        ventas: document.getElementById('tab-ventas'),
        inventario: document.getElementById('tab-inventario'),
        caja: document.getElementById('tab-caja')
    },
    kpiUnidades: document.getElementById('kpiUnidades'),
    kpiIngreso: document.getElementById('kpiIngreso'),
    kpiTicket: document.getElementById('kpiTicket'),
    ventasChartCanvas: document.getElementById('ventasChart'),
    ventasTabla: document.querySelector('#ventasTabla tbody'),
    ventasProductoTabla: document.querySelector('#ventasProductoTabla tbody'),
    exportCsvVentas: document.getElementById('exportCsvVentas'),
    exportXlsxVentas: document.getElementById('exportXlsxVentas')
};

// Elementos modal Ventas Productos
const uiModal = {
    botonVentasProductos: document.getElementById('botonVentasProductos'),
    modal: document.getElementById('modalVentasProductos'),
    fondoModal: document.getElementById('fondoModalVentasProductos'),
    botonCerrarModal: document.getElementById('botonCerrarModalVentasProductos'),
    modalContenido: document.getElementById('modalVentasProductosContenido')
};

let ventasChart = null;
let modalChart = null;

// Renderizar contenido dinámico dentro del modal de Ventas Productos
function renderModalVentasProductosContenido() {
    if (!uiModal.modalContenido) return;

    uiModal.modalContenido.innerHTML = `
        <div class="modal-ventas-productos__wrapper">
            <div class="modal-ventas-productos__left">
                <div class="filtro-periodo">
                    <label><input type="radio" name="periodoReporte" value="diario" checked> Diario</label>
                    <label><input type="radio" name="periodoReporte" value="semanal"> Semanal</label>
                    <label><input type="radio" name="periodoReporte" value="mensual"> Mensual</label>
                </div>

                <div class="filtro-fechas">
                    <input type="date" id="modalFechaDesde">
                    <input type="date" id="modalFechaHasta">
                    <button id="modalAplicarFechas">Aplicar</button>
                </div>

                <div class="buscador-reporte">
                    <input type="search" id="modalSearch" placeholder="Buscar por nombre, código interno o código de barras...">
                    <button id="modalLimpiarSearch">Limpiar</button>
                </div>

                <div class="reporte-acciones" style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                    <label style="display:flex; align-items:center; gap:8px; font-size:0.92rem; color:#374151;">
                        Ver
                        <select id="modalCantidadProductos" aria-label="Cantidad de productos a mostrar">
                            <option value="10">10</option>
                            <option value="20">20</option>
                            <option value="30">30</option>
                            <option value="50">50</option>
                        </select>
                        <span>productos</span>
                    </label>
                    <button id="modalExportXlsx">Exportar XLSX</button>
                    <button id="modalExportPdf">Exportar PDF</button>
                    <button id="modalOrdenToggle">Mostrar: Más vendidos</button>
                </div>

                <div class="tabla-ventas-productos__scroll">
                    <table class="tabla-reporte" id="tablaVentasProductos">
                        <thead>
                            <tr><th>Producto</th><th>Código</th><th>Unidades</th><th>Ingreso</th><th>%</th></tr>
                        </thead>
                        <tbody id="cuerpoTablaVentasProductos"></tbody>
                    </table>
                </div>
            </div>

            <div class="modal-ventas-productos__right">
                <div class="reportes-resumen-periodo">
                    <div class="resumen-periodo__titulo" id="resumenPeriodoTitulo">Periodo</div>
                    <div class="resumen-periodo__monto" id="resumenPeriodoValor">$ 0.00</div>
                </div>

                <div class="reportes-area-grafico">
                    <canvas id="chartVentasProductos" style="max-height:60vh; width:100%;"></canvas>
                </div>
            </div>
        </div>
    `;

    // Añadir handlers
    const btnAplicar = document.getElementById('modalAplicarFechas');
    const inputDesde = document.getElementById('modalFechaDesde');
    const inputHasta = document.getElementById('modalFechaHasta');
    const search = document.getElementById('modalSearch');
    const limpiar = document.getElementById('modalLimpiarSearch');
    const cantidadSelect = document.getElementById('modalCantidadProductos');
    const exportXlsxBtn = document.getElementById('modalExportXlsx');
    const exportPdfBtn = document.getElementById('modalExportPdf');
    const ordenToggle = document.getElementById('modalOrdenToggle');

    // estado local de modal
    estado.modal = estado.modal || {
        periodo: 'diario',
        desde: null,
        hasta: null,
        search: '',
        ordenAsc: false,
        cantidad: 10
    };

    if (cantidadSelect) {
        cantidadSelect.value = String(estado.modal.cantidad || 10);
        cantidadSelect.addEventListener('change', () => {
            estado.modal.cantidad = Number(cantidadSelect.value) || 10;
            actualizarDatosModal();
        });
    }

    // period radio
    document.getElementsByName('periodoReporte').forEach((el) => {
        el.addEventListener('change', () => {
            estado.modal.periodo = el.value;
            estado.modal.desde = null;
            estado.modal.hasta = null;
            if (inputDesde) inputDesde.value = '';
            if (inputHasta) inputHasta.value = '';
            actualizarDatosModal();
        });
    });

    if (btnAplicar) btnAplicar.addEventListener('click', () => {
        estado.modal.desde = inputDesde.value || null;
        estado.modal.hasta = inputHasta.value || null;
        actualizarDatosModal();
    });

    let debounceTimer = null;
    if (search) {
        search.addEventListener('input', () => {
            window.clearTimeout(debounceTimer);
            debounceTimer = window.setTimeout(() => {
                estado.modal.search = search.value.trim();
                actualizarDatosModal();
            }, 250);
        });
    }

    if (limpiar) {
        limpiar.addEventListener('click', () => {
            if (search) search.value = '';
            estado.modal.search = '';
            actualizarDatosModal();
        });
    }

    if (ordenToggle) {
        ordenToggle.addEventListener('click', () => {
            estado.modal.ordenAsc = !estado.modal.ordenAsc;
            ordenToggle.textContent = estado.modal.ordenAsc ? 'Mostrar: Menos vendidos' : 'Mostrar: Más vendidos';
            actualizarDatosModal();
        });
    }

    if (exportXlsxBtn) exportXlsxBtn.addEventListener('click', () => {
        const rows = generarFilasExportacionModal();
        exportXlsx(rows, 'ventas_productos_periodo');
    });

    if (exportPdfBtn) exportPdfBtn.addEventListener('click', () => {
        exportPdfModal();
    });

    // inicializar carga de datos
    actualizarDatosModal();
}

function calcularRangoSegunPeriodo(periodo) {
    const hoy = new Date();
    let desde = new Date(hoy);
    if (periodo === 'diario') {
        desde.setDate(hoy.getDate() - 1);
    } else if (periodo === 'semanal') {
        desde.setDate(hoy.getDate() - 7);
    } else {
        desde.setDate(hoy.getDate() - 30);
    }
    return { desde: desde.toISOString().slice(0,10), hasta: hoy.toISOString().slice(0,10) };
}

async function actualizarDatosModal() {
    console.debug('[reportes] actualizarDatosModal: inicio', { modal: estado.modal });
    const modalState = estado.modal || { periodo: 'diario', desde: null, hasta: null, search: '' };
    let desde = modalState.desde;
    let hasta = modalState.hasta;

    if (!desde && !hasta) {
        const rango = calcularRangoSegunPeriodo(modalState.periodo);
        desde = rango.desde;
        hasta = rango.hasta;
    }

    // Preparar params
    const params = new URLSearchParams();
    if (desde) params.append('desde', desde);
    if (hasta) params.append('hasta', hasta);
    if (modalState.search) params.append('search', modalState.search);
    params.append('orden', modalState.ordenAsc ? 'asc' : 'desc');
    params.append('limite', '500');

    try {
        console.debug('[reportes] realizando fetch a /api/reportes/ventas-productos', params.toString());
        const respuesta = await fetch('/api/reportes/ventas-productos?' + params.toString(), { cache: 'no-store', credentials: 'same-origin' });
        let datos = null;
        try { datos = await respuesta.json(); } catch (e) { datos = null; }

        if (!respuesta.ok || !datos?.ok) {
            // intentar leer detalle del cuerpo para depuración
            let texto = null;
            try { texto = await respuesta.text(); } catch (e) { texto = null; }
            console.warn('Respuesta /api/reportes/ventas-productos no OK', respuesta.status, texto, datos);
            throw new Error(datos?.mensaje || `No fue posible obtener datos de ventas por producto (status ${respuesta.status}).`);
        }

        // Intentar obtener la tasa vigente para convertir a USD cuando sea necesario
        let tasaVigente = null;
        try {
            const tasaResp = await fetch('/api/finanzas/resumen', { cache: 'no-store', credentials: 'same-origin' });
            if (tasaResp.ok) {
                const tasaJson = await tasaResp.json();
                tasaVigente = Number((tasaJson?.tasaVigente?.valor) || tasaJson?.tasaVigente?.valor || 0) || null;
            }
        } catch (e) {
            console.debug('[reportes] no se pudo obtener tasa vigente (esto es opcional):', e);
            tasaVigente = null;
        }

        const filas = (datos.rows || []).map((r) => {
            const ingresoBsRaw = Number(r.ingresoBs || 0);
            let ingresoUsdRaw = Number(r.ingresoUsd || 0);

            // Si el backend no devolvió ingresoUsd, intentar calcularlo con la tasa vigente
            if (!ingresoUsdRaw && ingresoBsRaw && tasaVigente) {
                try { ingresoUsdRaw = Number((ingresoBsRaw / tasaVigente).toFixed(2)); } catch(e) { ingresoUsdRaw = 0; }
            }

            return {
                producto: r.nombreActual || r.nombreProducto || r.producto || '',
                codigoInterno: r.codigoInternoActual || r.codigoProducto || '',
                codigoBarras: r.codigoBarras || '',
                unidades: Number(r.unidades || 0),
                ingresoBs: ingresoBsRaw,
                ingresoUsd: ingresoUsdRaw
            };
        });

        // Calcular porcentaje según ingreso en USD (más representativo para ventas)
        const totalIngresoUsd = filas.reduce((s, x) => s + Number(x.ingresoUsd || 0), 0) || 0;
        filas.forEach((r) => {
            r.pct = totalIngresoUsd ? Number(((Number(r.ingresoUsd || 0) / totalIngresoUsd) * 100).toFixed(2)) : 0;
        });
        console.debug('[reportes] filas recibidas del servidor', { count: filas.length, sample: filas.slice(0,5) });

        // Asegurar orden según preferencia (el servidor ya ordena pero aplicamos de nuevo por seguridad)
        filas.sort((a, b) => modalState.ordenAsc ? a.unidades - b.unidades : b.unidades - a.unidades);

        const topLimit = Math.max(1, Number(modalState.cantidad || 10));
        const filasVisibles = filas.slice(0, topLimit);

        renderTablaModal(filasVisibles);
        // Actualizar resumen de periodo arriba del gráfico
        try {
            const resumenTitulo = document.getElementById('resumenPeriodoTitulo');
            const resumenValor = document.getElementById('resumenPeriodoValor');
            if (resumenTitulo) {
                const periodoLabel = modalState.periodo ? modalState.periodo.toUpperCase() : 'PERIODO';
                resumenTitulo.textContent = periodoLabel === 'DIARIO' ? 'Venta total del día' : (periodoLabel === 'SEMANAL' ? 'Venta total de la semana' : (periodoLabel === 'MENSUAL' ? 'Venta total del mes' : 'Venta total'));
            }
            if (resumenValor) {
                const totalStr = (totalIngresoUsd || 0).toFixed(2);
                resumenValor.textContent = `$ ${totalStr}`;
            }
        } catch (e) {}

        renderChartModal(filas, totalIngresoUsd, modalState.periodo, desde, hasta);
    } catch (error) {
        console.error('[reportes] Error obteniendo ventas por producto desde servidor, usando mock como fallback:', error);
        // Fallback a mock si el endpoint falla
        if (!estado.datosVentas || estado.datosVentas.length === 0) {
            estado.datosVentas = generarMockVentas();
        }
        // Reusar la lógica previa para filtrar/agrupar
        const filtrados = estado.datosVentas.filter((r) => {
            const fechaTs = new Date(r.fecha).valueOf();
            const desdeTs = new Date(desde).valueOf();
            const hastaTs = new Date(hasta).valueOf() + (24*3600*1000 -1);
            if (fechaTs < desdeTs || fechaTs > hastaTs) return false;
            if (modalState.search) {
                const s = modalState.search.toLowerCase();
                return (String(r.producto).toLowerCase().includes(s) || String(r.codigoInterno || '').toLowerCase().includes(s) || String(r.codigoBarras || '').toLowerCase().includes(s));
            }
            return true;
        });

        const mapa = {};
        filtrados.forEach((r) => {
            const key = `${r.producto}||${r.codigoInterno||''}||${r.codigoBarras||''}`;
            if (!mapa[key]) mapa[key] = { producto: r.producto, codigoInterno: r.codigoInterno||'', codigoBarras: r.codigoBarras||'', unidades: 0, ingreso: 0 };
            mapa[key].unidades += Number(r.unidades || 0);
            mapa[key].ingreso += Number(r.ingreso || 0);
        });

        const rows = Object.values(mapa);
        const totalIngreso = rows.reduce((s, x) => s + Number(x.ingreso || 0), 0) || 0;
        rows.forEach((r) => { r.pct = totalIngreso ? Number(((Number(r.ingreso || 0) / totalIngreso) * 100).toFixed(2)) : 0; });
        rows.sort((a,b) => modalState.ordenAsc ? a.unidades - b.unidades : b.unidades - a.unidades);

        const topLimit = Math.max(1, Number(modalState.cantidad || 10));
        const rowsVisibles = rows.slice(0, topLimit);
        renderTablaModal(rowsVisibles);
        renderChartModal(rows, totalIngreso, modalState.periodo, desde, hasta);
    }
}

function renderTablaModal(rows) {
    const cuerpo = document.getElementById('cuerpoTablaVentasProductos');
    if (!cuerpo) return;
    cuerpo.innerHTML = '';
    rows.forEach((r) => {
        const tr = document.createElement('tr');
        const ingresoUsd = typeof r.ingresoUsd !== 'undefined' ? Number(r.ingresoUsd).toFixed(2) : (typeof r.ingreso !== 'undefined' ? Number(r.ingreso).toFixed(2) : '0.00');
        tr.innerHTML = `<td>${r.producto}</td><td>${r.codigoInterno || r.codigoBarras || ''}</td><td>${r.unidades}</td><td>$ ${ingresoUsd}</td><td>${r.pct}%</td>`;
        cuerpo.appendChild(tr);
    });
}

function renderChartModal(rows) {
    const canvas = document.getElementById('chartVentasProductos');
    if (!canvas || !canvas.getContext) return;

    const topLimit = Math.max(1, Number((estado.modal && estado.modal.cantidad) || 10));
    const sorted = rows.slice().sort((a,b) => (b.ingresoUsd || 0) - (a.ingresoUsd || 0));
    const top = sorted.slice(0, topLimit);
    const others = sorted.slice(topLimit);
    const othersSum = others.reduce((s,x) => s + Number(x.ingresoUsd || 0), 0);

    const labels = top.map(r => r.producto).concat(others.length ? ['Otros'] : []);
    const data = top.map(r => Number(r.ingresoUsd || 0)).concat(others.length ? [othersSum] : []);
    const colors = labels.map((_, i) => `hsl(${(i*47)%360} 70% 50%)`);

    if (typeof Chart === 'undefined') {
        // Mostrar aviso de que la librería Chart.js no está disponible
        const parent = canvas.parentElement;
        if (parent) {
            parent.innerHTML = '<div style="padding:18px; color:#6b7280;">La gráfica no está disponible porque la librería Chart.js no se cargó (bloqueada por el navegador). Puede usar la tabla o exportar los datos.</div>';
        }
        return;
    }

    if (modalChart) {
        try { modalChart.destroy(); } catch(e){}
        modalChart = null;
    }

    const ctx = canvas.getContext('2d');
    try {
        modalChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels,
                datasets: [{
                    data,
                    backgroundColor: colors,
                    borderColor: '#ffffff',
                    borderWidth: 0,
                    hoverOffset: 0,
                    spacing: 0,
                    borderRadius: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '60%',
                layout: { padding: { top: 8, bottom: 8, left: 8, right: 8 } },
                animation: { duration: 600, easing: 'easeOutCubic' },
                plugins: {
                    legend: {
                        position: 'bottom',
                        align: 'center',
                        labels: {
                            boxWidth: 14,
                            boxHeight: 14,
                            usePointStyle: true,
                            pointStyle: 'circle',
                            padding: 16,
                            color: '#374151',
                            font: { weight: '600' }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = Number(context.parsed || 0);
                                const total = context.dataset.data.reduce((s,v) => s + Number(v || 0), 0) || 1;
                                const pct = Number(((value/total)*100).toFixed(2));
                                return `${label}: $ ${value.toFixed(2)} · ${pct}%`;
                            }
                        }
                    }
                }
            }
        });

        // Actualizar resumen arriba del gráfico (si existe)
        try {
            const resumenTitulo = document.getElementById('resumenPeriodoTitulo');
            const resumenValor = document.getElementById('resumenPeriodoValor');
            if (resumenTitulo && resumenValor) {
                // Si rows tienen periodo disponible, se actualiza fuera de esta función
            }
        } catch (e) {}

    } catch (e) {
        console.warn('No se pudo renderizar modalChart:', e);
    }
}

function generarFilasExportacionModal() {
    const cuerpo = document.getElementById('cuerpoTablaVentasProductos');
    if (!cuerpo) return [];
    const filas = [];
    Array.from(cuerpo.querySelectorAll('tr')).forEach((tr) => {
        const tds = tr.querySelectorAll('td');
        // Extraer número del campo ingreso (puede llevar $ y/o espacios)
        const ingresoTexto = tds[3].textContent || '';
        const ingresoNumero = Number(ingresoTexto.replace(/[^0-9\.,-]+/g, '').replace(/,/g, '.')) || 0;
        filas.push({ producto: tds[0].textContent, codigo: tds[1].textContent, unidades: Number(tds[2].textContent), ingresoUsd: ingresoNumero, porcentaje: tds[4].textContent });
    });
    return filas;
}

function parseFechaLocal(fechaStr) {
    if (!fechaStr || String(fechaStr).trim() === '') return null;
    const valor = String(fechaStr).trim();
    const partes = valor.split('-');
    if (partes.length === 3 && partes[0].length === 4) {
        const [anio, mes, dia] = partes.map(Number);
        if (!Number.isNaN(anio) && !Number.isNaN(mes) && !Number.isNaN(dia)) {
            return new Date(anio, mes - 1, dia);
        }
    }

    const fecha = new Date(valor);
    if (Number.isNaN(fecha.getTime())) return null;
    return fecha;
}

function formatearFechaPdf(fechaStr) {
    const fecha = parseFechaLocal(fechaStr);
    if (!fecha) return !fechaStr || String(fechaStr).trim() === '' ? 'Sin filtro' : String(fechaStr);
    return fecha.toLocaleDateString('es-VE', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

function obtenerMetaReporteModal() {
    const modalState = estado.modal || {};
    const empresa = document.getElementById('nombreNegocioSuperior')?.textContent?.trim() || 'Tenvik POS';
    const usuario = document.getElementById('nombreUsuarioLateral')?.textContent?.trim() || 'Usuario';
    const desde = formatearFechaPdf(modalState.desde || null);
    const hasta = formatearFechaPdf(modalState.hasta || null);
    const cantidad = Number(modalState.cantidad || 10);
    const orden = modalState.ordenAsc ? 'Menos vendidos' : 'Más vendidos';
    const tieneFiltro = Boolean(modalState.desde || modalState.hasta || modalState.search || Number(modalState.cantidad || 10) !== 10 || modalState.ordenAsc === true);
    const tipoReporte = tieneFiltro ? null : (modalState.periodo === 'diario' ? 'Reporte diario' : (modalState.periodo === 'semanal' ? 'Reporte semanal' : 'Reporte mensual'));

    const periodoBase = modalState.periodo === 'diario'
        ? 'Diario'
        : (modalState.periodo === 'semanal' ? 'Semanal' : (modalState.periodo === 'mensual' ? 'Mensual' : 'Sin filtro'));

    const periodoTexto = (() => {
        if (modalState.desde || modalState.hasta) {
            if (desde === 'Sin filtro' && hasta === 'Sin filtro') return periodoBase;
            if (desde === 'Sin filtro') return hasta;
            if (hasta === 'Sin filtro') return desde;
            return `${desde} - ${hasta}`;
        }
        return periodoBase;
    })();

    return {
        empresa,
        usuario,
        tipoReporte,
        desde,
        hasta,
        periodoTexto,
        periodoBase,
        cantidad,
        orden,
        fechaGeneracion: new Date().toLocaleString('es-VE', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        })
    };
}

async function obtenerLogoPdfBase64() {
    try {
        const response = await fetch('/favicon.ico', { cache: 'no-store', credentials: 'same-origin' });
        if (!response.ok) return null;

        const blob = await response.blob();
        const bitmap = await createImageBitmap(blob);
        const canvas = document.createElement('canvas');
        canvas.width = bitmap.width;
        canvas.height = bitmap.height;

        const ctx = canvas.getContext('2d');
        if (!ctx) return null;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(bitmap, 0, 0);

        return canvas.toDataURL('image/png');
    } catch (e) {
        return null;
    }
}

async function exportPdfModal() {
    const tablaFilas = generarFilasExportacionModal();
    if (!tablaFilas || tablaFilas.length === 0) {
        alert('No hay datos para exportar en PDF.');
        return;
    }

    if (typeof window.jspdf === 'undefined' || !window.jspdf?.jsPDF) {
        alert('La librería de PDF no está disponible. Se usará la vista de impresión como respaldo.');

        const canvas = document.getElementById('chartVentasProductos');
        const img = canvas ? canvas.toDataURL('image/png') : null;
        const meta = obtenerMetaReporteModal();

        let html = `<html><head><title>Reporte ventas por producto</title><style>body{font-family:Arial,sans-serif;margin:24px;color:#111827;} h1{margin:0 0 8px;} .meta{font-size:12px;line-height:1.5;margin-bottom:18px;} table{width:100%;border-collapse:collapse;margin-top:12px;} th,td{border:1px solid #d1d5db;padding:8px 10px;text-align:left;font-size:12px;} th{background:#f3f4f6;} img{max-width:100%;height:auto;display:block;margin:12px 0;}</style></head><body>`;
        html += `<h1>Reporte de ventas por producto</h1>`;
        html += `<div class="meta"><strong>Empresa:</strong> ${meta.empresa}<br><strong>Usuario:</strong> ${meta.usuario}<br><strong>Tipo:</strong> ${meta.tipoReporte}<br><strong>Periodo:</strong> ${meta.desde} - ${meta.hasta}<br><strong>Filtro:</strong> ${meta.search}<br><strong>Generado:</strong> ${meta.fechaGeneracion}</div>`;
        if (img) html += `<img src="${img}" alt="Gráfico del reporte"/>`;
        html += `<table><thead><tr><th>Producto</th><th>Código</th><th>Unidades</th><th>Ingreso (USD)</th><th>%</th></tr></thead><tbody>`;
        tablaFilas.forEach((r) => {
            const ingresoVal = Number(r.ingresoUsd || 0);
            html += `<tr><td>${r.producto}</td><td>${r.codigo}</td><td>${r.unidades}</td><td>$ ${ingresoVal.toFixed(2)}</td><td>${r.porcentaje}</td></tr>`;
        });
        html += `</tbody></table>`;
        html += `<script>window.onload=function(){window.print(); setTimeout(()=>window.close(), 800);}</script></body></html>`;

        const w = window.open('', '_blank', 'noopener,noreferrer');
        if (!w) {
            alert('No fue posible abrir la vista de impresión (bloqueador de popups).');
            return;
        }
        w.document.open();
        w.document.write(html);
        w.document.close();
        return;
    }

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: 'portrait', unit: 'pt', format: 'a4' });
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const marginLeft = 40;
    const meta = obtenerMetaReporteModal();
    const fecha = new Date().toLocaleDateString('es-VE', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    });
    const logoDataUrl = await obtenerLogoPdfBase64();

    const colorNaranja = [251, 146, 60];
    const colorNaranjaOscuro = [234, 118, 30];
    const colorTexto = [17, 24, 39];
    const colorBorde = [226, 232, 240];
    const colorResaltado = [255, 244, 236];

    doc.setFillColor(255, 255, 255);
    doc.rect(0, 0, pageWidth, 78, 'F');

    if (logoDataUrl) {
        try {
            doc.addImage(logoDataUrl, 'PNG', 26, 14, 64, 64, undefined, 'FAST');
        } catch (e) {
            doc.setFillColor(colorNaranja[0], colorNaranja[1], colorNaranja[2]);
            doc.roundedRect(36, 18, 34, 34, 8, 8, 'F');
            doc.setTextColor(255, 255, 255);
            doc.setFont('helvetica', 'bold');
            doc.setFontSize(20);
            doc.text('T', 50, 42);
        }
    } else {
        doc.setFillColor(colorNaranja[0], colorNaranja[1], colorNaranja[2]);
        doc.roundedRect(36, 18, 34, 34, 8, 8, 'F');
        doc.setTextColor(255, 255, 255);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(20);
        doc.text('T', 50, 42);
    }

    doc.setTextColor(colorTexto[0], colorTexto[1], colorTexto[2]);
    doc.setFontSize(18);
    doc.setFont('helvetica', 'bold');
    doc.text(meta.empresa || 'Tenvik', 87, 45,);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text('Reporte de ventas por producto', 87, 58);

    doc.setTextColor(55, 65, 81);
    doc.setFontSize(10);
    doc.text(`Generado: ${meta.fechaGeneracion}`, pageWidth - 180, 35);
    if (meta.tipoReporte) {
        doc.text(`Tipo: ${meta.tipoReporte}`, pageWidth - 180, 50);
    }

    let y = 96;

    doc.setTextColor(colorTexto[0], colorTexto[1], colorTexto[2]);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text(`Periodo: ${meta.periodoTexto}`, marginLeft, y + 4);
    doc.text(`Orden: ${meta.orden}`, pageWidth - 180, y + 4);

    const columnas = ['Producto', 'Código', 'Unidades', 'Ingreso', '%'];
    const anchoCol = [200, 120, 60, 80, 45];
    const xIni = marginLeft;
    let x = xIni;
    const rowHeight = 20;

    y += 22;
    doc.setFillColor(colorResaltado[0], colorResaltado[1], colorResaltado[2]);
    doc.rect(xIni, y, pageWidth - (marginLeft * 2), rowHeight, 'F');
    doc.setDrawColor(colorBorde[0], colorBorde[1], colorBorde[2]);
    doc.setTextColor(colorTexto[0], colorTexto[1], colorTexto[2]);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    columnas.forEach((titulo, i) => {
        doc.text(titulo, x + 6, y + 13);
        x += anchoCol[i];
    });

    y += rowHeight;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);

    tablaFilas.forEach((fila, idx) => {
        if (y > pageHeight - 80) {
            doc.addPage();
            y = 52;
        }

        const ingresoVal = Number(fila.ingresoUsd || 0);
        const filaTexto = [
            String(fila.producto || '').slice(0, 28),
            String(fila.codigo || '').slice(0, 18),
            String(fila.unidades || 0),
            `$ ${ingresoVal.toFixed(2)}`,
            `${fila.porcentaje || '0.00'}%`
        ];

        x = xIni;
        const bg = idx % 2 === 0 ? [255, 255, 255] : [255, 244, 236];
        doc.setFillColor(bg[0], bg[1], bg[2]);
        doc.rect(xIni, y, pageWidth - (marginLeft * 2), rowHeight, 'F');

        filaTexto.forEach((valor, i) => {
            const texto = String(valor || '');
            const pad = i === 0 ? 6 : 5;
            doc.text(texto, x + pad, y + 12);
            x += anchoCol[i];
        });

        y += rowHeight;
    });

    doc.setDrawColor(colorBorde[0], colorBorde[1], colorBorde[2]);
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(8);
    doc.text(`Documento generado el ${fecha} • ${meta.empresa}`, marginLeft, pageHeight - 24);
    doc.save(`reporte_ventas_productos_${new Date().toISOString().slice(0,10)}.pdf`);
}

function inicializarUI() {
    // Tabs
    if (ui.pestanas && ui.pestanas.length) {
        ui.pestanas.forEach((btn) => {
            if (!btn) return;
            btn.addEventListener('click', () => {
                const tab = btn.dataset.tab;
                setTab(tab);
            });
        });
    }

    // Filtros
    if (ui.filtroRango) {
        ui.filtroRango.addEventListener('change', () => {
            estado.filtroRango = ui.filtroRango.value;
            if (ui.rangoPersonalizado) ui.rangoPersonalizado.hidden = estado.filtroRango !== 'personalizado';
            if (estado.filtroRango !== 'personalizado') {
                aplicarFiltrosYRefrescar();
            }
        });
    }

    if (ui.filtroSucursal) {
        ui.filtroSucursal.addEventListener('change', () => {
            estado.filtroSucursal = ui.filtroSucursal.value;
            aplicarFiltrosYRefrescar();
        });
    }

    if (ui.aplicarRangoPersonalizado) {
        ui.aplicarRangoPersonalizado.addEventListener('click', () => {
            estado.desde = ui.fechaDesde?.value || null;
            estado.hasta = ui.fechaHasta?.value || null;
            aplicarFiltrosYRefrescar();
        });
    }

    if (ui.exportCsvVentas) ui.exportCsvVentas.addEventListener('click', () => exportCsv(estado.datosVentas, 'ventas'));
    if (ui.exportXlsxVentas) ui.exportXlsxVentas.addEventListener('click', () => exportXlsx(estado.datosVentas, 'ventas'));
    // Nuevos botones para exportar por producto
    const exportCsvProdBtn = document.getElementById('exportCsvVentasProductos');
    const exportXlsxProdBtn = document.getElementById('exportXlsxVentasProductos');
    if (exportCsvProdBtn) exportCsvProdBtn.addEventListener('click', () => exportCsv(agregarVentasPorProducto(), 'ventas_productos'));
    if (exportXlsxProdBtn) exportXlsxProdBtn.addEventListener('click', () => exportXlsx(agregarVentasPorProducto(), 'ventas_productos'));

    // Inicializar gráfico vacío
    if (ui.ventasChartCanvas && ui.ventasChartCanvas.getContext && typeof Chart !== 'undefined') {
        try {
            const ctx = ui.ventasChartCanvas.getContext('2d');
            ventasChart = new Chart(ctx, {
                type: 'bar',
                data: { labels: [], datasets: [{ label: 'Ingreso USD', data: [], backgroundColor: '#4f46e5' }] },
                options: { responsive: true, plugins: { legend: { display: false } } }
            });
        } catch (e) {
            console.warn('Chart inicialization failed:', e);
            ventasChart = null;
        }
    } else {
        ventasChart = null;
    }

    // Vistas dentro de Ventas: por fecha / por producto
    const viewPorFechaBtn = document.getElementById('viewPorFecha');
    const viewPorProductoBtn = document.getElementById('viewPorProducto');
    const contenedorPorFecha = document.getElementById('contenedor-por-fecha');
    const contenedorPorProducto = document.getElementById('contenedor-por-producto');

    function activarVistaFecha() {
        viewPorFechaBtn.classList.add('btn-view--activo');
        viewPorProductoBtn.classList.remove('btn-view--activo');
        contenedorPorFecha.hidden = false;
        contenedorPorProducto.hidden = true;
        ui.ventasChartCanvas.parentElement.hidden = false;
    }

    function activarVistaProducto() {
        viewPorProductoBtn.classList.add('btn-view--activo');
        viewPorFechaBtn.classList.remove('btn-view--activo');
        contenedorPorFecha.hidden = true;
        contenedorPorProducto.hidden = false;
        ui.ventasChartCanvas.parentElement.hidden = true;
    }

    if (viewPorFechaBtn && viewPorProductoBtn) {
        viewPorFechaBtn.addEventListener('click', activarVistaFecha);
        viewPorProductoBtn.addEventListener('click', activarVistaProducto);
        // vista inicial
        activarVistaFecha();
    }

    // Mostrar tab inicial
    setTab(estado.tab);

    if (uiModal.botonCerrarModal) {
        uiModal.botonCerrarModal.addEventListener('click', cerrarModalVentasProductos);
    }

    // Abrir modal al pulsar el botón principal de reportes
    if (uiModal.botonVentasProductos) {
        uiModal.botonVentasProductos.addEventListener('click', () => {
            abrirModalVentasProductos();
        });
    }

    // Evitar cerrar haciendo click en el fondo: no añadimos handler que cierre
    if (uiModal.fondoModal) {
        uiModal.fondoModal.addEventListener('click', (e) => {
            // Intencionalmente vacío para impedir cierre por click en fondo
            e.stopPropagation();
        });
    }

    // No se registran atajos de teclado para abrir el modal; el botón queda sin evento según solicitud.
}

// (Navegación cliente-side removida: el botón vuelve a su estado anterior)

function setTab(tab) {
    estado.tab = tab;
    Object.keys(ui.tabContenedores).forEach((t) => {
        const el = ui.tabContenedores[t];
        if (!el) return;
        el.hidden = t !== tab;
    });

    ui.pestanas.forEach((btn) => btn.classList.toggle('boton-pestana--activo', btn.dataset.tab === tab));

    // Lazy load datos para la pestaña
    if (tab === 'ventas') {
        cargarDatosVentas();
    }
}

function aplicarFiltrosYRefrescar() {
    // Para ahora, recargamos datos mock
    if (estado.tab === 'ventas') {
        cargarDatosVentas();
    }
}

function generarMockVentas() {
    // Genera datos de los últimos 30 días por producto
    const dias = 30;
    const hoy = new Date();
    const productos = [
        { nombre: 'Harina 1kg', codigoInterno: 'PRD-HARINA-1', codigoBarras: '1234567890123' },
        { nombre: 'Azúcar 1kg', codigoInterno: 'PRD-AZUCAR-1', codigoBarras: '2234567890123' },
        { nombre: 'Aceite 1L', codigoInterno: 'PRD-ACEITE-1', codigoBarras: '3234567890123' },
        { nombre: 'Arroz 1kg', codigoInterno: 'PRD-ARROZ-1', codigoBarras: '4234567890123' },
        { nombre: 'Leche 1L', codigoInterno: 'PRD-LECHE-1', codigoBarras: '5234567890123' }
    ];
    const datos = [];

    for (let d = dias - 1; d >= 0; d--) {
        const fecha = new Date(hoy);
        fecha.setDate(hoy.getDate() - d);
        const fechaStr = fecha.toISOString().slice(0, 10);

        productos.forEach((p) => {
            const unidades = Math.floor(Math.random() * 10);
            const precio = Number((Math.random() * 5 + 1).toFixed(2));
            if (unidades === 0) return;
            datos.push({
                fecha: fechaStr,
                producto: p.nombre,
                codigoInterno: p.codigoInterno,
                codigoBarras: p.codigoBarras,
                unidades,
                ingreso: Number((unidades * precio).toFixed(2))
            });
        });
    }

    return datos;
}

async function cargarDatosVentas() {
    // En futuro: llamar a API real con filtros. Ahora usamos mock.
    estado.datosVentas = generarMockVentas();

    renderVentas();
}

function renderVentas() {
    // KPIs
    const totalUnidades = estado.datosVentas.reduce((s, r) => s + Number(r.unidades || 0), 0);
    const totalIngreso = estado.datosVentas.reduce((s, r) => s + Number(r.ingreso || 0), 0);
    const ticketPromedio = totalUnidades ? Number((totalIngreso / totalUnidades).toFixed(2)) : 0;

    if (ui.kpiUnidades) ui.kpiUnidades.textContent = String(totalUnidades);
    if (ui.kpiIngreso) ui.kpiIngreso.textContent = totalIngreso.toFixed(2);
    if (ui.kpiTicket) ui.kpiTicket.textContent = ticketPromedio.toFixed(2);

    // Gráfico: sumar ingreso por fecha
    const ingresoPorFecha = {};
    estado.datosVentas.forEach((r) => {
        ingresoPorFecha[r.fecha] = (ingresoPorFecha[r.fecha] || 0) + r.ingreso;
    });

    const labels = Object.keys(ingresoPorFecha).sort();
    const data = labels.map((l) => Number(ingresoPorFecha[l].toFixed(2)));

    if (ventasChart && ventasChart.data && ventasChart.data.datasets && ventasChart.data.datasets[0]) {
        ventasChart.data.labels = labels;
        ventasChart.data.datasets[0].data = data;
        try { ventasChart.update(); } catch (e) { console.warn('No se pudo actualizar ventasChart:', e); }
    }

    // Tabla: mostrar últimos 200 registros
    if (ui.ventasTabla) {
        ui.ventasTabla.innerHTML = '';
        const slice = estado.datosVentas.slice(-200).reverse();
        slice.forEach((r) => {
            const tr = document.createElement('tr');
            tr.innerHTML = `<td>${r.fecha}</td><td>${r.producto}</td><td>${r.unidades}</td><td>${r.ingreso.toFixed(2)}</td>`;
            ui.ventasTabla.appendChild(tr);
        });
    }

    // También renderizamos la vista por producto (agregada)
    renderVentasPorProducto();
}

function agregarVentasPorProducto() {
    const mapa = {};
    estado.datosVentas.forEach((r) => {
        const key = r.producto;
        if (!mapa[key]) mapa[key] = { producto: key, unidades: 0, ingreso: 0 };
        mapa[key].unidades += Number(r.unidades || 0);
        mapa[key].ingreso += Number(r.ingreso || 0);
    });

    const arr = Object.values(mapa);
    // Orden descendente por unidades
    arr.sort((a, b) => b.unidades - a.unidades);
    return arr;
}

function renderVentasPorProducto() {
    if (!ui.ventasProductoTabla) return;
    ui.ventasProductoTabla.innerHTML = '';
    const rows = agregarVentasPorProducto();
    rows.forEach((r) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `<td>${r.producto}</td><td>${r.unidades}</td><td>${r.ingreso.toFixed(2)}</td>`;
        ui.ventasProductoTabla.appendChild(tr);
    });
}

function exportCsv(rows, nombre) {
    if (!rows || rows.length === 0) {
        alert('No hay datos para exportar.');
        return;
    }

    const cols = Object.keys(rows[0]);
    const lines = [cols.join(',')];
    rows.forEach((r) => {
        const line = cols.map((c) => String(r[c] ?? '')).map((s) => s.includes(',') ? `"${s.replace(/"/g, '""')}"` : s).join(',');
        lines.push(line);
    });

    const csv = lines.join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${nombre || 'export'}_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
}

function exportXlsx(rows, nombre) {
    if (!rows || rows.length === 0) {
        alert('No hay datos para exportar.');
        return;
    }

    if (typeof XLSX === 'undefined') {
        // Fallback: exportar CSV si SheetJS no está disponible
        alert('Exportación XLSX no disponible (biblioteca bloqueada). Se descargará CSV en su lugar.');
        return exportCsv(rows, nombre);
    }

    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Datos');
    const ab = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([ab], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${nombre || 'export'}_${new Date().toISOString().slice(0,10)}.xlsx`;
    a.click();
    URL.revokeObjectURL(url);
}

// Inicialización final
document.addEventListener('DOMContentLoaded', () => {
    inicializarUI();

    if (sessionStorage.getItem('tenvik.focus.ventasProductos') === 'true') {
        sessionStorage.removeItem('tenvik.focus.ventasProductos');
        window.setTimeout(() => {
            abrirModalVentasProductos();
        }, 120);
    }
});

function abrirModalVentasProductos() {
    if (!uiModal.modal) return;
    uiModal.modal.hidden = false;
    // Bloquear scroll
    document.body.style.overflow = 'hidden';
    // Llevar foco a botón cerrar
    if (uiModal.botonCerrarModal) uiModal.botonCerrarModal.focus();
    try {
        renderModalVentasProductosContenido();
    } catch (e) {
        console.error('Error rendering modal content:', e);
    }
}

function cerrarModalVentasProductos() {
    if (!uiModal.modal) return;
    uiModal.modal.hidden = true;
    document.body.style.overflow = '';
    // regresar foco al botón que abrió
    if (uiModal.botonVentasProductos) uiModal.botonVentasProductos.focus();
}
