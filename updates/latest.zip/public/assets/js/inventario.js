'use strict';

/* =========================================================
   INVENTARIO BÁSICO V1
   ========================================================= */

const elementos = {
    nombreNegocioSuperior: document.getElementById(
        'nombreNegocioSuperior'
    ),

    estadoLicenciaSuperior: document.getElementById(
        'estadoLicenciaSuperior'
    ),

    estadoActualizacionSuperior: document.getElementById(
        'estadoActualizacionSuperior'
    ),

    avatarUsuarioLateral: document.getElementById(
        'avatarUsuarioLateral'
    ),

    nombreUsuarioLateral: document.getElementById(
        'nombreUsuarioLateral'
    ),

    rolUsuarioLateral: document.getElementById(
        'rolUsuarioLateral'
    ),

    botonCerrarSesion: document.getElementById(
        'botonCerrarSesion'
    ),

    botonNuevoProducto: document.getElementById(
        'botonNuevoProducto'
    ),

    botonIngresarCantidad: document.getElementById(
        'botonIngresarCantidad'
    ),

    tarjetaProductosActivos: document.getElementById(
        'tarjetaProductosActivos'
    ),

    tarjetaSinExistencia: document.getElementById(
        'tarjetaSinExistencia'
    ),

    tarjetaStockMinimo: document.getElementById(
        'tarjetaStockMinimo'
    ),

    cantidadProductosActivos: document.getElementById(
        'cantidadProductosActivos'
    ),

    cantidadProductosSinExistencia: document.getElementById(
        'cantidadProductosSinExistencia'
    ),

    cantidadProductosStockMinimo: document.getElementById(
        'cantidadProductosStockMinimo'
    ),

    busquedaProductos: document.getElementById(
        'busquedaProductos'
    ),

    filtroEstadoProductos: document.getElementById(
        'filtroEstadoProductos'
    ),

    botonLimpiarBusquedaProductos: document.getElementById(
        'botonLimpiarBusquedaProductos'
    ),

    resumenProductos: document.getElementById(
        'resumenProductos'
    ),

    cuerpoTablaProductos: document.getElementById(
        'cuerpoTablaProductos'
    ),

    mensajePaginacionProductos: document.getElementById(
        'mensajePaginacionProductos'
    ),

    paginaActualProductos: document.getElementById(
        'paginaActualProductos'
    ),

    botonPaginaAnterior: document.getElementById(
        'botonPaginaAnterior'
    ),

    botonPaginaSiguiente: document.getElementById(
        'botonPaginaSiguiente'
    ),

    modalProducto: document.getElementById(
        'modalProducto'
    ),

    fondoModalProducto: document.getElementById(
        'fondoModalProducto'
    ),

    botonCerrarPanelProducto: document.getElementById(
        'botonCerrarPanelProducto'
    ),

    botonCancelarProducto: document.getElementById(
        'botonCancelarProducto'
    ),

    etiquetaPanelProducto: document.getElementById(
        'etiquetaPanelProducto'
    ),

    tituloPanelProducto: document.getElementById(
        'tituloPanelProducto'
    ),

    formularioProducto: document.getElementById(
        'formularioProducto'
    ),

    nombreProducto: document.getElementById(
        'nombreProducto'
    ),
    bloqueTipoVentaProducto: document.getElementById(
        'bloqueTipoVentaProducto'
    ),

    tipoVentaUnidadProducto: document.getElementById(
        'tipoVentaUnidadProducto'
    ),

    tipoVentaFraccionableProducto: document.getElementById(
        'tipoVentaFraccionableProducto'
    ),

    ayudaTipoVentaProducto: document.getElementById(
        'ayudaTipoVentaProducto'
    ),
    codigoInternoProducto: document.getElementById(
        'codigoInternoProducto'
    ),

    codigoBarrasProducto: document.getElementById(
        'codigoBarrasProducto'
    ),

    precioVentaUsdProducto: document.getElementById(
        'precioVentaUsdProducto'
    ),
    etiquetaPrecioVentaUsdProducto:
        document.getElementById(
            'etiquetaPrecioVentaUsdProducto'
        ),
    stockMinimoProducto: document.getElementById(
        'stockMinimoProducto'
    ),
    etiquetaStockMinimoProducto:
        document.getElementById(
            'etiquetaStockMinimoProducto'
        ),
    bloqueExistenciaInicialProducto: document.getElementById(
        'bloqueExistenciaInicialProducto'
    ),

    existenciaInicialProducto: document.getElementById(
        'existenciaInicialProducto'
    ),
    etiquetaExistenciaInicialProducto:
        document.getElementById(
            'etiquetaExistenciaInicialProducto'
        ),

    ayudaExistenciaInicialProducto:
        document.getElementById(
            'ayudaExistenciaInicialProducto'
        ),
    aplicaIvaProducto: document.getElementById(
        'aplicaIvaProducto'
    ),

    detalleAuditoriaProducto: document.getElementById(
        'detalleAuditoriaProducto'
    ),

    mensajeFormularioProducto: document.getElementById(
        'mensajeFormularioProducto'
    ),

    botonGuardarProducto: document.getElementById(
        'botonGuardarProducto'
    ),

    mensajeFlotanteInventario: document.getElementById(
        'mensajeFlotanteInventario'
    ),

    modalMovimientoInventario: document.getElementById(
        'modalMovimientoInventario'
    ),

    fondoModalMovimientoInventario: document.getElementById(
        'fondoModalMovimientoInventario'
    ),

    botonCerrarPanelMovimientoInventario: document.getElementById(
        'botonCerrarPanelMovimientoInventario'
    ),

    botonCancelarMovimientoInventario: document.getElementById(
        'botonCancelarMovimientoInventario'
    ),

    formularioMovimientoInventario: document.getElementById(
        'formularioMovimientoInventario'
    ),

    nombreProductoMovimientoInventario: document.getElementById(
        'nombreProductoMovimientoInventario'
    ),

    codigoProductoMovimientoInventario: document.getElementById(
        'codigoProductoMovimientoInventario'
    ),

    existenciaActualMovimientoInventario: document.getElementById(
        'existenciaActualMovimientoInventario'
    ),

    modoMovimientoEntrada: document.getElementById(
        'modoMovimientoEntrada'
    ),

    modoMovimientoSalida: document.getElementById(
        'modoMovimientoSalida'
    ),

    modoMovimientoReconteo: document.getElementById(
        'modoMovimientoReconteo'
    ),

    etiquetaCantidadMovimientoInventario: document.getElementById(
        'etiquetaCantidadMovimientoInventario'
    ),

    cantidadMovimientoInventario: document.getElementById(
        'cantidadMovimientoInventario'
    ),

    ayudaCantidadMovimientoInventario: document.getElementById(
        'ayudaCantidadMovimientoInventario'
    ),

    notaMovimientoInventario: document.getElementById(
        'notaMovimientoInventario'
    ),

    mensajeFormularioMovimientoInventario: document.getElementById(
        'mensajeFormularioMovimientoInventario'
    ),

    botonGuardarMovimientoInventario: document.getElementById(
        'botonGuardarMovimientoInventario'
    ),

    modalIngresoRapidoInventario: document.getElementById(
        'modalIngresoRapidoInventario'
    ),

    fondoModalIngresoRapidoInventario: document.getElementById(
        'fondoModalIngresoRapidoInventario'
    ),

    modalConfirmarEstadoProducto: document.getElementById(
        'modalConfirmarEstadoProducto'
    ),

    fondoModalConfirmarEstadoProducto: document.getElementById(
        'fondoModalConfirmarEstadoProducto'
    ),

    botonCerrarPanelConfirmarEstadoProducto: document.getElementById(
        'botonCerrarPanelConfirmarEstadoProducto'
    ),

    botonCancelarConfirmarEstadoProducto: document.getElementById(
        'botonCancelarConfirmarEstadoProducto'
    ),

    botonConfirmarEstadoProducto: document.getElementById(
        'botonConfirmarEstadoProducto'
    ),

    etiquetaPanelConfirmarEstadoProducto: document.getElementById(
        'etiquetaPanelConfirmarEstadoProducto'
    ),

    tituloPanelConfirmarEstadoProducto: document.getElementById(
        'tituloPanelConfirmarEstadoProducto'
    ),

    nombreProductoConfirmarEstadoProducto: document.getElementById(
        'nombreProductoConfirmarEstadoProducto'
    ),

    codigoProductoConfirmarEstadoProducto: document.getElementById(
        'codigoProductoConfirmarEstadoProducto'
    ),

    textoConfirmacionEstadoProducto: document.getElementById(
        'textoConfirmacionEstadoProducto'
    ),

    botonCerrarPanelIngresoRapidoInventario: document.getElementById(
        'botonCerrarPanelIngresoRapidoInventario'
    ),

    botonCancelarIngresoRapidoInventario: document.getElementById(
        'botonCancelarIngresoRapidoInventario'
    ),

    formularioIngresoRapidoInventario: document.getElementById(
        'formularioIngresoRapidoInventario'
    ),

    codigoIngresoRapidoInventario: document.getElementById(
        'codigoIngresoRapidoInventario'
    ),

    nombreProductoIngresoRapidoInventario: document.getElementById(
        'nombreProductoIngresoRapidoInventario'
    ),

    codigoProductoIngresoRapidoInventario: document.getElementById(
        'codigoProductoIngresoRapidoInventario'
    ),

    existenciaActualIngresoRapidoInventario: document.getElementById(
        'existenciaActualIngresoRapidoInventario'
    ),

    cantidadIngresoRapidoInventario: document.getElementById(
        'cantidadIngresoRapidoInventario'
    ),

    mensajeFormularioIngresoRapidoInventario: document.getElementById(
        'mensajeFormularioIngresoRapidoInventario'
    ),

    botonGuardarIngresoRapidoInventario: document.getElementById(
        'botonGuardarIngresoRapidoInventario'
    ),

    modalBusquedaIngresoRapidoInventario: document.getElementById(
        'modalBusquedaIngresoRapidoInventario'
    ),

    fondoModalBusquedaIngresoRapidoInventario: document.getElementById(
        'fondoModalBusquedaIngresoRapidoInventario'
    ),

    botonCerrarPanelBusquedaIngresoRapidoInventario: document.getElementById(
        'botonCerrarPanelBusquedaIngresoRapidoInventario'
    ),

    botonCancelarBusquedaIngresoRapidoInventario: document.getElementById(
        'botonCancelarBusquedaIngresoRapidoInventario'
    ),

    formularioBusquedaIngresoRapidoInventario: document.getElementById(
        'formularioBusquedaIngresoRapidoInventario'
    ),

    busquedaIngresoRapidoInventario: document.getElementById(
        'busquedaIngresoRapidoInventario'
    ),

    listaResultadosBusquedaIngresoRapidoInventario: document.getElementById(
        'listaResultadosBusquedaIngresoRapidoInventario'
    ),

    mensajeBusquedaIngresoRapidoInventario: document.getElementById(
        'mensajeBusquedaIngresoRapidoInventario'
    )
};

const estado = {
    pagina: 1,
    limite: 20,

    busqueda: '',
    filtroEstado: 'ACTIVO',
    filtroResumen: null,

    productoEditando: null,
    productoMovimiento: null,
    productoIngresoRapido: null,
    productoConfirmarEstado: null,
    productoBusquedaRapida: null,
    temporizadorBusqueda: null,
    controladorCargaProductos: null,

    productos: [],
    paginacion: {
        pagina: 1,
        limite: 20,
        total: 0,
        totalPaginas: 1
    }
};

function obtenerFiltroResumenDesdeUrl() {
    const filtro = new URLSearchParams(
        window.location.search
    ).get('filtroResumen');

    if (
        filtro === 'ACTIVOS' ||
        filtro === 'SIN_EXISTENCIA' ||
        filtro === 'STOCK_MINIMO'
    ) {
        return filtro;
    }

    return null;
}

function obtenerBusquedaDesdeUrl() {
    const busqueda = new URLSearchParams(
        window.location.search
    ).get('busqueda');

    return textoSeguro(busqueda);
}
const TIPOS_VENTA_PRODUCTO = Object.freeze({
    UNIDAD: 'UNIDAD',
    FRACCIONABLE: 'FRACCIONABLE'
});
/* =========================================================
   UTILIDADES
   ========================================================= */

function textoSeguro(valor) {
    return String(valor ?? '').trim();
}

function numeroSeguro(valor, valorPorDefecto = 0) {
    const numero = Number(
        String(valor ?? '')
            .replace(',', '.')
            .trim()
    );

    return Number.isFinite(numero)
        ? numero
        : valorPorDefecto;
}

function obtenerIniciales(nombre) {
    const partes = textoSeguro(nombre)
        .split(/\s+/)
        .filter(Boolean)
        .slice(0, 2);

    if (partes.length === 0) {
        return '—';
    }

    return partes
        .map((parte) => parte.charAt(0))
        .join('')
        .toUpperCase();
}

function formatearUsd(valor) {
    return new Intl.NumberFormat(
        'es-VE',
        {
            style: 'currency',
            currency: 'USD',
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }
    ).format(numeroSeguro(valor));
}

function formatearCantidad(valor) {
    return new Intl.NumberFormat(
        'es-VE',
        {
            minimumFractionDigits: 0,
            maximumFractionDigits: 3
        }
    ).format(numeroSeguro(valor));
}

function valorNumeroParaCampo(valor) {
    const numero = numeroSeguro(valor, NaN);

    if (!Number.isFinite(numero)) {
        return '';
    }

    return String(numero).replace('.', ',');
}

function formatearFecha(valor) {
    if (!valor) {
        return '—';
    }

    const fecha = new Date(valor);

    if (Number.isNaN(fecha.getTime())) {
        return '—';
    }

    return new Intl.DateTimeFormat(
        'es-VE',
        {
            dateStyle: 'medium',
            timeStyle: 'short'
        }
    ).format(fecha);
}

function normalizarMontoPositivo(valor) {
    const texto = textoSeguro(valor)
        .replace(/\s+/g, '')
        .replace(',', '.');

    if (
        !/^(?:0|[1-9]\d{0,11})(?:\.\d{1,6})?$/
            .test(texto)
    ) {
        return null;
    }

    const numero = Number(texto);

    if (
        !Number.isFinite(numero) ||
        numero <= 0
    ) {
        return null;
    }

    return texto;
}

function normalizarCantidadNoNegativa(valor) {
    const textoOriginal = textoSeguro(valor);

    if (!textoOriginal) {
        return '0';
    }

    const texto = textoOriginal
        .replace(/\s+/g, '')
        .replace(',', '.');

    if (
        !/^(?:0|[1-9]\d{0,14})(?:\.\d{1,3})?$/
            .test(texto)
    ) {
        return null;
    }

    const numero = Number(texto);

    if (
        !Number.isFinite(numero) ||
        numero < 0
    ) {
        return null;
    }

    return texto;
}
function obtenerTipoVentaProducto(producto = null) {
    const tipoVenta = textoSeguro(
        producto?.tipoVenta ||
        producto?.tipo_venta
    ).toUpperCase();

    return tipoVenta ===
        TIPOS_VENTA_PRODUCTO.FRACCIONABLE
        ? TIPOS_VENTA_PRODUCTO.FRACCIONABLE
        : TIPOS_VENTA_PRODUCTO.UNIDAD;
}

function esProductoPorPeso(producto = null) {
    return obtenerTipoVentaProducto(producto) ===
        TIPOS_VENTA_PRODUCTO.FRACCIONABLE;
}

function obtenerUnidadMedidaProducto(producto = null) {
    return esProductoPorPeso(producto)
        ? 'KG'
        : 'UND';
}

function obtenerUnidadVisibleProducto(producto = null) {
    return obtenerUnidadMedidaProducto(producto)
        .toLowerCase();
}

function obtenerDescripcionVentaProducto(producto) {
    return esProductoPorPeso(producto)
        ? 'Por peso · KG'
        : 'Por unidad · UND';
}

function formatearCantidadConUnidad(
    cantidad,
    producto = null
) {
    return `${formatearCantidad(
        cantidad
    )} ${obtenerUnidadVisibleProducto(producto)}`;
}

function normalizarCantidadSegunTipoVenta(
    valor,
    tipoVenta,
    permiteCero = true
) {
    const cantidad = normalizarCantidadNoNegativa(
        valor
    );

    if (cantidad === null) {
        return null;
    }

    if (
        tipoVenta === TIPOS_VENTA_PRODUCTO.UNIDAD &&
        !/^(?:0|[1-9]\d{0,14})$/.test(cantidad)
    ) {
        return null;
    }

    if (
        !permiteCero &&
        Number(cantidad) <= 0
    ) {
        return null;
    }

    return cantidad;
}

function obtenerTipoVentaFormulario() {
    return elementos.tipoVentaFraccionableProducto.checked
        ? TIPOS_VENTA_PRODUCTO.FRACCIONABLE
        : TIPOS_VENTA_PRODUCTO.UNIDAD;
}

function actualizarFormularioSegunTipoVenta() {
    const esEdicion = Boolean(
        estado.productoEditando?.id
    );

    const tipoVenta = esEdicion
        ? obtenerTipoVentaProducto(
            estado.productoEditando
        )
        : obtenerTipoVentaFormulario();

    const porPeso = tipoVenta ===
        TIPOS_VENTA_PRODUCTO.FRACCIONABLE;

    elementos.tipoVentaUnidadProducto.checked =
        !porPeso;

    elementos.tipoVentaFraccionableProducto.checked =
        porPeso;

    elementos.tipoVentaUnidadProducto.disabled =
        esEdicion;

    elementos.tipoVentaFraccionableProducto.disabled =
        esEdicion;

    elementos.bloqueTipoVentaProducto.classList.toggle(
        'selector-tipo-venta--bloqueado',
        esEdicion
    );

    elementos.ayudaTipoVentaProducto.textContent =
        esEdicion
            ? 'La forma de venta queda bloqueada para proteger las existencias y el historial del producto.'
            : porPeso
                ? 'Este producto se venderá por kilogramo y permitirá hasta tres decimales.'
                : 'Este producto se venderá por unidad y solo permitirá cantidades enteras.';

    elementos.etiquetaPrecioVentaUsdProducto.textContent =
        porPeso
            ? 'Precio de venta USD por kg'
            : 'Precio de venta USD por unidad';

    elementos.etiquetaStockMinimoProducto.innerHTML =
        porPeso
            ? 'Stock mínimo en kg <span>Opcional</span>'
            : 'Stock mínimo en und <span>Opcional</span>';

    elementos.etiquetaExistenciaInicialProducto.textContent =
        porPeso
            ? 'Existencia inicial en kg'
            : 'Existencia inicial en und';

    elementos.precioVentaUsdProducto.placeholder =
        porPeso
            ? 'Ej.: 8,00'
            : 'Ej.: 2,50';

    elementos.stockMinimoProducto.placeholder =
        porPeso
            ? 'Ej.: 2,500'
            : 'Ej.: 5';

    elementos.existenciaInicialProducto.placeholder =
        porPeso
            ? 'Ej.: 12,750'
            : 'Ej.: 20';

    elementos.stockMinimoProducto.inputMode =
        porPeso
            ? 'decimal'
            : 'numeric';

    elementos.existenciaInicialProducto.inputMode =
        porPeso
            ? 'decimal'
            : 'numeric';

    elementos.ayudaExistenciaInicialProducto.textContent =
        porPeso
            ? 'El peso inicial se guardará como entrada inicial en el Almacén principal.'
            : 'La cantidad inicial se guardará como entrada inicial en el Almacén principal.';
}
function obtenerMensajeError(error, mensajePorDefecto) {
    const mensaje = textoSeguro(error?.message);

    return mensaje || mensajePorDefecto;
}

async function solicitarJson(url, opciones = {}) {
    const respuesta = await fetch(url, {
        credentials: 'same-origin',
        ...opciones
    });

    const contenido = await respuesta
        .json()
        .catch(() => ({}));

    if (!respuesta.ok) {
        const error = new Error(
            contenido.mensaje ||
            contenido.error ||
            'No fue posible completar la operación.'
        );

        error.codigo = contenido.codigo || null;
        error.estadoHttp = respuesta.status;

        throw error;
    }

    return contenido;
}

function crearElemento(
    etiqueta,
    texto = '',
    clase = ''
) {
    const elemento = document.createElement(etiqueta);

    if (clase) {
        elemento.className = clase;
    }

    if (texto !== '') {
        elemento.textContent = texto;
    }

    return elemento;
}

function mostrarMensajeFlotante(
    mensaje,
    tipo = 'normal'
) {
    const elemento = elementos.mensajeFlotanteInventario;

    elemento.textContent = mensaje;

    elemento.classList.remove(
        'mensaje-flotante-inventario--error',
        'mensaje-flotante-inventario--correcto'
    );

    if (tipo === 'error') {
        elemento.classList.add(
            'mensaje-flotante-inventario--error'
        );
    }

    if (tipo === 'correcto') {
        elemento.classList.add(
            'mensaje-flotante-inventario--correcto'
        );
    }

    elemento.classList.add(
        'mensaje-flotante-inventario--visible'
    );

    window.clearTimeout(
        mostrarMensajeFlotante.temporizador
    );

    mostrarMensajeFlotante.temporizador = window.setTimeout(
        () => {
            elemento.classList.remove(
                'mensaje-flotante-inventario--visible'
            );
        },
        4200
    );
}

function mostrarMensajeFormulario(
    mensaje,
    tipo = 'error'
) {
    elementos.mensajeFormularioProducto.textContent =
        mensaje;

    elementos.mensajeFormularioProducto.classList.remove(
        'mensaje-formulario-producto--correcto'
    );

    if (tipo === 'correcto') {
        elementos.mensajeFormularioProducto.classList.add(
            'mensaje-formulario-producto--correcto'
        );
    }
}

function limpiarMensajeFormulario() {
    elementos.mensajeFormularioProducto.textContent = '';

    elementos.mensajeFormularioProducto.classList.remove(
        'mensaje-formulario-producto--correcto'
    );
}

/* =========================================================
   CONTEXTO DE APLICACIÓN
   ========================================================= */

function obtenerUsuarioEstado(datos) {
    return (
        datos?.usuario ||
        datos?.sesion?.usuario ||
        datos?.contexto?.sesion?.usuario ||
        {}
    );
}

function obtenerNegocioEstado(datos) {
    return (
        datos?.negocio ||
        datos?.configuracionNegocio ||
        datos?.contexto?.negocio ||
        {}
    );
}

function obtenerLicenciaEstado(datos) {
    return (
        datos?.licencia ||
        datos?.contexto?.licencia ||
        {}
    );
}

function renderizarContextoAplicacion(datos) {
    const usuario = obtenerUsuarioEstado(datos);
    const negocio = obtenerNegocioEstado(datos);
    const licencia = obtenerLicenciaEstado(datos);

    const nombreUsuario =
        textoSeguro(usuario.nombreCompleto) ||
        textoSeguro(usuario.nombre_completo) ||
        textoSeguro(usuario.nombre) ||
        textoSeguro(usuario.username) ||
        'Usuario';

    const rol =
        textoSeguro(usuario.rol) ||
        '—';

    const nombreNegocio =
        textoSeguro(negocio.nombreComercial) ||
        textoSeguro(negocio.nombre_comercial) ||
        textoSeguro(negocio.nombre) ||
        'Tenvik';

    const estadoLicencia =
        textoSeguro(licencia.estado) ||
        'ACTIVA';

    elementos.nombreNegocioSuperior.textContent =
        nombreNegocio;

    elementos.nombreUsuarioLateral.textContent =
        nombreUsuario;

    elementos.rolUsuarioLateral.textContent =
        rol;

    elementos.avatarUsuarioLateral.textContent =
        obtenerIniciales(nombreUsuario);

    elementos.estadoLicenciaSuperior.textContent =
        `Licencia: ${estadoLicencia}`;

    if (elementos.estadoActualizacionSuperior) {
        const disponible = Boolean(datos?.actualizacion?.disponible);
        if (disponible) {
            elementos.estadoActualizacionSuperior.hidden = false;
            elementos.estadoActualizacionSuperior.classList.add('estado-actualizacion--visible');
            elementos.estadoActualizacionSuperior.classList.remove('estado-actualizacion--oculto');
        } else {
            elementos.estadoActualizacionSuperior.hidden = true;
            elementos.estadoActualizacionSuperior.classList.add('estado-actualizacion--oculto');
            elementos.estadoActualizacionSuperior.classList.remove('estado-actualizacion--visible');
        }
    }
}

if (elementos.estadoActualizacionSuperior) {
    elementos.estadoActualizacionSuperior.addEventListener(
        'click',
        () => {
            sessionStorage.setItem(
                'tenvik.focus.actualizacion',
                'true'
            );
        }
    );
}

async function cargarContextoAplicacion() {
    try {
        const datos = await solicitarJson(
            '/api/aplicacion/estado'
        );

        renderizarContextoAplicacion(datos);
    } catch (error) {
        if (
            error.estadoHttp === 401 ||
            error.estadoHttp === 403
        ) {
            window.location.assign('/');
            return;
        }

        elementos.estadoLicenciaSuperior.textContent =
            'No fue posible consultar la licencia.';
    }
}

/* =========================================================
   RESUMEN DE INVENTARIO
   ========================================================= */

function renderizarResumenInventario(productos) {
    const productosActivos = productos.filter(
        (producto) => producto.estado === 'ACTIVO'
    );

    const sinExistencia = productosActivos.filter(
        (producto) => numeroSeguro(
            producto.existenciaDisponible
        ) <= 0
    );

    const conStockMinimo = productosActivos.filter(
        (producto) => {
            const disponible = numeroSeguro(
                producto.existenciaDisponible
            );

            const minimo = numeroSeguro(
                producto.stockMinimo
            );

            return minimo > 0 && disponible <= minimo;
        }
    );

    elementos.cantidadProductosActivos.textContent =
        String(productosActivos.length);

    elementos.cantidadProductosSinExistencia.textContent =
        String(sinExistencia.length);

    elementos.cantidadProductosStockMinimo.textContent =
        String(conStockMinimo.length);
}

async function cargarResumenInventario() {
    const productosActivos = [];

    let pagina = 1;
    let totalPaginas = 1;

    try {
        do {
            const parametros = new URLSearchParams({
                estado: 'ACTIVO',
                pagina: String(pagina),
                limite: '100'
            });

            const datos = await solicitarJson(
                `/api/inventario/productos?${parametros.toString()}`
            );

            productosActivos.push(
                ...(Array.isArray(datos.productos)
                    ? datos.productos
                    : [])
            );

            totalPaginas = Number(
                datos.paginacion?.totalPaginas || 1
            );

            pagina += 1;
        } while (pagina <= totalPaginas);

        renderizarResumenInventario(productosActivos);
    } catch (error) {
        elementos.cantidadProductosActivos.textContent = '—';
        elementos.cantidadProductosSinExistencia.textContent = '—';
        elementos.cantidadProductosStockMinimo.textContent = '—';
    }
}

/* =========================================================
   LISTADO DE PRODUCTOS
   ========================================================= */

function obtenerProductosFiltradosPorResumen(productos) {
    if (!estado.filtroResumen) {
        return productos;
    }

    return productos.filter((producto) => {
        const disponible = numeroSeguro(
            producto.existenciaDisponible
        );

        const minimo = numeroSeguro(
            producto.stockMinimo
        );

        if (estado.filtroResumen === 'ACTIVOS') {
            return producto.estado === 'ACTIVO';
        }

        if (estado.filtroResumen === 'SIN_EXISTENCIA') {
            return disponible <= 0;
        }

        if (estado.filtroResumen === 'STOCK_MINIMO') {
            return minimo > 0 && disponible <= minimo;
        }

        return true;
    });
}

function actualizarResumenSeleccionado() {
    elementos.tarjetaProductosActivos.classList.toggle(
        'tarjeta-resumen-inventario--activo',
        estado.filtroResumen === 'ACTIVOS'
    );

    elementos.tarjetaSinExistencia.classList.toggle(
        'tarjeta-resumen-inventario--activo',
        estado.filtroResumen === 'SIN_EXISTENCIA'
    );

    elementos.tarjetaStockMinimo.classList.toggle(
        'tarjeta-resumen-inventario--activo',
        estado.filtroResumen === 'STOCK_MINIMO'
    );
}

function obtenerProductosFiltradosPorResumen(productos) {
    if (!estado.filtroResumen) {
        return productos;
    }

    return productos.filter((producto) => {
        const disponible = numeroSeguro(
            producto.existenciaDisponible
        );

        const minimo = numeroSeguro(
            producto.stockMinimo
        );

        if (estado.filtroResumen === 'ACTIVOS') {
            return producto.estado === 'ACTIVO';
        }

        if (estado.filtroResumen === 'SIN_EXISTENCIA') {
            return producto.estado === 'ACTIVO' && disponible <= 0;
        }

        if (estado.filtroResumen === 'STOCK_MINIMO') {
            return producto.estado === 'ACTIVO' && minimo > 0 && disponible <= minimo;
        }

        return true;
    });
}

function actualizarResumenSeleccionado() {
    elementos.tarjetaProductosActivos.classList.toggle(
        'tarjeta-resumen-inventario--activo',
        estado.filtroResumen === 'ACTIVOS'
    );

    elementos.tarjetaSinExistencia.classList.toggle(
        'tarjeta-resumen-inventario--activo',
        estado.filtroResumen === 'SIN_EXISTENCIA'
    );

    elementos.tarjetaStockMinimo.classList.toggle(
        'tarjeta-resumen-inventario--activo',
        estado.filtroResumen === 'STOCK_MINIMO'
    );
}

function mostrarEstadoCargaTabla(mensaje) {
    elementos.cuerpoTablaProductos.replaceChildren();

    const fila = document.createElement('tr');

    const celda = crearElemento(
        'td',
        mensaje,
        'tabla-productos__cargando'
    );

    celda.colSpan = 8;

    fila.appendChild(celda);

    elementos.cuerpoTablaProductos.appendChild(fila);
}

function obtenerClaseCantidadProducto(producto) {
    const disponible = numeroSeguro(
        producto.existenciaDisponible
    );

    const minimo = numeroSeguro(
        producto.stockMinimo
    );

    if (disponible <= 0) {
        return 'cantidad-producto-tabla--agotado';
    }

    if (minimo > 0 && disponible <= minimo) {
        return 'cantidad-producto-tabla--minimo';
    }

    return '';
}

function crearFilaProducto(producto) {
    const fila = document.createElement('tr');

    const unidad =
        obtenerUnidadVisibleProducto(producto);

    const celdaProducto = document.createElement('td');

    const informacionProducto = crearElemento(
        'div',
        '',
        'producto-tabla'
    );

    informacionProducto.appendChild(
        crearElemento('strong', producto.nombre)
    );

    informacionProducto.appendChild(
        crearElemento(
            'span',
            obtenerDescripcionVentaProducto(producto),
            'producto-tabla__tipo-venta'
        )
    );

    informacionProducto.appendChild(
        crearElemento(
            'span',
            producto.codigoBarras
                ? `Código de barras: ${producto.codigoBarras}`
                : 'Sin código de barras'
        )
    );

    celdaProducto.appendChild(informacionProducto);

    const celdaCodigo = document.createElement('td');

    celdaCodigo.appendChild(
        crearElemento(
            'span',
            producto.codigoInterno || producto.codigoBarras || '—',
            'codigo-producto-tabla'
        )
    );

    const celdaPrecio = document.createElement('td');

    celdaPrecio.appendChild(
        crearElemento(
            'span',
            `${formatearUsd(
                producto.precioVentaUsd
            )} / ${unidad}`,
            'precio-producto-tabla'
        )
    );

    const celdaIva = document.createElement('td');

    celdaIva.appendChild(
        crearElemento(
            'span',
            producto.aplicaIva ? 'Aplica' : 'Exento',
            producto.aplicaIva
                ? 'etiqueta-iva etiqueta-iva--aplica'
                : 'etiqueta-iva etiqueta-iva--exento'
        )
    );

    const celdaExistencia = document.createElement('td');

    celdaExistencia.appendChild(
        crearElemento(
            'span',
            formatearCantidadConUnidad(
                producto.existenciaDisponible,
                producto
            ),
            [
                'cantidad-producto-tabla',
                obtenerClaseCantidadProducto(producto)
            ]
                .filter(Boolean)
                .join(' ')
        )
    );

    const celdaStockMinimo = document.createElement('td');

    celdaStockMinimo.appendChild(
        crearElemento(
            'span',
            formatearCantidadConUnidad(
                producto.stockMinimo,
                producto
            ),
            'cantidad-producto-tabla'
        )
    );

    const celdaEstado = document.createElement('td');

    const esActivo = producto.estado === 'ACTIVO';

    celdaEstado.appendChild(
        crearElemento(
            'span',
            esActivo ? 'Activo' : 'Inactivo',
            esActivo
                ? 'etiqueta-estado-producto etiqueta-estado-producto--activo'
                : 'etiqueta-estado-producto etiqueta-estado-producto--inactivo'
        )
    );

    const celdaAcciones = document.createElement('td');

    const contenedorAcciones = crearElemento(
        'div',
        '',
        'acciones-producto-tabla'
    );

    const botonEditar = crearElemento(
        'button',
        'Editar',
        'boton-accion-producto'
    );

    botonEditar.type = 'button';

    botonEditar.addEventListener('click', () => {
        abrirPanelEditarProducto(producto.id);
    });

    const botonStock = crearElemento(
        'button',
        'Stock',
        'boton-accion-producto'
    );

    botonStock.type = 'button';

    botonStock.addEventListener('click', () => {
        abrirPanelMovimientoInventario(producto.id);
    });

    const botonEstado = crearElemento(
        'button',
        esActivo ? 'Inactivar' : 'Activar',
        'boton-accion-producto boton-accion-producto--estado'
    );

    botonEstado.type = 'button';

    botonEstado.addEventListener('click', () => {
        abrirModalConfirmarEstadoProducto(producto);
    });

    contenedorAcciones.append(
        botonEditar,
        botonStock,
        botonEstado
    );

    celdaAcciones.appendChild(contenedorAcciones);

    fila.append(
        celdaProducto,
        celdaCodigo,
        celdaPrecio,
        celdaIva,
        celdaExistencia,
        celdaStockMinimo,
        celdaEstado,
        celdaAcciones
    );

    return fila;
}
function renderizarProductos(productos) {
    elementos.cuerpoTablaProductos.replaceChildren();

    if (productos.length === 0) {
        mostrarEstadoCargaTabla(
            'No se encontraron productos con los filtros seleccionados.'
        );

        return;
    }

    const productosFiltrados =
        obtenerProductosFiltradosPorResumen(productos);

    const fragmento = document.createDocumentFragment();

    productosFiltrados.forEach((producto) => {
        fragmento.appendChild(
            crearFilaProducto(producto)
        );
    });

    elementos.cuerpoTablaProductos.appendChild(fragmento);
}

function renderizarPaginacion(paginacion) {
    const pagina = Number(paginacion.pagina || 1);
    const total = Number(paginacion.total || 0);
    const totalPaginas = Number(
        paginacion.totalPaginas || 1
    );

    elementos.paginaActualProductos.textContent =
        `${pagina} / ${totalPaginas}`;

    elementos.mensajePaginacionProductos.textContent =
        total === 1
            ? '1 producto encontrado.'
            : `${total} productos encontrados.`;

    elementos.botonPaginaAnterior.disabled =
        pagina <= 1;

    elementos.botonPaginaSiguiente.disabled =
        pagina >= totalPaginas;
}

async function cargarProductos() {
    if (estado.controladorCargaProductos) {
        estado.controladorCargaProductos.abort();
    }

    estado.controladorCargaProductos =
        new AbortController();

    const parametros = new URLSearchParams({
        busqueda: estado.busqueda,
        estado: estado.filtroEstado,
        pagina: String(estado.pagina),
        limite: String(estado.limite)
    });

    mostrarEstadoCargaTabla(
        'Consultando productos...'
    );

    try {
        const datos = await solicitarJson(
            `/api/inventario/productos?${parametros.toString()}`,
            {
                signal: estado.controladorCargaProductos.signal
            }
        );

        estado.productos = Array.isArray(datos.productos)
            ? datos.productos
            : [];

        estado.paginacion = datos.paginacion || {
            pagina: 1,
            limite: estado.limite,
            total: 0,
            totalPaginas: 1
        };

        renderizarProductos(estado.productos);

        renderizarPaginacion(estado.paginacion);

        elementos.resumenProductos.textContent =
            estado.paginacion.total === 1
                ? 'Mostrando 1 producto.'
                : `Mostrando ${estado.productos.length} de ${estado.paginacion.total} productos.`;
    } catch (error) {
        if (error.name === 'AbortError') {
            return;
        }

        mostrarEstadoCargaTabla(
            'No fue posible cargar los productos.'
        );

        elementos.resumenProductos.textContent =
            'Ocurrió un problema consultando el inventario.';

        mostrarMensajeFlotante(
            obtenerMensajeError(
                error,
                'No fue posible consultar el inventario.'
            ),
            'error'
        );
    }
}

/* =========================================================
   PANEL DE PRODUCTO
   ========================================================= */

function abrirModalProducto() {
    elementos.modalProducto.hidden = false;

    document.body.style.overflow = 'hidden';
}

function cerrarModalProducto() {
    elementos.modalProducto.hidden = true;

    document.body.style.overflow = '';

    estado.productoEditando = null;

    elementos.formularioProducto.reset();

    elementos.tipoVentaUnidadProducto.checked = true;
    elementos.tipoVentaFraccionableProducto.checked = false;

    actualizarFormularioSegunTipoVenta();

    limpiarMensajeFormulario();

    elementos.detalleAuditoriaProducto.hidden = true;
    elementos.detalleAuditoriaProducto.textContent = '';
}

function prepararPanelNuevoProducto() {
    estado.productoEditando = null;

    elementos.formularioProducto.reset();

    elementos.tipoVentaUnidadProducto.checked = true;
    elementos.tipoVentaFraccionableProducto.checked = false;

    elementos.etiquetaPanelProducto.textContent =
        'Nuevo registro';

    elementos.tituloPanelProducto.textContent =
        'Registrar producto';

    elementos.botonGuardarProducto.textContent =
        'Guardar producto';

    elementos.bloqueExistenciaInicialProducto.hidden =
        false;

    elementos.existenciaInicialProducto.disabled =
        false;

    elementos.aplicaIvaProducto.checked = true;

    actualizarFormularioSegunTipoVenta();

    elementos.detalleAuditoriaProducto.hidden = true;
    elementos.detalleAuditoriaProducto.textContent = '';

    limpiarMensajeFormulario();

    abrirModalProducto();

    window.setTimeout(() => {
        elementos.nombreProducto.focus();
    }, 80);
}

function llenarFormularioProducto(producto) {
    const tipoVenta = obtenerTipoVentaProducto(
        producto
    );

    elementos.tipoVentaUnidadProducto.checked =
        tipoVenta === TIPOS_VENTA_PRODUCTO.UNIDAD;

    elementos.tipoVentaFraccionableProducto.checked =
        tipoVenta === TIPOS_VENTA_PRODUCTO.FRACCIONABLE;

    elementos.nombreProducto.value =
        producto.nombre || '';

    elementos.codigoInternoProducto.value =
        producto.codigoInterno || '';

    elementos.codigoBarrasProducto.value =
        producto.codigoBarras || '';

    elementos.precioVentaUsdProducto.value =
        valorNumeroParaCampo(
            producto.precioVentaUsd
        );

    elementos.stockMinimoProducto.value =
        valorNumeroParaCampo(
            producto.stockMinimo
        );

    elementos.existenciaInicialProducto.value = '';

    elementos.aplicaIvaProducto.checked =
        producto.aplicaIva === true;

    actualizarFormularioSegunTipoVenta();
}

function obtenerDatosFormularioProducto() {
    const nombre = textoSeguro(
        elementos.nombreProducto.value
    );

    const codigoInterno = textoSeguro(
        elementos.codigoInternoProducto.value
    );

    const codigoBarras = textoSeguro(
        elementos.codigoBarrasProducto.value
    );

    const tipoVenta = estado.productoEditando?.id
        ? obtenerTipoVentaProducto(
            estado.productoEditando
        )
        : obtenerTipoVentaFormulario();

    const porPeso = tipoVenta ===
        TIPOS_VENTA_PRODUCTO.FRACCIONABLE;

    const precioVentaUsd = normalizarMontoPositivo(
        elementos.precioVentaUsdProducto.value
    );

    const stockMinimo = normalizarCantidadSegunTipoVenta(
        elementos.stockMinimoProducto.value,
        tipoVenta
    );

    const existenciaInicial =
        normalizarCantidadSegunTipoVenta(
            elementos.existenciaInicialProducto.value,
            tipoVenta
        );

    if (nombre.length < 2) {
        return {
            error:
                'Ingrese un nombre de producto de al menos 2 caracteres.',
            campo: elementos.nombreProducto
        };
    }

    if (!precioVentaUsd) {
        return {
            error: porPeso
                ? 'Ingrese un precio por kg válido y mayor que cero.'
                : 'Ingrese un precio por unidad válido y mayor que cero.',
            campo: elementos.precioVentaUsdProducto
        };
    }

    if (stockMinimo === null) {
        return {
            error: porPeso
                ? 'Ingrese un stock mínimo válido en kg, con hasta 3 decimales.'
                : 'Ingrese un stock mínimo válido en unidades enteras.',
            campo: elementos.stockMinimoProducto
        };
    }

    if (
        !estado.productoEditando &&
        existenciaInicial === null
    ) {
        return {
            error: porPeso
                ? 'Ingrese una existencia inicial válida en kg, con hasta 3 decimales.'
                : 'Ingrese una existencia inicial válida en unidades enteras.',
            campo: elementos.existenciaInicialProducto
        };
    }

    return {
        datos: {
            nombre,
            codigoInterno,
            codigoBarras,
            tipoVenta,
            precioVentaUsd,
            stockMinimo,
            existenciaInicial:
                existenciaInicial === null
                    ? '0'
                    : existenciaInicial,

            aplicaIva:
                elementos.aplicaIvaProducto.checked
        }
    };
}

function renderizarAuditoriaProducto(producto) {
    const lineas = [];

    if (producto.creadoEn) {
        const responsable =
            producto.creadoPorNombre || 'Usuario local';

        lineas.push(
            `Creado por ${responsable} el ${formatearFecha(
                producto.creadoEn
            )}.`
        );
    }

    if (producto.actualizadoEn) {
        const responsable =
            producto.actualizadoPorNombre || 'Usuario local';

        lineas.push(
            `Actualizado por ${responsable} el ${formatearFecha(
                producto.actualizadoEn
            )}.`
        );
    }

    if (lineas.length === 0) {
        elementos.detalleAuditoriaProducto.hidden = true;
        elementos.detalleAuditoriaProducto.textContent = '';

        return;
    }

    elementos.detalleAuditoriaProducto.textContent =
        lineas.join(' ');

    elementos.detalleAuditoriaProducto.hidden = false;
}

async function abrirPanelEditarProducto(productoId) {
    limpiarMensajeFormulario();

    elementos.etiquetaPanelProducto.textContent =
        'Edición de producto';

    elementos.tituloPanelProducto.textContent =
        'Cargando producto...';

    elementos.botonGuardarProducto.textContent =
        'Guardar cambios';

    elementos.bloqueExistenciaInicialProducto.hidden =
        true;

    elementos.existenciaInicialProducto.disabled =
        true;

    elementos.detalleAuditoriaProducto.hidden = true;

    abrirModalProducto();

    try {
        const datos = await solicitarJson(
            `/api/inventario/productos/${productoId}`
        );

        const producto = datos.producto;

        estado.productoEditando = producto;

        elementos.tituloPanelProducto.textContent =
            'Editar producto';

        llenarFormularioProducto(producto);

        renderizarAuditoriaProducto(producto);

        window.setTimeout(() => {
            elementos.nombreProducto.focus();
        }, 80);
    } catch (error) {
        cerrarModalProducto();

        mostrarMensajeFlotante(
            obtenerMensajeError(
                error,
                'No fue posible consultar el producto.'
            ),
            'error'
        );
    }
}

async function guardarProducto(evento) {
    evento.preventDefault();

    limpiarMensajeFormulario();

    const resultado = obtenerDatosFormularioProducto();

    if (resultado.error) {
        mostrarMensajeFormulario(resultado.error);

        resultado.campo?.focus();

        return;
    }

    const esEdicion =
        Boolean(estado.productoEditando?.id);

    const url = esEdicion
        ? `/api/inventario/productos/${estado.productoEditando.id}`
        : '/api/inventario/productos';

    const metodo = esEdicion
        ? 'PUT'
        : 'POST';

    const textoOriginal =
        elementos.botonGuardarProducto.textContent;

    elementos.botonGuardarProducto.disabled = true;

    elementos.botonGuardarProducto.textContent =
        esEdicion
            ? 'Guardando...'
            : 'Registrando...';

    try {
        const datos = await solicitarJson(url, {
            method: metodo,

            headers: {
                'Content-Type': 'application/json'
            },

            body: JSON.stringify(resultado.datos)
        });

        mostrarMensajeFormulario(
            datos.mensaje ||
            (
                esEdicion
                    ? 'Producto actualizado correctamente.'
                    : 'Producto registrado correctamente.'
            ),
            'correcto'
        );

        mostrarMensajeFlotante(
            datos.mensaje ||
            (
                esEdicion
                    ? 'Producto actualizado correctamente.'
                    : 'Producto registrado correctamente.'
            ),
            'correcto'
        );

        window.setTimeout(() => {
            cerrarModalProducto();

            Promise.all([
                cargarProductos(),
                cargarResumenInventario()
            ]);
        }, 350);
    } catch (error) {
        mostrarMensajeFormulario(
            obtenerMensajeError(
                error,
                'No fue posible guardar el producto.'
            )
        );
    } finally {
        elementos.botonGuardarProducto.disabled = false;

        elementos.botonGuardarProducto.textContent =
            textoOriginal;
    }
}
/* =========================================================
   MOVIMIENTOS DE INVENTARIO
   ========================================================= */

function limpiarMensajeFormularioMovimiento() {
    elementos.mensajeFormularioMovimientoInventario.textContent = '';

    elementos.mensajeFormularioMovimientoInventario.classList.remove(
        'mensaje-formulario-movimiento--correcto'
    );
}

function mostrarMensajeFormularioMovimiento(
    mensaje,
    tipo = 'error'
) {
    elementos.mensajeFormularioMovimientoInventario.textContent =
        mensaje;

    elementos.mensajeFormularioMovimientoInventario.classList.remove(
        'mensaje-formulario-movimiento--correcto'
    );

    if (tipo === 'correcto') {
        elementos.mensajeFormularioMovimientoInventario.classList.add(
            'mensaje-formulario-movimiento--correcto'
        );
    }
}

function obtenerModoMovimientoSeleccionado() {
    const modoSeleccionado = document.querySelector(
        'input[name="modoMovimientoInventario"]:checked'
    );

    return textoSeguro(modoSeleccionado?.value)
        .toUpperCase();
}

function actualizarTextoModoMovimiento() {
    const modo = obtenerModoMovimientoSeleccionado();

    const producto = estado.productoMovimiento;

    const porPeso = esProductoPorPeso(producto);

    const nombreCantidad = porPeso
        ? 'peso'
        : 'cantidad';

    elementos.cantidadMovimientoInventario.inputMode =
        porPeso
            ? 'decimal'
            : 'numeric';

    if (modo === 'ENTRADA') {
        elementos.etiquetaCantidadMovimientoInventario.textContent =
            porPeso
                ? 'Peso a añadir (kg)'
                : 'Cantidad a añadir (und)';

        elementos.ayudaCantidadMovimientoInventario.textContent =
            `El ${nombreCantidad} se sumará a la existencia actual.`;

        elementos.cantidadMovimientoInventario.placeholder =
            porPeso
                ? 'Ej.: 2,500'
                : 'Ej.: 10';

        return;
    }

    if (modo === 'SALIDA') {
        elementos.etiquetaCantidadMovimientoInventario.textContent =
            porPeso
                ? 'Peso a retirar (kg)'
                : 'Cantidad a retirar (und)';

        elementos.ayudaCantidadMovimientoInventario.textContent =
            `El ${nombreCantidad} se restará de la existencia actual. No se permite dejar stock negativo.`;

        elementos.cantidadMovimientoInventario.placeholder =
            porPeso
                ? 'Ej.: 0,500'
                : 'Ej.: 5';

        return;
    }

    elementos.etiquetaCantidadMovimientoInventario.textContent =
        porPeso
            ? 'Peso real contado (kg)'
            : 'Cantidad real contada (und)';

    elementos.ayudaCantidadMovimientoInventario.textContent =
        `Indique el ${nombreCantidad} físico real encontrado durante el reconteo.`;

    elementos.cantidadMovimientoInventario.placeholder =
        porPeso
            ? 'Ej.: 12,750'
            : 'Ej.: 25';
}

function abrirModalMovimientoInventario() {
    elementos.modalMovimientoInventario.hidden = false;

    document.body.style.overflow = 'hidden';
}

function cerrarModalMovimientoInventario() {
    elementos.modalMovimientoInventario.hidden = true;

    document.body.style.overflow = '';

    estado.productoMovimiento = null;

    elementos.formularioMovimientoInventario.reset();

    elementos.modoMovimientoEntrada.checked = true;

    elementos.nombreProductoMovimientoInventario.textContent =
        '—';

    elementos.codigoProductoMovimientoInventario.textContent =
        '—';

    elementos.existenciaActualMovimientoInventario.textContent =
        '—';

    limpiarMensajeFormularioMovimiento();

    actualizarTextoModoMovimiento();
}

function llenarPanelMovimientoInventario(producto) {
    elementos.nombreProductoMovimientoInventario.textContent =
        producto.nombre || 'Producto';

    elementos.codigoProductoMovimientoInventario.textContent =
        producto.codigoInterno || 'Sin código interno';

    elementos.existenciaActualMovimientoInventario.textContent =
        formatearCantidadConUnidad(
            producto.existenciaDisponible,
            producto
        );

    elementos.modoMovimientoEntrada.checked = true;

    elementos.cantidadMovimientoInventario.value = '';

    elementos.notaMovimientoInventario.value = '';

    limpiarMensajeFormularioMovimiento();

    actualizarTextoModoMovimiento();
}

async function abrirPanelMovimientoInventario(productoId) {
    abrirModalMovimientoInventario();

    elementos.nombreProductoMovimientoInventario.textContent =
        'Consultando producto...';

    elementos.codigoProductoMovimientoInventario.textContent =
        '—';

    elementos.existenciaActualMovimientoInventario.textContent =
        '—';

    elementos.cantidadMovimientoInventario.value = '';

    elementos.notaMovimientoInventario.value = '';

    limpiarMensajeFormularioMovimiento();

    try {
        const datos = await solicitarJson(
            `/api/inventario/productos/${productoId}`
        );

        estado.productoMovimiento = datos.producto;

        llenarPanelMovimientoInventario(
            datos.producto
        );

        window.setTimeout(() => {
            elementos.cantidadMovimientoInventario.focus();
        }, 80);
    } catch (error) {
        cerrarModalMovimientoInventario();

        mostrarMensajeFlotante(
            obtenerMensajeError(
                error,
                'No fue posible consultar el producto.'
            ),
            'error'
        );
    }
}

function obtenerDatosMovimientoInventario() {
    const modo = obtenerModoMovimientoSeleccionado();

    const producto = estado.productoMovimiento;

    if (!producto) {
        return {
            error:
                'No se encontró un producto válido para ajustar.'
        };
    }

    const tipoVenta = obtenerTipoVentaProducto(
        producto
    );

    const porPeso = esProductoPorPeso(producto);

    const cantidad = normalizarCantidadSegunTipoVenta(
        elementos.cantidadMovimientoInventario.value,
        tipoVenta,
        modo === 'RECONTEO'
    );

    const nota = textoSeguro(
        elementos.notaMovimientoInventario.value
    );

    if (
        modo !== 'ENTRADA' &&
        modo !== 'SALIDA' &&
        modo !== 'RECONTEO'
    ) {
        return {
            error:
                'Seleccione una operación de inventario válida.'
        };
    }

    if (cantidad === null) {
        return {
            error: porPeso
                ? (
                    modo === 'RECONTEO'
                        ? 'Ingrese un peso real válido en kg, igual o mayor que cero.'
                        : 'Ingrese un peso válido en kg y mayor que cero.'
                )
                : (
                    modo === 'RECONTEO'
                        ? 'Ingrese una cantidad entera válida, igual o mayor que cero.'
                        : 'Ingrese una cantidad entera válida y mayor que cero.'
                ),

            campo: elementos.cantidadMovimientoInventario
        };
    }

    if (nota.length > 250) {
        return {
            error:
                'La nota no puede superar 250 caracteres.',

            campo: elementos.notaMovimientoInventario
        };
    }

    return {
        datos: {
            modo,
            cantidad,
            nota
        }
    };
}

async function guardarMovimientoInventario(evento) {
    evento.preventDefault();

    limpiarMensajeFormularioMovimiento();

    if (!estado.productoMovimiento?.id) {
        mostrarMensajeFormularioMovimiento(
            'No se encontró un producto válido para ajustar.'
        );

        return;
    }

    const resultado = obtenerDatosMovimientoInventario();

    if (resultado.error) {
        mostrarMensajeFormularioMovimiento(
            resultado.error
        );

        resultado.campo?.focus();

        return;
    }

    const textoOriginal =
        elementos.botonGuardarMovimientoInventario
            .textContent;

    elementos.botonGuardarMovimientoInventario.disabled =
        true;

    elementos.botonGuardarMovimientoInventario.textContent =
        'Guardando...';

    try {
        const datos = await solicitarJson(
            `/api/inventario/productos/${estado.productoMovimiento.id}/existencia`,
            {
                method: 'POST',

                headers: {
                    'Content-Type': 'application/json'
                },

                body: JSON.stringify(resultado.datos)
            }
        );

        mostrarMensajeFormularioMovimiento(
            datos.mensaje ||
            'Existencia actualizada correctamente.',
            'correcto'
        );

        mostrarMensajeFlotante(
            datos.mensaje ||
            'Existencia actualizada correctamente.',
            'correcto'
        );

        window.setTimeout(async () => {
            cerrarModalMovimientoInventario();

            await Promise.all([
                cargarProductos(),
                cargarResumenInventario()
            ]);
        }, 350);
    } catch (error) {
        mostrarMensajeFormularioMovimiento(
            obtenerMensajeError(
                error,
                'No fue posible actualizar la existencia.'
            )
        );
    } finally {
        elementos.botonGuardarMovimientoInventario.disabled =
            false;

        elementos.botonGuardarMovimientoInventario.textContent =
            textoOriginal;
    }
}

function limpiarMensajeFormularioIngresoRapido() {
    elementos.mensajeFormularioIngresoRapidoInventario.textContent = '';
}

function mostrarMensajeFormularioIngresoRapido(mensaje, tipo = 'error') {
    const elemento = elementos.mensajeFormularioIngresoRapidoInventario;

    elemento.textContent = mensaje;
    elemento.classList.remove(
        'mensaje-formulario-movimiento--correcto'
    );

    if (tipo === 'correcto') {
        elemento.classList.add(
            'mensaje-formulario-movimiento--correcto'
        );
    }
}

function limpiarMensajeFormularioIngresoRapido() {
    elementos.mensajeFormularioIngresoRapidoInventario.textContent = '';
    elementos.mensajeFormularioIngresoRapidoInventario.classList.remove(
        'mensaje-formulario-movimiento--correcto'
    );
}

function abrirModalIngresoRapidoInventario() {
    elementos.modalIngresoRapidoInventario.hidden = false;

    document.body.style.overflow = 'hidden';

    elementos.formularioIngresoRapidoInventario.reset();

    elementos.nombreProductoIngresoRapidoInventario.textContent = '—';
    elementos.codigoProductoIngresoRapidoInventario.textContent = '—';
    elementos.existenciaActualIngresoRapidoInventario.textContent = '—';

    estado.productoIngresoRapido = null;
    estado.productoBusquedaRapida = null;

    limpiarMensajeFormularioIngresoRapido();
    limpiarMensajeBusquedaIngresoRapido();

    window.setTimeout(() => {
        elementos.codigoIngresoRapidoInventario.focus();
    }, 80);
}

function cerrarModalIngresoRapidoInventario() {
    elementos.modalIngresoRapidoInventario.hidden = true;

    document.body.style.overflow = '';

    estado.productoIngresoRapido = null;

    limpiarMensajeFormularioIngresoRapido();
}

async function buscarProductoIngresoRapido(codigo) {
    const texto = textoSeguro(codigo);

    if (!texto) {
        throw new Error(
            'Ingrese un código interno o de barras para buscar el producto.'
        );
    }

    const codigoBuscado = texto.toUpperCase();

    const encontrado = estado.productos.find((producto) => {
        return (
            textoSeguro(producto.codigoInterno).toUpperCase() ===
                codigoBuscado ||
            textoSeguro(producto.codigoBarras).toUpperCase() ===
                codigoBuscado
        );
    });

    if (encontrado) {
        return {
            producto: encontrado,
            codigoSeleccionado: codigoBuscado
        };
    }

    const parametros = new URLSearchParams({
        busqueda: texto,
        estado: 'TODOS',
        pagina: '1',
        limite: '1'
    });

    const datos = await solicitarJson(
        `/api/inventario/productos?${parametros.toString()}`
    );

    if (!Array.isArray(datos.productos) || datos.productos.length === 0) {
        throw new Error(
            'No se encontró ningún producto con ese código.'
        );
    }

    return {
        producto: datos.productos[0],
        codigoSeleccionado: codigoBuscado
    };
}

function llenarPanelIngresoRapidoInventario(
    producto,
    codigoSeleccionado = null
) {
    estado.productoIngresoRapido = producto;

    elementos.nombreProductoIngresoRapidoInventario.textContent =
        producto.nombre || 'Producto';

    elementos.codigoProductoIngresoRapidoInventario.textContent =
        codigoSeleccionado ||
        producto.codigoInterno ||
        producto.codigoBarras ||
        'Sin código';

    elementos.existenciaActualIngresoRapidoInventario.textContent =
        formatearCantidadConUnidad(
            producto.existenciaDisponible,
            producto
        );

    elementos.cantidadIngresoRapidoInventario.value = '';

    limpiarMensajeFormularioIngresoRapido();
}

function obtenerDatosIngresoRapidoInventario() {
    const codigo = textoSeguro(
        elementos.codigoIngresoRapidoInventario.value
    );

    if (!codigo) {
        return {
            error:
                'Ingrese un código interno o un código de barras para buscar el producto.',
            campo: elementos.codigoIngresoRapidoInventario
        };
    }

    if (!estado.productoIngresoRapido?.id) {
        return {
            error:
                'Busque primero el producto antes de ingresar la cantidad.',
            campo: elementos.codigoIngresoRapidoInventario
        };
    }

    const tipoVenta = obtenerTipoVentaProducto(
        estado.productoIngresoRapido
    );

    const cantidad = normalizarCantidadSegunTipoVenta(
        elementos.cantidadIngresoRapidoInventario.value,
        tipoVenta,
        false
    );

    if (cantidad === null) {
        return {
            error:
                tipoVenta === TIPOS_VENTA_PRODUCTO.FRACCIONABLE
                    ? 'Ingrese una cantidad válida en kg y mayor que cero.'
                    : 'Ingrese una cantidad entera válida y mayor que cero.',
            campo: elementos.cantidadIngresoRapidoInventario
        };
    }

    return {
        datos: {
            modo: 'ENTRADA',
            cantidad,
            nota: 'Ingreso rápido desde inventario'
        }
    };
}

async function procesarBusquedaIngresoRapido() {
    const codigo = textoSeguro(
        elementos.codigoIngresoRapidoInventario.value
    );

    if (!codigo) {
        mostrarMensajeFormularioIngresoRapido(
            'Ingrese un código interno o de barras para buscar el producto.'
        );

        return;
    }

    try {
        const resultado = await buscarProductoIngresoRapido(codigo);

        llenarPanelIngresoRapidoInventario(
            resultado.producto,
            resultado.codigoSeleccionado
        );

        elementos.cantidadIngresoRapidoInventario.focus();
    } catch (error) {
        mostrarMensajeFormularioIngresoRapido(
            obtenerMensajeError(
                error,
                'No se encontró ningún producto con ese código.'
            )
        );
    }
}

function abrirModalBusquedaIngresoRapido() {
    elementos.modalBusquedaIngresoRapidoInventario.hidden = false;

    document.body.style.overflow = 'hidden';

    elementos.formularioBusquedaIngresoRapidoInventario.reset();
    elementos.listaResultadosBusquedaIngresoRapidoInventario.replaceChildren(
        crearElemento(
            'p',
            'Ingrese texto para ver resultados.',
            'lista-busqueda-ingreso-rapido__mensaje'
        )
    );
    elementos.mensajeBusquedaIngresoRapidoInventario.textContent = '';

    window.setTimeout(() => {
        elementos.busquedaIngresoRapidoInventario.focus();
    }, 80);
}

function cerrarModalBusquedaIngresoRapido() {
    elementos.modalBusquedaIngresoRapidoInventario.hidden = true;

    document.body.style.overflow = '';

    elementos.mensajeBusquedaIngresoRapidoInventario.textContent = '';

    if (!elementos.modalIngresoRapidoInventario.hidden) {
        elementos.codigoIngresoRapidoInventario.focus();
    }
}

function limpiarMensajeBusquedaIngresoRapido() {
    elementos.mensajeBusquedaIngresoRapidoInventario.textContent = '';
}

function mostrarMensajeBusquedaIngresoRapido(mensaje) {
    elementos.mensajeBusquedaIngresoRapidoInventario.textContent = mensaje;
}

async function buscarProductosIngresoRapidoPorNombre(texto) {
    const termino = textoSeguro(texto);

    if (!termino) {
        return [];
    }

    const parametros = new URLSearchParams({
        busqueda: termino,
        estado: 'TODOS',
        pagina: '1',
        limite: '10'
    });

    const datos = await solicitarJson(
        `/api/inventario/productos?${parametros.toString()}`
    );

    return Array.isArray(datos.productos)
        ? datos.productos
        : [];
}

function renderizarResultadosBusquedaIngresoRapido(productos) {
    elementos.listaResultadosBusquedaIngresoRapidoInventario.replaceChildren();

    if (productos.length === 0) {
        elementos.listaResultadosBusquedaIngresoRapidoInventario.appendChild(
            crearElemento(
                'p',
                'No se encontraron productos con esa búsqueda.',
                'lista-busqueda-ingreso-rapido__mensaje'
            )
        );

        return;
    }

    productos.forEach((producto) => {
        const item = crearElemento(
            'button',
            '',
            'resultado-busqueda-ingreso-rapido'
        );

        item.type = 'button';
        item.setAttribute('role', 'option');
        item.setAttribute('tabindex', '0');

        item.appendChild(
            crearElemento('strong', producto.nombre)
        );

        item.appendChild(
            crearElemento(
                'span',
                `${producto.codigoInterno || producto.codigoBarras || 'Sin código'} · ${producto.codigoBarras ? 'Código de barras' : 'Sin código de barras'}`
            )
        );

        item.addEventListener('click', () => {
            seleccionarProductoDesdeBusqueda(producto);
        });

        elementos.listaResultadosBusquedaIngresoRapidoInventario.appendChild(item);
    });
}

function seleccionarProductoDesdeBusqueda(producto) {
    cerrarModalBusquedaIngresoRapido();

    elementos.codigoIngresoRapidoInventario.value =
        producto.codigoInterno || producto.codigoBarras || '';

    llenarPanelIngresoRapidoInventario(producto);
    elementos.cantidadIngresoRapidoInventario.focus();
}

function escucharBusquedaIngresoRapido() {
    let temporizador = null;

    elementos.busquedaIngresoRapidoInventario.addEventListener(
        'input',
        () => {
            window.clearTimeout(temporizador);

            temporizador = window.setTimeout(async () => {
                const texto = elementos.busquedaIngresoRapidoInventario.value;

                if (!textoSeguro(texto)) {
                    renderizarResultadosBusquedaIngresoRapido([]);
                    return;
                }

                try {
                    const productos = await buscarProductosIngresoRapidoPorNombre(texto);

                    renderizarResultadosBusquedaIngresoRapido(productos);
                } catch (error) {
                    mostrarMensajeBusquedaIngresoRapido(
                        obtenerMensajeError(
                            error,
                            'No fue posible buscar productos.'
                        )
                    );
                }
            }, 260);
        }
    );
}

function agregarAtajoBusquedaIngresoRapido() {
    elementos.codigoIngresoRapidoInventario.addEventListener(
        'keydown',
        async (evento) => {
            if (evento.key === 'F2') {
                evento.preventDefault();
                abrirModalBusquedaIngresoRapido();
                return;
            }

            if (evento.key !== 'Enter') {
                return;
            }

            evento.preventDefault();

            await procesarBusquedaIngresoRapido();
        }
    );
}

async function guardarIngresoRapidoInventario(evento) {
    evento.preventDefault();

    limpiarMensajeFormularioIngresoRapido();

    if (!estado.productoIngresoRapido?.id) {
        await procesarBusquedaIngresoRapido();

        if (!estado.productoIngresoRapido?.id) {
            return;
        }
    }

    const resultado = obtenerDatosIngresoRapidoInventario();

    if (resultado.error) {
        mostrarMensajeFormularioIngresoRapido(resultado.error);

        resultado.campo?.focus();

        return;
    }

    const textoOriginal =
        elementos.botonGuardarIngresoRapidoInventario.textContent;

    elementos.botonGuardarIngresoRapidoInventario.disabled = true;

    elementos.botonGuardarIngresoRapidoInventario.textContent =
        'Guardando...';

    try {
        const datos = await solicitarJson(
            `/api/inventario/productos/${estado.productoIngresoRapido.id}/existencia`,
            {
                method: 'POST',

                headers: {
                    'Content-Type': 'application/json'
                },

                body: JSON.stringify(resultado.datos)
            }
        );

        mostrarMensajeFormularioIngresoRapido(
            datos.mensaje ||
            'Cantidad ingresada correctamente.',
            'correcto'
        );

        mostrarMensajeFlotante(
            datos.mensaje ||
            'Cantidad ingresada correctamente.',
            'correcto'
        );

        estado.productoIngresoRapido = null;

        elementos.formularioIngresoRapidoInventario.reset();
        elementos.nombreProductoIngresoRapidoInventario.textContent = '—';
        elementos.codigoProductoIngresoRapidoInventario.textContent = '—';
        elementos.existenciaActualIngresoRapidoInventario.textContent = '—';

        window.setTimeout(() => {
            elementos.codigoIngresoRapidoInventario.focus();
        }, 80);

        await Promise.all([
            cargarProductos(),
            cargarResumenInventario()
        ]);
    } catch (error) {
        mostrarMensajeFormularioIngresoRapido(
            obtenerMensajeError(
                error,
                'No fue posible ingresar la cantidad.'
            )
        );
    } finally {
        elementos.botonGuardarIngresoRapidoInventario.disabled = false;

        elementos.botonGuardarIngresoRapidoInventario.textContent =
            textoOriginal;
    }
}

/* =========================================================
   ACTIVAR / INACTIVAR
   ========================================================= */

function abrirModalConfirmarEstadoProducto(producto) {
    if (!producto?.id) {
        return;
    }

    const activar = producto.estado !== 'ACTIVO';

    estado.productoConfirmarEstado = producto;

    elementos.etiquetaPanelConfirmarEstadoProducto.textContent =
        activar
            ? 'Activación de producto'
            : 'Inactivar producto';

    elementos.tituloPanelConfirmarEstadoProducto.textContent =
        activar
            ? 'Activar producto'
            : 'Inactivar producto';

    elementos.nombreProductoConfirmarEstadoProducto.textContent =
        producto.nombre || 'Producto';

    elementos.codigoProductoConfirmarEstadoProducto.textContent =
        producto.codigoInterno || producto.codigoBarras || 'Sin código interno';

    elementos.textoConfirmacionEstadoProducto.textContent =
        activar
            ? `¿Deseas activar el producto “${producto.nombre}”? Podrá volver a venderse inmediatamente.`
            : `¿Deseas inactivar el producto “${producto.nombre}”? Dejará de estar disponible para ventas futuras.`;

    elementos.modalConfirmarEstadoProducto.classList.add(
        'modal-confirmacion-estado'
    );
    elementos.modalConfirmarEstadoProducto.hidden = false;
    document.body.style.overflow = 'hidden';
}

function cerrarModalConfirmarEstadoProducto() {
    elementos.modalConfirmarEstadoProducto.classList.remove(
        'modal-confirmacion-estado'
    );
    elementos.modalConfirmarEstadoProducto.hidden = true;
    document.body.style.overflow = '';
    estado.productoConfirmarEstado = null;
}

async function confirmarEstadoProducto() {
    if (!estado.productoConfirmarEstado) {
        cerrarModalConfirmarEstadoProducto();
        return;
    }

    const producto = estado.productoConfirmarEstado;

    cerrarModalConfirmarEstadoProducto();

    await cambiarEstadoProducto(producto);
}

async function cambiarEstadoProducto(producto) {
    const activar = producto.estado !== 'ACTIVO';

    const accion = activar
        ? 'activar'
        : 'inactivar';

    try {
        const datos = await solicitarJson(
            `/api/inventario/productos/${producto.id}/estado`,
            {
                method: 'PATCH',

                headers: {
                    'Content-Type': 'application/json'
                },

                body: JSON.stringify({
                    estado: activar
                        ? 'ACTIVO'
                        : 'INACTIVO'
                })
            }
        );

        mostrarMensajeFlotante(
            datos.mensaje ||
            `Producto ${accion}do correctamente.`,
            'correcto'
        );

        await Promise.all([
            cargarProductos(),
            cargarResumenInventario()
        ]);
    } catch (error) {
        mostrarMensajeFlotante(
            obtenerMensajeError(
                error,
                `No fue posible ${accion} el producto.`
            ),
            'error'
        );
    }
}

/* =========================================================
   NAVEGACIÓN Y SESIÓN
   ========================================================= */

function navegarModulo(modulo) {
    const rutasDisponibles = {
        'Panel principal': '/panel',
        Clientes: '/clientes',
        Inventario: '/inventario',
        Ventas: '/ventas',
        Reportes: '/reportes',
        Caja: '/caja',
        Usuarios: '/usuarios',
        Configuración: '/configuracion'
    };

    const ruta = rutasDisponibles[modulo];

    if (ruta) {
        window.location.assign(ruta);
        return;
    }

    mostrarMensajeFlotante(
        `${modulo} será construido en el siguiente bloque de Tenvik.`
    );
}

async function cerrarSesion() {
    const textoOriginal =
        elementos.botonCerrarSesion.textContent;

    elementos.botonCerrarSesion.disabled = true;

    elementos.botonCerrarSesion.textContent =
        'Cerrando...';

    try {
        await solicitarJson(
            '/api/sesion/cerrar',
            {
                method: 'POST'
            }
        );

        window.location.assign('/');
    } catch (error) {
        elementos.botonCerrarSesion.disabled = false;

        elementos.botonCerrarSesion.textContent =
            textoOriginal;

        mostrarMensajeFlotante(
            obtenerMensajeError(
                error,
                'No fue posible cerrar la sesión.'
            ),
            'error'
        );
    }
}

/* =========================================================
   EVENTOS
   ========================================================= */

function enlazarEventos() {
    document.querySelectorAll(
        '[data-modulo]'
    ).forEach((elemento) => {
        elemento.addEventListener('click', () => {
            navegarModulo(
                textoSeguro(elemento.dataset.modulo)
            );
        });
    });

    elementos.botonNuevoProducto.addEventListener(
        'click',
        prepararPanelNuevoProducto
    );

    elementos.botonCerrarPanelProducto.addEventListener(
        'click',
        cerrarModalProducto
    );

    elementos.botonCancelarProducto.addEventListener(
        'click',
        cerrarModalProducto
    );

    elementos.fondoModalProducto.addEventListener(
        'click',
        cerrarModalProducto
    );

    elementos.formularioProducto.addEventListener(
        'submit',
        guardarProducto
    );
    elementos.botonCerrarPanelMovimientoInventario.addEventListener(
        'click',
        cerrarModalMovimientoInventario
    );

    elementos.botonCancelarMovimientoInventario.addEventListener(
        'click',
        cerrarModalMovimientoInventario
    );

    elementos.fondoModalMovimientoInventario.addEventListener(
        'click',
        cerrarModalMovimientoInventario
    );

    elementos.formularioMovimientoInventario.addEventListener(
        'submit',
        guardarMovimientoInventario
    );

    elementos.botonCerrarPanelConfirmarEstadoProducto.addEventListener(
        'click',
        cerrarModalConfirmarEstadoProducto
    );

    elementos.botonCancelarConfirmarEstadoProducto.addEventListener(
        'click',
        cerrarModalConfirmarEstadoProducto
    );

    elementos.fondoModalConfirmarEstadoProducto.addEventListener(
        'click',
        cerrarModalConfirmarEstadoProducto
    );

    elementos.botonConfirmarEstadoProducto.addEventListener(
        'click',
        confirmarEstadoProducto
    );

    [
        elementos.modoMovimientoEntrada,
        elementos.modoMovimientoSalida,
        elementos.modoMovimientoReconteo
    ].forEach((control) => {
        control.addEventListener(
            'change',
            actualizarTextoModoMovimiento
        );
    });
    [
        elementos.tipoVentaUnidadProducto,
        elementos.tipoVentaFraccionableProducto
    ].forEach((control) => {
        control.addEventListener('change', () => {
            if (estado.productoEditando?.id) {
                return;
            }

            actualizarFormularioSegunTipoVenta();
        });
    });
    elementos.busquedaProductos.addEventListener(
        'input',
        () => {
            window.clearTimeout(
                estado.temporizadorBusqueda
            );

            estado.temporizadorBusqueda =
                window.setTimeout(() => {
                    estado.busqueda = textoSeguro(
                        elementos.busquedaProductos.value
                    );

                    estado.pagina = 1;

                    cargarProductos();
                }, 280);
        }
    );

    elementos.filtroEstadoProductos.addEventListener(
        'change',
        () => {
            estado.filtroEstado =
                elementos.filtroEstadoProductos.value;

            estado.filtroResumen = null;
            actualizarResumenSeleccionado();

            estado.pagina = 1;

            cargarProductos();
        }
    );

    elementos.botonLimpiarBusquedaProductos.addEventListener(
        'click',
        () => {
            elementos.busquedaProductos.value = '';

            estado.busqueda = '';
            estado.filtroResumen = null;
            actualizarResumenSeleccionado();
            estado.pagina = 1;

            cargarProductos();

            elementos.busquedaProductos.focus();
        }
    );

    elementos.botonIngresarCantidad.addEventListener(
        'click',
        abrirModalIngresoRapidoInventario
    );

    elementos.botonCerrarPanelIngresoRapidoInventario.addEventListener(
        'click',
        cerrarModalIngresoRapidoInventario
    );

    elementos.botonCancelarIngresoRapidoInventario.addEventListener(
        'click',
        cerrarModalIngresoRapidoInventario
    );

    elementos.fondoModalIngresoRapidoInventario.addEventListener(
        'click',
        cerrarModalIngresoRapidoInventario
    );

    elementos.formularioIngresoRapidoInventario.addEventListener(
        'submit',
        guardarIngresoRapidoInventario
    );

    elementos.codigoIngresoRapidoInventario.addEventListener(
        'keydown',
        async (evento) => {
            if (evento.key === 'F2') {
                evento.preventDefault();
                abrirModalBusquedaIngresoRapido();
                return;
            }

            if (evento.key !== 'Enter') {
                return;
            }

            evento.preventDefault();

            await procesarBusquedaIngresoRapido();
        }
    );

    elementos.botonCerrarPanelBusquedaIngresoRapidoInventario.addEventListener(
        'click',
        cerrarModalBusquedaIngresoRapido
    );

    elementos.botonCancelarBusquedaIngresoRapidoInventario.addEventListener(
        'click',
        cerrarModalBusquedaIngresoRapido
    );

    elementos.fondoModalBusquedaIngresoRapidoInventario.addEventListener(
        'click',
        cerrarModalBusquedaIngresoRapido
    );

    elementos.formularioBusquedaIngresoRapidoInventario.addEventListener(
        'submit',
        (evento) => {
            evento.preventDefault();
        }
    );

    escucharBusquedaIngresoRapido();

    const activarFiltroResumen = (filtro) => {
        estado.filtroResumen =
            estado.filtroResumen === filtro
                ? null
                : filtro;

        actualizarResumenSeleccionado();
        renderizarProductos(estado.productos);
    };

    elementos.tarjetaProductosActivos.addEventListener(
        'click',
        () => {
            activarFiltroResumen('ACTIVOS');
        }
    );

    elementos.tarjetaSinExistencia.addEventListener(
        'click',
        () => {
            activarFiltroResumen('SIN_EXISTENCIA');
        }
    );

    elementos.tarjetaStockMinimo.addEventListener(
        'click',
        () => {
            activarFiltroResumen('STOCK_MINIMO');
        }
    );

    elementos.tarjetaProductosActivos.addEventListener(
        'keydown',
        (evento) => {
            if (evento.key === 'Enter' || evento.key === ' ') {
                evento.preventDefault();
                activarFiltroResumen('ACTIVOS');
            }
        }
    );

    elementos.tarjetaSinExistencia.addEventListener(
        'keydown',
        (evento) => {
            if (evento.key === 'Enter' || evento.key === ' ') {
                evento.preventDefault();
                activarFiltroResumen('SIN_EXISTENCIA');
            }
        }
    );

    elementos.tarjetaStockMinimo.addEventListener(
        'keydown',
        (evento) => {
            if (evento.key === 'Enter' || evento.key === ' ') {
                evento.preventDefault();
                activarFiltroResumen('STOCK_MINIMO');
            }
        }
    );

    elementos.botonPaginaAnterior.addEventListener(
        'click',
        () => {
            if (estado.pagina <= 1) {
                return;
            }

            estado.pagina -= 1;

            cargarProductos();
        }
    );

    elementos.botonPaginaSiguiente.addEventListener(
        'click',
        () => {
            const totalPaginas = Number(
                estado.paginacion.totalPaginas || 1
            );

            if (estado.pagina >= totalPaginas) {
                return;
            }

            estado.pagina += 1;

            cargarProductos();
        }
    );

    elementos.botonCerrarSesion.addEventListener(
        'click',
        cerrarSesion
    );

    document.addEventListener(
        'keydown',
        (evento) => {
            if (evento.key !== 'Escape') {
                return;
            }

            if (!elementos.modalBusquedaIngresoRapidoInventario.hidden) {
                cerrarModalBusquedaIngresoRapido();
                return;
            }

            if (!elementos.modalIngresoRapidoInventario.hidden) {
                cerrarModalIngresoRapidoInventario();
                return;
            }

            if (!elementos.modalMovimientoInventario.hidden) {
                cerrarModalMovimientoInventario();
                return;
            }

            if (!elementos.modalProducto.hidden) {
                cerrarModalProducto();
            }
        }
    );
}

/* =========================================================
   INICIO
   ========================================================= */

async function iniciarInventario() {
    const filtroInicial = obtenerFiltroResumenDesdeUrl();
    if (filtroInicial) {
        estado.filtroResumen = filtroInicial;
    }

    const busquedaInicial = obtenerBusquedaDesdeUrl();
    if (busquedaInicial) {
        estado.busqueda = busquedaInicial;
        if (elementos.busquedaProductos) {
            elementos.busquedaProductos.value = busquedaInicial;
        }
    }

    const sesionIngresoInventario = sessionStorage.getItem('tenvik.focus.ingresoInventario');
    if (sesionIngresoInventario === 'true') {
        sessionStorage.removeItem('tenvik.focus.ingresoInventario');
        window.setTimeout(() => {
            abrirModalIngresoRapidoInventario();
        }, 120);
    }

    const sesionNuevoProductoInventario = sessionStorage.getItem('tenvik.focus.nuevoProductoInventario');
    if (sesionNuevoProductoInventario === 'true') {
        sessionStorage.removeItem('tenvik.focus.nuevoProductoInventario');
        window.setTimeout(() => {
            abrirModalProducto();
        }, 120);
    }

    enlazarEventos();
    actualizarFormularioSegunTipoVenta();
    actualizarResumenSeleccionado();
    await cargarContextoAplicacion();

    await Promise.all([
        cargarProductos(),
        cargarResumenInventario()
    ]);
}

iniciarInventario();