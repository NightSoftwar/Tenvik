'use strict';

const elementos = {
    nombreNegocioSuperior: document.getElementById(
        'nombreNegocioSuperior'
    ),

    estadoLicenciaSuperior: document.getElementById(
        'estadoLicenciaSuperior'
    ),

    estadoActualizacionSuperior: document.getElementById(
        'estadoActualizacionSuperior'
    ),

    avatarUsuarioLateral: document.getElementById(
        'avatarUsuarioLateral'
    ),

    nombreUsuarioLateral: document.getElementById(
        'nombreUsuarioLateral'
    ),

    rolUsuarioLateral: document.getElementById(
        'rolUsuarioLateral'
    ),

    botonCerrarSesion: document.getElementById(
        'botonCerrarSesion'
    ),

    botonNuevoCajero: document.getElementById(
        'botonNuevoCajero'
    ),

    busquedaUsuarios: document.getElementById(
        'busquedaUsuarios'
    ),

    filtroEstadoUsuarios: document.getElementById(
        'filtroEstadoUsuarios'
    ),

    botonLimpiarBusquedaUsuarios: document.getElementById(
        'botonLimpiarBusquedaUsuarios'
    ),

    cantidadUsuariosActivos: document.getElementById(
        'cantidadUsuariosActivos'
    ),

    cantidadCajerosActivos: document.getElementById(
        'cantidadCajerosActivos'
    ),

    cantidadUsuariosBloqueados: document.getElementById(
        'cantidadUsuariosBloqueados'
    ),

    resumenUsuarios: document.getElementById(
        'resumenUsuarios'
    ),

    cuerpoTablaUsuarios: document.getElementById(
        'cuerpoTablaUsuarios'
    ),

    modalUsuario: document.getElementById(
        'modalUsuario'
    ),

    fondoModalUsuario: document.getElementById(
        'fondoModalUsuario'
    ),

    etiquetaPanelUsuario: document.getElementById(
        'etiquetaPanelUsuario'
    ),

    tituloPanelUsuario: document.getElementById(
        'tituloPanelUsuario'
    ),

    botonCerrarPanelUsuario: document.getElementById(
        'botonCerrarPanelUsuario'
    ),

    botonCancelarUsuario: document.getElementById(
        'botonCancelarUsuario'
    ),

    formularioUsuario: document.getElementById(
        'formularioUsuario'
    ),

    nombreCompletoUsuario: document.getElementById(
        'nombreCompletoUsuario'
    ),

    nombreUsuario: document.getElementById(
        'nombreUsuario'
    ),

    correoUsuario: document.getElementById(
        'correoUsuario'
    ),

    bloqueContrasenaUsuario: document.getElementById(
        'bloqueContrasenaUsuario'
    ),

    bloqueConfirmarContrasenaUsuario: document.getElementById(
        'bloqueConfirmarContrasenaUsuario'
    ),

    contrasenaUsuario: document.getElementById(
        'contrasenaUsuario'
    ),

    confirmarContrasenaUsuario: document.getElementById(
        'confirmarContrasenaUsuario'
    ),

    detalleAuditoriaUsuario: document.getElementById(
        'detalleAuditoriaUsuario'
    ),

    mensajeFormularioUsuario: document.getElementById(
        'mensajeFormularioUsuario'
    ),

    botonGuardarUsuario: document.getElementById(
        'botonGuardarUsuario'
    ),

    modalContrasenaUsuario: document.getElementById(
        'modalContrasenaUsuario'
    ),

    fondoModalContrasenaUsuario: document.getElementById(
        'fondoModalContrasenaUsuario'
    ),

    botonCerrarPanelContrasenaUsuario:
        document.getElementById(
            'botonCerrarPanelContrasenaUsuario'
        ),

    botonCancelarContrasenaUsuario:
        document.getElementById(
            'botonCancelarContrasenaUsuario'
        ),

    formularioContrasenaUsuario: document.getElementById(
        'formularioContrasenaUsuario'
    ),

    descripcionContrasenaUsuario: document.getElementById(
        'descripcionContrasenaUsuario'
    ),

    nuevaContrasenaUsuario: document.getElementById(
        'nuevaContrasenaUsuario'
    ),

    confirmarNuevaContrasenaUsuario:
        document.getElementById(
            'confirmarNuevaContrasenaUsuario'
        ),

    mensajeFormularioContrasenaUsuario:
        document.getElementById(
            'mensajeFormularioContrasenaUsuario'
        ),

    botonGuardarContrasenaUsuario:
        document.getElementById(
            'botonGuardarContrasenaUsuario'
        ),

    mensajeFlotanteUsuarios: document.getElementById(
        'mensajeFlotanteUsuarios'
    )
};

const estadoVista = {
    busqueda: '',
    estado: 'TODOS',

    usuarioEditandoId: null,
    usuarioContrasenaId: null,

    usuariosTotales: [],
    usuariosVisibles: []
};

let temporizadorBusqueda = null;
let temporizadorMensaje = null;

/* =========================================================
   UTILIDADES
   ========================================================= */

function textoSeguro(valor) {
    return String(valor ?? '').trim();
}

function obtenerIniciales(nombreCompleto) {
    const palabras = textoSeguro(nombreCompleto)
        .split(/\s+/)
        .filter(Boolean);

    if (palabras.length === 0) {
        return 'TV';
    }

    return palabras
        .slice(0, 2)
        .map((palabra) => palabra.charAt(0))
        .join('')
        .toUpperCase();
}

function formatearRol(rol) {
    const roles = {
        PROPIETARIO: 'Propietario',
        CAJERO: 'Cajero'
    };

    return roles[rol] || 'Usuario';
}

function formatearFechaHora(valor) {
    if (!valor) {
        return 'Sin registro';
    }

    const fecha = new Date(valor);

    if (Number.isNaN(fecha.getTime())) {
        return 'Sin registro';
    }

    return new Intl.DateTimeFormat(
        'es-VE',
        {
            dateStyle: 'short',
            timeStyle: 'short'
        }
    ).format(fecha);
}

function obtenerFechaCorta(valor) {
    if (!valor) {
        return 'Sin registro';
    }

    const fecha = new Date(valor);

    if (Number.isNaN(fecha.getTime())) {
        return 'Sin registro';
    }

    return new Intl.DateTimeFormat(
        'es-VE',
        {
            dateStyle: 'short'
        }
    ).format(fecha);
}

function crearElemento(tag, texto = '') {
    const elemento = document.createElement(tag);

    if (texto) {
        elemento.textContent = texto;
    }

    return elemento;
}

function mostrarMensajeFlotante(
    mensaje,
    tipo = 'correcto'
) {
    window.clearTimeout(temporizadorMensaje);

    const esError = tipo === 'error';

    elementos.mensajeFlotanteUsuarios.textContent =
        mensaje;

    elementos.mensajeFlotanteUsuarios.style.color =
        esError ? '#991b1b' : '';

    elementos.mensajeFlotanteUsuarios.style.background =
        esError ? '#fef2f2' : '';

    elementos.mensajeFlotanteUsuarios.style.borderColor =
        esError ? '#fecaca' : '';

    elementos.mensajeFlotanteUsuarios.classList.add(
        'mensaje-flotante-usuarios--visible'
    );

    temporizadorMensaje = window.setTimeout(() => {
        elementos.mensajeFlotanteUsuarios.classList.remove(
            'mensaje-flotante-usuarios--visible'
        );

        elementos.mensajeFlotanteUsuarios.style.color = '';
        elementos.mensajeFlotanteUsuarios.style.background = '';
        elementos.mensajeFlotanteUsuarios.style.borderColor = '';
    }, 3800);
}

function mostrarMensajeFormulario(
    mensaje,
    correcto = false
) {
    elementos.mensajeFormularioUsuario.textContent =
        mensaje;

    elementos.mensajeFormularioUsuario.classList.toggle(
        'mensaje-formulario-usuario--correcto',
        correcto
    );
}

function limpiarMensajeFormulario() {
    elementos.mensajeFormularioUsuario.textContent = '';

    elementos.mensajeFormularioUsuario.classList.remove(
        'mensaje-formulario-usuario--correcto'
    );
}

function mostrarMensajeFormularioContrasena(
    mensaje,
    correcto = false
) {
    elementos.mensajeFormularioContrasenaUsuario.textContent =
        mensaje;

    elementos.mensajeFormularioContrasenaUsuario.classList.toggle(
        'mensaje-formulario-usuario--correcto',
        correcto
    );
}

function limpiarMensajeFormularioContrasena() {
    elementos.mensajeFormularioContrasenaUsuario.textContent =
        '';

    elementos.mensajeFormularioContrasenaUsuario.classList.remove(
        'mensaje-formulario-usuario--correcto'
    );
}

async function solicitarJSON(
    ruta,
    opciones = {}
) {
    const respuesta = await fetch(ruta, {
        cache: 'no-store',
        ...opciones
    });

    let resultado = null;

    try {
        resultado = await respuesta.json();
    } catch (error) {
        resultado = null;
    }

    if (!respuesta.ok || !resultado?.ok) {
        const mensaje =
            resultado?.mensaje ||
            'No fue posible completar la operación.';

        const error = new Error(mensaje);

        error.codigo = resultado?.codigo || null;

        throw error;
    }

    return resultado;
}

/* =========================================================
   CONTEXTO DE LA APLICACIÓN
   ========================================================= */

async function cargarContextoAplicacion() {
    try {
        const resultado = await solicitarJSON(
            '/api/aplicacion/estado'
        );

        const usuario = resultado.sesion?.usuario || null;

        const accesoDisponible =
            resultado.licencia?.activa === true &&
            resultado.negocio?.configurado === true &&
            usuario &&
            usuario.rol === 'PROPIETARIO';

        if (!accesoDisponible) {
            window.location.assign(
                resultado.destino || '/'
            );

            return false;
        }

        elementos.nombreNegocioSuperior.textContent =
            resultado.negocio?.nombreComercial ||
            'Mi negocio';

        elementos.nombreUsuarioLateral.textContent =
            usuario.nombreCompleto || 'Propietario';

        elementos.rolUsuarioLateral.textContent =
            formatearRol(usuario.rol);

        elementos.avatarUsuarioLateral.textContent =
            obtenerIniciales(usuario.nombreCompleto);

        elementos.estadoLicenciaSuperior.textContent =
            resultado.licencia?.estado === 'ACTIVA'
                ? 'Licencia activa'
                : 'Licencia no disponible';

        if (elementos.estadoActualizacionSuperior) {
            const disponible = Boolean(resultado?.actualizacion?.disponible);
            if (disponible) {
                elementos.estadoActualizacionSuperior.hidden = false;
                elementos.estadoActualizacionSuperior.classList.add('estado-actualizacion--visible');
                elementos.estadoActualizacionSuperior.classList.remove('estado-actualizacion--oculto');
            } else {
                elementos.estadoActualizacionSuperior.hidden = true;
                elementos.estadoActualizacionSuperior.classList.add('estado-actualizacion--oculto');
                elementos.estadoActualizacionSuperior.classList.remove('estado-actualizacion--visible');
            }
        }

        return true;
    } catch (error) {
        console.error(
            'Error cargando contexto de Usuarios:',
            error
        );

        mostrarMensajeFlotante(
            error.message ||
            'No fue posible preparar Usuarios.',
            'error'
        );

        return false;
    }
}

/* =========================================================
   LISTADO Y RESUMEN
   ========================================================= */

function actualizarResumenUsuarios(usuarios) {
    const lista = Array.isArray(usuarios)
        ? usuarios
        : [];

    const usuariosActivos = lista.filter(
        (usuario) => usuario.estado === 'ACTIVO'
    );

    const cajerosActivos = lista.filter(
        (usuario) =>
            usuario.estado === 'ACTIVO' &&
            usuario.rol === 'CAJERO'
    );

    const usuariosBloqueados = lista.filter(
        (usuario) => usuario.estado === 'BLOQUEADO'
    );

    elementos.cantidadUsuariosActivos.textContent =
        String(usuariosActivos.length);

    elementos.cantidadCajerosActivos.textContent =
        String(cajerosActivos.length);

    elementos.cantidadUsuariosBloqueados.textContent =
        String(usuariosBloqueados.length);
}

function crearInsigniaRol(rol) {
    const insignia = crearElemento(
        'span',
        formatearRol(rol)
    );

    insignia.className =
        `insignia-usuario ${rol === 'PROPIETARIO'
            ? 'insignia-usuario--propietario'
            : 'insignia-usuario--cajero'
        }`;

    return insignia;
}

function crearInsigniaEstado(estado) {
    const esActivo = estado === 'ACTIVO';

    const insignia = crearElemento(
        'span',
        esActivo ? 'Activo' : 'Bloqueado'
    );

    insignia.className =
        `insignia-usuario ${esActivo
            ? 'insignia-usuario--activo'
            : 'insignia-usuario--bloqueado'
        }`;

    return insignia;
}

function crearFilaUsuario(usuario) {
    const fila = document.createElement('tr');

    const celdaUsuario = document.createElement('td');

    const bloqueUsuario = crearElemento('div');

    bloqueUsuario.className = 'usuario-tabla';

    const avatar = crearElemento(
        'span',
        obtenerIniciales(usuario.nombreCompleto)
    );

    avatar.className = 'usuario-tabla__avatar';

    const datosUsuario = crearElemento('div');

    datosUsuario.className = 'usuario-tabla__datos';

    const nombre = crearElemento(
        'strong',
        usuario.nombreCompleto || 'Sin nombre'
    );

    const identificador = crearElemento(
        'span',
        `@${usuario.usuario || 'sin-usuario'}`
    );

    datosUsuario.append(nombre, identificador);
    bloqueUsuario.append(avatar, datosUsuario);
    celdaUsuario.appendChild(bloqueUsuario);

    const celdaAcceso = document.createElement('td');

    const bloqueAcceso = crearElemento('div');

    bloqueAcceso.className = 'acceso-usuario-tabla';

    const usuarioAcceso = crearElemento(
        'span',
        usuario.usuario || '—'
    );

    const correo = crearElemento(
        'span',
        usuario.correo || 'Sin correo'
    );

    bloqueAcceso.append(usuarioAcceso, correo);
    celdaAcceso.appendChild(bloqueAcceso);

    const celdaRol = document.createElement('td');

    celdaRol.appendChild(
        crearInsigniaRol(usuario.rol)
    );

    const celdaEstado = document.createElement('td');

    celdaEstado.appendChild(
        crearInsigniaEstado(usuario.estado)
    );

    const celdaUltimoAcceso = document.createElement('td');

    const bloqueUltimoAcceso = crearElemento('div');

    bloqueUltimoAcceso.className =
        'ultimo-acceso-usuario';

    const textoUltimoAcceso = crearElemento(
        'span',
        usuario.ultimoAccesoEn
            ? obtenerFechaCorta(usuario.ultimoAccesoEn)
            : 'Sin acceso'
    );

    const detalleUltimoAcceso = crearElemento(
        'span',
        usuario.ultimoAccesoEn
            ? formatearFechaHora(usuario.ultimoAccesoEn)
            : 'Todavía no ha iniciado sesión'
    );

    bloqueUltimoAcceso.append(
        textoUltimoAcceso,
        detalleUltimoAcceso
    );

    celdaUltimoAcceso.appendChild(
        bloqueUltimoAcceso
    );

    const celdaAcciones = document.createElement('td');

    const acciones = crearElemento('div');

    acciones.className = 'acciones-usuario-tabla';

    if (usuario.rol === 'PROPIETARIO') {
        const protegido = crearElemento(
            'span',
            'Cuenta protegida'
        );

        protegido.className = 'insignia-usuario';

        protegido.style.color = '#64748b';
        protegido.style.background = '#f1f5f9';

        acciones.appendChild(protegido);
    } else {
        const botonEditar = crearElemento(
            'button',
            'Editar'
        );

        botonEditar.type = 'button';
        botonEditar.className = 'boton-accion-usuario';

        botonEditar.addEventListener('click', () => {
            abrirEdicionCajero(usuario.id);
        });

        const botonContrasena = crearElemento(
            'button',
            'Contraseña'
        );

        botonContrasena.type = 'button';

        botonContrasena.className =
            'boton-accion-usuario boton-accion-usuario--contrasena';

        botonContrasena.addEventListener('click', () => {
            abrirRestablecimientoContrasena(usuario);
        });

        const botonEstado = crearElemento(
            'button',
            usuario.estado === 'ACTIVO'
                ? 'Bloquear'
                : 'Reactivar'
        );

        botonEstado.type = 'button';

        botonEstado.className =
            usuario.estado === 'ACTIVO'
                ? 'boton-accion-usuario boton-accion-usuario--bloquear'
                : 'boton-accion-usuario boton-accion-usuario--reactivar';

        botonEstado.addEventListener('click', () => {
            if (usuario.estado === 'ACTIVO') {
                bloquearCajero(usuario);
                return;
            }

            reactivarCajero(usuario);
        });

        acciones.append(
            botonEditar,
            botonContrasena,
            botonEstado
        );
    }

    celdaAcciones.appendChild(acciones);

    fila.append(
        celdaUsuario,
        celdaAcceso,
        celdaRol,
        celdaEstado,
        celdaUltimoAcceso,
        celdaAcciones
    );

    return fila;
}

function renderizarUsuarios(usuarios) {
    elementos.cuerpoTablaUsuarios.replaceChildren();

    if (!Array.isArray(usuarios) || usuarios.length === 0) {
        const fila = document.createElement('tr');

        const celda = document.createElement('td');

        celda.colSpan = 6;
        celda.className = 'tabla-usuarios__vacio';

        celda.textContent = estadoVista.busqueda
            ? 'No se encontraron usuarios con esta búsqueda.'
            : 'Todavía no hay cajeros registrados. Use “Nuevo cajero” para crear el primero.';

        fila.appendChild(celda);

        elementos.cuerpoTablaUsuarios.appendChild(
            fila
        );

        return;
    }

    for (const usuario of usuarios) {
        elementos.cuerpoTablaUsuarios.appendChild(
            crearFilaUsuario(usuario)
        );
    }
}

function actualizarTextoResumenListado(usuarios) {
    const cantidad = Array.isArray(usuarios)
        ? usuarios.length
        : 0;

    elementos.resumenUsuarios.textContent =
        cantidad === 1
            ? '1 usuario encontrado.'
            : `${cantidad} usuarios encontrados.`;
}

async function cargarUsuarios() {
    try {
        elementos.resumenUsuarios.textContent =
            'Consultando usuarios...';

        const parametrosListado = new URLSearchParams({
            busqueda: estadoVista.busqueda,
            estado: estadoVista.estado
        });

        const [resultadoTotal, resultadoListado] =
            await Promise.all([
                solicitarJSON(
                    '/api/usuarios?estado=TODOS'
                ),

                solicitarJSON(
                    `/api/usuarios?${parametrosListado.toString()}`
                )
            ]);

        estadoVista.usuariosTotales =
            resultadoTotal.usuarios || [];

        estadoVista.usuariosVisibles =
            resultadoListado.usuarios || [];

        actualizarResumenUsuarios(
            estadoVista.usuariosTotales
        );

        renderizarUsuarios(
            estadoVista.usuariosVisibles
        );

        actualizarTextoResumenListado(
            estadoVista.usuariosVisibles
        );
    } catch (error) {
        console.error(
            'Error cargando usuarios:',
            error
        );

        elementos.cuerpoTablaUsuarios.replaceChildren();

        const fila = document.createElement('tr');

        const celda = document.createElement('td');

        celda.colSpan = 6;
        celda.className = 'tabla-usuarios__vacio';

        celda.textContent =
            error.message ||
            'No fue posible cargar los usuarios.';

        fila.appendChild(celda);

        elementos.cuerpoTablaUsuarios.appendChild(
            fila
        );

        elementos.resumenUsuarios.textContent =
            'Error consultando usuarios.';

        mostrarMensajeFlotante(
            error.message ||
            'No fue posible cargar los usuarios.',
            'error'
        );
    }
}

/* =========================================================
   PANEL DE CREAR / EDITAR CAJERO
   ========================================================= */

function actualizarVisibilidadContrasenas(
    mostrar
) {
    elementos.bloqueContrasenaUsuario.hidden =
        !mostrar;

    elementos.bloqueConfirmarContrasenaUsuario.hidden =
        !mostrar;

    elementos.contrasenaUsuario.required = mostrar;

    elementos.confirmarContrasenaUsuario.required =
        mostrar;

    if (!mostrar) {
        elementos.contrasenaUsuario.value = '';
        elementos.confirmarContrasenaUsuario.value = '';
    }
}

function limpiarFormularioUsuario() {
    estadoVista.usuarioEditandoId = null;

    elementos.formularioUsuario.reset();

    elementos.etiquetaPanelUsuario.textContent =
        'Nuevo acceso';

    elementos.tituloPanelUsuario.textContent =
        'Registrar cajero';

    elementos.botonGuardarUsuario.textContent =
        'Crear cajero';

    elementos.detalleAuditoriaUsuario.hidden = true;
    elementos.detalleAuditoriaUsuario.textContent = '';

    actualizarVisibilidadContrasenas(true);

    limpiarMensajeFormulario();
}

function abrirNuevoCajero() {
    limpiarFormularioUsuario();

    elementos.modalUsuario.hidden = false;

    window.setTimeout(() => {
        elementos.nombreCompletoUsuario.focus();
    }, 40);
}

function cerrarPanelUsuario() {
    elementos.modalUsuario.hidden = true;

    limpiarMensajeFormulario();
}

function construirTextoAuditoria(usuario) {
    const partes = [];

    if (usuario.creadoPorNombre) {
        partes.push(
            `Creado por ${usuario.creadoPorNombre} el ${formatearFechaHora(
                usuario.creadoEn
            )}.`
        );
    } else {
        partes.push(
            `Cuenta creada durante la configuración inicial el ${formatearFechaHora(
                usuario.creadoEn
            )}.`
        );
    }

    if (usuario.actualizadoPorNombre) {
        partes.push(
            `Última modificación por ${usuario.actualizadoPorNombre} el ${formatearFechaHora(
                usuario.actualizadoEn
            )}.`
        );
    }

    if (usuario.bloqueadoEn) {
        const bloqueador =
            usuario.bloqueadoPorNombre ||
            'un usuario autorizado';

        const motivo = usuario.motivoBloqueo
            ? ` Motivo: ${usuario.motivoBloqueo}.`
            : '';

        partes.push(
            `Último bloqueo por ${bloqueador} el ${formatearFechaHora(
                usuario.bloqueadoEn
            )}.${motivo}`
        );
    }

    return partes.join(' ');
}

function rellenarFormularioEdicion(usuario) {
    estadoVista.usuarioEditandoId = Number(usuario.id);

    elementos.nombreCompletoUsuario.value =
        usuario.nombreCompleto || '';

    elementos.nombreUsuario.value =
        usuario.usuario || '';

    elementos.correoUsuario.value =
        usuario.correo || '';

    elementos.etiquetaPanelUsuario.textContent =
        'Edición de acceso';

    elementos.tituloPanelUsuario.textContent =
        'Editar cajero';

    elementos.botonGuardarUsuario.textContent =
        'Guardar cambios';

    actualizarVisibilidadContrasenas(false);

    elementos.detalleAuditoriaUsuario.textContent =
        construirTextoAuditoria(usuario);

    elementos.detalleAuditoriaUsuario.hidden = false;

    limpiarMensajeFormulario();

    elementos.modalUsuario.hidden = false;

    window.setTimeout(() => {
        elementos.nombreCompletoUsuario.focus();
    }, 40);
}

async function abrirEdicionCajero(usuarioId) {
    try {
        const resultado = await solicitarJSON(
            `/api/usuarios/${encodeURIComponent(
                usuarioId
            )}`
        );

        rellenarFormularioEdicion(resultado.usuario);
    } catch (error) {
        console.error(
            'Error consultando cajero:',
            error
        );

        mostrarMensajeFlotante(
            error.message ||
            'No fue posible abrir el cajero.',
            'error'
        );
    }
}

function construirDatosUsuario() {
    return {
        nombreCompleto: textoSeguro(
            elementos.nombreCompletoUsuario.value
        ),

        usuario: textoSeguro(
            elementos.nombreUsuario.value
        ).toLowerCase(),

        correo: textoSeguro(
            elementos.correoUsuario.value
        ).toLowerCase(),

        contrasena: String(
            elementos.contrasenaUsuario.value || ''
        ),

        confirmarContrasena: String(
            elementos.confirmarContrasenaUsuario.value || ''
        )
    };
}

function validarFormularioUsuario(
    datos,
    creando
) {
    if (datos.nombreCompleto.length < 2) {
        throw new Error(
            'Ingrese un nombre completo de al menos 2 caracteres.'
        );
    }

    if (datos.usuario.length < 3) {
        throw new Error(
            'El usuario de acceso debe tener al menos 3 caracteres.'
        );
    }

    if (creando) {
        if (datos.contrasena.length < 8) {
            throw new Error(
                'La contraseña inicial debe tener al menos 8 caracteres.'
            );
        }

        if (
            datos.contrasena !==
            datos.confirmarContrasena
        ) {
            throw new Error(
                'Las contraseñas no coinciden.'
            );
        }
    }
}

async function guardarUsuario(evento) {
    evento.preventDefault();

    limpiarMensajeFormulario();

    const editando = Number.isInteger(
        estadoVista.usuarioEditandoId
    );

    const datos = construirDatosUsuario();

    try {
        validarFormularioUsuario(datos, !editando);
    } catch (error) {
        mostrarMensajeFormulario(error.message);

        return;
    }

    const ruta = editando
        ? `/api/usuarios/${estadoVista.usuarioEditandoId}`
        : '/api/usuarios/cajeros';

    const metodo = editando ? 'PUT' : 'POST';

    const textoOriginal =
        elementos.botonGuardarUsuario.textContent;

    try {
        elementos.botonGuardarUsuario.disabled = true;

        elementos.botonGuardarUsuario.textContent =
            editando
                ? 'Guardando cambios...'
                : 'Creando cajero...';

        const cuerpo = editando
            ? {
                nombreCompleto: datos.nombreCompleto,
                usuario: datos.usuario,
                correo: datos.correo
            }
            : datos;

        const resultado = await solicitarJSON(
            ruta,
            {
                method: metodo,

                headers: {
                    'Content-Type':
                        'application/json'
                },

                body: JSON.stringify(cuerpo)
            }
        );

        await cargarUsuarios();

        cerrarPanelUsuario();

        mostrarMensajeFlotante(
            resultado.mensaje ||
            'Usuario guardado correctamente.'
        );
    } catch (error) {
        console.error(
            'Error guardando usuario:',
            error
        );

        mostrarMensajeFormulario(
            error.message ||
            'No fue posible guardar el usuario.'
        );
    } finally {
        elementos.botonGuardarUsuario.disabled = false;

        elementos.botonGuardarUsuario.textContent =
            textoOriginal;
    }
}

/* =========================================================
   RESTABLECIMIENTO DE CONTRASEÑA
   ========================================================= */

function abrirRestablecimientoContrasena(usuario) {
    estadoVista.usuarioContrasenaId = Number(usuario.id);

    elementos.formularioContrasenaUsuario.reset();

    limpiarMensajeFormularioContrasena();

    elementos.descripcionContrasenaUsuario.textContent =
        `Asignará una nueva contraseña para ${usuario.nombreCompleto}.`;

    elementos.modalContrasenaUsuario.hidden = false;

    window.setTimeout(() => {
        elementos.nuevaContrasenaUsuario.focus();
    }, 40);
}

function cerrarPanelContrasena() {
    elementos.modalContrasenaUsuario.hidden = true;

    estadoVista.usuarioContrasenaId = null;

    limpiarMensajeFormularioContrasena();
}

async function guardarNuevaContrasena(evento) {
    evento.preventDefault();

    limpiarMensajeFormularioContrasena();

    const cajeroId = estadoVista.usuarioContrasenaId;

    const contrasena = String(
        elementos.nuevaContrasenaUsuario.value || ''
    );

    const confirmarContrasena = String(
        elementos.confirmarNuevaContrasenaUsuario.value ||
        ''
    );

    if (!Number.isInteger(cajeroId)) {
        mostrarMensajeFormularioContrasena(
            'No fue posible identificar al cajero.'
        );

        return;
    }

    if (contrasena.length < 8) {
        mostrarMensajeFormularioContrasena(
            'La nueva contraseña debe tener al menos 8 caracteres.'
        );

        return;
    }

    if (contrasena !== confirmarContrasena) {
        mostrarMensajeFormularioContrasena(
            'Las contraseñas no coinciden.'
        );

        return;
    }

    const textoOriginal =
        elementos.botonGuardarContrasenaUsuario.textContent;

    try {
        elementos.botonGuardarContrasenaUsuario.disabled =
            true;

        elementos.botonGuardarContrasenaUsuario.textContent =
            'Restableciendo...';

        const resultado = await solicitarJSON(
            `/api/usuarios/${encodeURIComponent(
                cajeroId
            )}/contrasena`,
            {
                method: 'PATCH',

                headers: {
                    'Content-Type':
                        'application/json'
                },

                body: JSON.stringify({
                    contrasena,
                    confirmarContrasena
                })
            }
        );

        await cargarUsuarios();

        cerrarPanelContrasena();

        mostrarMensajeFlotante(
            resultado.mensaje ||
            'Contraseña restablecida correctamente.'
        );
    } catch (error) {
        console.error(
            'Error restableciendo contraseña:',
            error
        );

        mostrarMensajeFormularioContrasena(
            error.message ||
            'No fue posible restablecer la contraseña.'
        );
    } finally {
        elementos.botonGuardarContrasenaUsuario.disabled =
            false;

        elementos.botonGuardarContrasenaUsuario.textContent =
            textoOriginal;
    }
}

/* =========================================================
   BLOQUEO Y REACTIVACIÓN
   ========================================================= */

async function bloquearCajero(usuario) {
    const confirmado = window.confirm(
        `¿Desea bloquear a ${usuario.nombreCompleto}? Sus sesiones activas se cerrarán inmediatamente.`
    );

    if (!confirmado) {
        return;
    }

    const motivoIngresado = window.prompt(
        'Motivo del bloqueo (opcional):',
        ''
    );

    const motivoBloqueo = textoSeguro(
        motivoIngresado
    );

    try {
        const resultado = await solicitarJSON(
            `/api/usuarios/${encodeURIComponent(
                usuario.id
            )}/bloqueo`,
            {
                method: 'PATCH',

                headers: {
                    'Content-Type':
                        'application/json'
                },

                body: JSON.stringify({
                    motivoBloqueo
                })
            }
        );

        await cargarUsuarios();

        mostrarMensajeFlotante(
            resultado.mensaje ||
            'Cajero bloqueado correctamente.'
        );
    } catch (error) {
        console.error(
            'Error bloqueando cajero:',
            error
        );

        mostrarMensajeFlotante(
            error.message ||
            'No fue posible bloquear el cajero.',
            'error'
        );
    }
}

async function reactivarCajero(usuario) {
    const confirmado = window.confirm(
        `¿Desea reactivar a ${usuario.nombreCompleto}? Podrá iniciar sesión nuevamente con sus credenciales.`
    );

    if (!confirmado) {
        return;
    }

    try {
        const resultado = await solicitarJSON(
            `/api/usuarios/${encodeURIComponent(
                usuario.id
            )}/reactivacion`,
            {
                method: 'PATCH',

                headers: {
                    'Content-Type':
                        'application/json'
                }
            }
        );

        await cargarUsuarios();

        mostrarMensajeFlotante(
            resultado.mensaje ||
            'Cajero reactivado correctamente.'
        );
    } catch (error) {
        console.error(
            'Error reactivando cajero:',
            error
        );

        mostrarMensajeFlotante(
            error.message ||
            'No fue posible reactivar el cajero.',
            'error'
        );
    }
}

/* =========================================================
   SESIÓN
   ========================================================= */

async function cerrarSesion() {
    const textoOriginal =
        elementos.botonCerrarSesion.textContent;

    try {
        elementos.botonCerrarSesion.disabled = true;

        elementos.botonCerrarSesion.textContent =
            'Cerrando...';

        const resultado = await solicitarJSON(
            '/api/autenticacion/cerrar-sesion',
            {
                method: 'POST',

                headers: {
                    'Content-Type':
                        'application/json'
                }
            }
        );

        window.location.assign(
            resultado.redireccion ||
            '/iniciar-sesion'
        );
    } catch (error) {
        console.error(
            'Error cerrando sesión:',
            error
        );

        window.location.assign('/iniciar-sesion');
    } finally {
        elementos.botonCerrarSesion.disabled = false;

        elementos.botonCerrarSesion.textContent =
            textoOriginal;
    }
}

/* =========================================================
   EVENTOS
   ========================================================= */

function programarBusqueda() {
    window.clearTimeout(temporizadorBusqueda);

    temporizadorBusqueda = window.setTimeout(() => {
        estadoVista.busqueda = textoSeguro(
            elementos.busquedaUsuarios.value
        );

        cargarUsuarios();
    }, 280);
}

function navegarModulo(modulo) {
    const rutasDisponibles = {
        'Panel principal': '/panel',
        Clientes: '/clientes',
        Inventario: '/inventario',
        Ventas: '/ventas',
        Reportes: '/reportes',
        Caja: '/caja',
        Usuarios: '/usuarios',
        Configuración: '/configuracion'
    };
    const ruta = rutasDisponibles[modulo];

    if (ruta) {
        window.location.assign(ruta);
        return;
    }

    mostrarMensajeFlotante(
        `${modulo} será construido en el siguiente bloque de Tenvik.`
    );
}

document.querySelectorAll(
    '[data-modulo]'
).forEach((elemento) => {
    elemento.addEventListener('click', () => {
        navegarModulo(
            textoSeguro(elemento.dataset.modulo)
        );
    });
});

elementos.botonNuevoCajero.addEventListener(
    'click',
    abrirNuevoCajero
);

elementos.botonCerrarPanelUsuario.addEventListener(
    'click',
    cerrarPanelUsuario
);

elementos.botonCancelarUsuario.addEventListener(
    'click',
    cerrarPanelUsuario
);

elementos.fondoModalUsuario.addEventListener(
    'click',
    cerrarPanelUsuario
);

elementos.formularioUsuario.addEventListener(
    'submit',
    guardarUsuario
);

elementos.nombreUsuario.addEventListener(
    'input',
    () => {
        elementos.nombreUsuario.value =
            elementos.nombreUsuario.value
                .toLowerCase()
                .replace(/\s+/g, '');
    }
);

elementos.busquedaUsuarios.addEventListener(
    'input',
    programarBusqueda
);

elementos.filtroEstadoUsuarios.addEventListener(
    'change',
    () => {
        estadoVista.estado =
            elementos.filtroEstadoUsuarios.value;

        cargarUsuarios();
    }
);

elementos.botonLimpiarBusquedaUsuarios.addEventListener(
    'click',
    () => {
        elementos.busquedaUsuarios.value = '';

        estadoVista.busqueda = '';

        cargarUsuarios();

        elementos.busquedaUsuarios.focus();
    }
);

elementos.botonCerrarPanelContrasenaUsuario.addEventListener(
    'click',
    cerrarPanelContrasena
);

elementos.botonCancelarContrasenaUsuario.addEventListener(
    'click',
    cerrarPanelContrasena
);

elementos.fondoModalContrasenaUsuario.addEventListener(
    'click',
    cerrarPanelContrasena
);

elementos.formularioContrasenaUsuario.addEventListener(
    'submit',
    guardarNuevaContrasena
);

elementos.botonCerrarSesion.addEventListener(
    'click',
    cerrarSesion
);

document.addEventListener('keydown', (evento) => {
    if (evento.key !== 'Escape') {
        return;
    }

    if (!elementos.modalContrasenaUsuario.hidden) {
        cerrarPanelContrasena();

        return;
    }

    if (!elementos.modalUsuario.hidden) {
        cerrarPanelUsuario();
    }
});

if (elementos.estadoActualizacionSuperior) {
    elementos.estadoActualizacionSuperior.addEventListener(
        'click',
        () => {
            sessionStorage.setItem(
                'tenvik.focus.actualizacion',
                'true'
            );
        }
    );
}

/* =========================================================
   INICIO
   ========================================================= */

async function iniciarUsuarios() {
    const tieneAcceso =
        await cargarContextoAplicacion();

    if (!tieneAcceso) {
        return;
    }

    await cargarUsuarios();

    const sesionNuevoCajero = sessionStorage.getItem('tenvik.focus.nuevoCajero');
    if (sesionNuevoCajero === 'true') {
        sessionStorage.removeItem('tenvik.focus.nuevoCajero');
        window.setTimeout(() => {
            abrirNuevoCajero();
        }, 120);
    }
}

iniciarUsuarios();