'use strict';

const elementos = {
    nombreNegocioSuperior: document.getElementById(
        'nombreNegocioSuperior'
    ),

    estadoLicenciaSuperior: document.getElementById(
        'estadoLicenciaSuperior'
    ),

    estadoActualizacionSuperior: document.getElementById(
        'estadoActualizacionSuperior'
    ),

    avatarUsuarioLateral: document.getElementById(
        'avatarUsuarioLateral'
    ),

    nombreUsuarioLateral: document.getElementById(
        'nombreUsuarioLateral'
    ),

    rolUsuarioLateral: document.getElementById(
        'rolUsuarioLateral'
    ),

    botonCerrarSesion: document.getElementById(
        'botonCerrarSesion'
    ),

    monedaBaseCabecera: document.getElementById(
        'monedaBaseCabecera'
    ),

    valorTasaVigente: document.getElementById(
        'valorTasaVigente'
    ),

    detalleTasaVigente: document.getElementById(
        'detalleTasaVigente'
    ),

    estadoIvaResumen: document.getElementById(
        'estadoIvaResumen'
    ),

    cantidadCajasActivas: document.getElementById(
        'cantidadCajasActivas'
    ),

    formularioTasa: document.getElementById(
        'formularioTasa'
    ),

    valorNuevaTasa: document.getElementById(
        'valorNuevaTasa'
    ),

    notaNuevaTasa: document.getElementById(
        'notaNuevaTasa'
    ),

    mensajeFormularioTasa: document.getElementById(
        'mensajeFormularioTasa'
    ),

    botonGuardarTasa: document.getElementById(
        'botonGuardarTasa'
    ),

    formularioConfiguracionFinanciera:
        document.getElementById(
            'formularioConfiguracionFinanciera'
        ),

    preciosIncluyenIva: document.getElementById(
        'preciosIncluyenIva'
    ),
    ivaPorcentajeGlobal: document.getElementById(
        'ivaPorcentajeGlobal'
    ),
    decimalesUsd: document.getElementById(
        'decimalesUsd'
    ),

    decimalesVes: document.getElementById(
        'decimalesVes'
    ),

    mensajeFormularioConfiguracion:
        document.getElementById(
            'mensajeFormularioConfiguracion'
        ),

    botonGuardarConfiguracion: document.getElementById(
        'botonGuardarConfiguracion'
    ),
    formularioImpresion: document.getElementById(
        'formularioImpresion'
    ),

    estadoImpresionConfiguracion: document.getElementById(
        'estadoImpresionConfiguracion'
    ),

    impresionHabilitada: document.getElementById(
        'impresionHabilitada'
    ),

    formatoPapelImpresion: document.getElementById(
        'formatoPapelImpresion'
    ),

    modoImpresion: document.getElementById(
        'modoImpresion'
    ),

    puertoSerialImpresion: document.getElementById(
        'puertoSerialImpresion'
    ),

    baudRateImpresion: document.getElementById(
        'baudRateImpresion'
    ),

    copiasVentaImpresion: document.getElementById(
        'copiasVentaImpresion'
    ),

    copiasReimpresion: document.getElementById(
        'copiasReimpresion'
    ),

    lineasAvanceFinal: document.getElementById(
        'lineasAvanceFinal'
    ),

    tituloComprobanteImpresion: document.getElementById(
        'tituloComprobanteImpresion'
    ),

    nombreImpresoraWindows: document.getElementById(
        'nombreImpresoraWindows'
    ),

    cortarPapelImpresion: document.getElementById(
        'cortarPapelImpresion'
    ),

    mostrarLogoTextoImpresion: document.getElementById(
        'mostrarLogoTextoImpresion'
    ),

    mensajeFormularioImpresion: document.getElementById(
        'mensajeFormularioImpresion'
    ),

    botonGuardarImpresion: document.getElementById(
        'botonGuardarImpresion'
    ),

    botonProbarImpresion: document.getElementById(
        'botonProbarImpresion'
    ),
    versionActualSistema: document.getElementById(
        'versionActualSistema'
    ),
    versionRemotaSistema: document.getElementById(
        'versionRemotaSistema'
    ),
    estadoActualizacionSistema: document.getElementById(
        'estadoActualizacionSistema'
    ),
    notasActualizacionSistema: document.getElementById(
        'notasActualizacionSistema'
    ),
    mensajeActualizacionSistema: document.getElementById(
        'mensajeActualizacionSistema'
    ),
    botonBuscarActualizacion: document.getElementById(
        'botonBuscarActualizacion'
    ),
    botonAplicarActualizacion: document.getElementById(
        'botonAplicarActualizacion'
    ),
    modalActualizacion: document.getElementById(
        'modalActualizacion'
    ),
    modalConfirmarActualizacion: document.getElementById(
        'modalConfirmarActualizacion'
    ),
    botonCancelarConfirmacionActualizacion: document.getElementById(
        'botonCancelarConfirmacionActualizacion'
    ),
    botonConfirmarAplicarActualizacion: document.getElementById(
        'botonConfirmarAplicarActualizacion'
    ),
    modalActualizacionMensaje: document.getElementById(
        'modalActualizacionMensaje'
    ),
    modalActualizacionProgreso: document.getElementById(
        'modalActualizacionProgreso'
    ),
    cantidadMetodosPago: document.getElementById(
        'cantidadMetodosPago'
    ),

    listaMetodosPago: document.getElementById(
        'listaMetodosPago'
    ),

    cantidadCajasFisicas: document.getElementById(
        'cantidadCajasFisicas'
    ),

    listaCajasFisicas: document.getElementById(
        'listaCajasFisicas'
    ),

    /* Importar licencia desde Configuración */
    archivoLicenciaConfiguracion: document.getElementById('archivoLicenciaConfiguracion'),
    botonImportarLicenciaConfiguracion: document.getElementById('botonImportarLicenciaConfiguracion'),
    nombreArchivoLicenciaConfiguracion: document.getElementById('nombreArchivoLicenciaConfiguracion'),
    mensajeImportacionLicenciaConfiguracion: document.getElementById('mensajeImportacionLicenciaConfiguracion'),
    diasRestantesLicencia: document.getElementById('diasRestantesLicencia'),
    detalleAplicacionLicencia: document.getElementById('detalleAplicacionLicencia'),

    cuerpoTablaTasas: document.getElementById(
        'cuerpoTablaTasas'
    ),

    mensajeFlotanteConfiguracion: document.getElementById(
        'mensajeFlotanteConfiguracion'
    ),
    estadoClaveAutorizacion: document.getElementById(
        'estadoClaveAutorizacion'
    ),

    detalleClaveAutorizacion: document.getElementById(
        'detalleClaveAutorizacion'
    ),

    formularioClaveAutorizacion: document.getElementById(
        'formularioClaveAutorizacion'
    ),

    bloqueClaveActualAutorizacion: document.getElementById(
        'bloqueClaveActualAutorizacion'
    ),

    claveActualAutorizacion: document.getElementById(
        'claveActualAutorizacion'
    ),

    claveNuevaAutorizacion: document.getElementById(
        'claveNuevaAutorizacion'
    ),

    confirmarClaveNuevaAutorizacion: document.getElementById(
        'confirmarClaveNuevaAutorizacion'
    ),

    mensajeFormularioClaveAutorizacion: document.getElementById(
        'mensajeFormularioClaveAutorizacion'
    ),

    botonGuardarClaveAutorizacion: document.getElementById(
        'botonGuardarClaveAutorizacion'
    ),
    toggleRequerirClaveAutorizacion: document.getElementById(
        'toggleRequerirClaveAutorizacion'
    )
};

const estadoVista = {
    configuracion: null,
    tasaVigente: null,
    metodosPago: [],
    cajasFisicas: [],
    tasas: [],
    claveAutorizacion: null,
    impresion: null
};
let temporizadorMensaje = null;

/* =========================================================
   UTILIDADES
   ========================================================= */

function textoSeguro(valor) {
    return String(valor ?? '').trim();
}

function obtenerIniciales(nombreCompleto) {
    const palabras = textoSeguro(nombreCompleto)
        .split(/\s+/)
        .filter(Boolean);

    if (palabras.length === 0) {
        return 'TV';
    }

    return palabras
        .slice(0, 2)
        .map((palabra) => palabra.charAt(0))
        .join('')
        .toUpperCase();
}

function formatearRol(rol) {
    const roles = {
        PROPIETARIO: 'Propietario',
        CAJERO: 'Cajero'
    };

    return roles[rol] || 'Usuario';
}

function crearElemento(tag, texto = '') {
    const elemento = document.createElement(tag);

    if (texto) {
        elemento.textContent = texto;
    }

    return elemento;
}

function convertirFecha(valor) {
    const texto = textoSeguro(valor);

    if (!texto) {
        return null;
    }

    const fecha = new Date(
        texto.includes(' ')
            ? texto.replace(' ', 'T')
            : texto
    );

    if (Number.isNaN(fecha.getTime())) {
        return null;
    }

    return fecha;
}

function formatearFechaHora(valor) {
    const fecha = convertirFecha(valor);

    if (!fecha) {
        return 'Sin registro';
    }

    return new Intl.DateTimeFormat(
        'es-VE',
        {
            dateStyle: 'short',
            timeStyle: 'short'
        }
    ).format(fecha);
}

function formatearMonto(
    valor,
    moneda = 'VES',
    decimales = 2
) {
    const numero = Number(valor);

    if (!Number.isFinite(numero)) {
        return '—';
    }

    const cantidad = new Intl.NumberFormat(
        'es-VE',
        {
            minimumFractionDigits: decimales,
            maximumFractionDigits: decimales
        }
    ).format(numero);

    if (moneda === 'USD') {
        return `$ ${cantidad}`;
    }

    return `Bs. ${cantidad}`;
}

function normalizarMontoParaServicio(valor) {
    const texto = textoSeguro(valor)
        .replace(/\s+/g, '')
        .replace(',', '.');

    if (
        !/^(?:0|[1-9]\d{0,11})(?:\.\d{1,6})?$/
            .test(texto)
    ) {
        return null;
    }

    const numero = Number(texto);

    if (
        !Number.isFinite(numero) ||
        numero <= 0
    ) {
        return null;
    }

    return texto;
}
function normalizarPorcentajeIvaParaServicio(
    valor
) {
    const texto = textoSeguro(valor)
        .replace(/\s+/g, '')
        .replace(',', '.');

    if (
        !/^(?:0|[1-9]\d{0,2})(?:\.\d{1,2})?$/
            .test(texto)
    ) {
        return null;
    }

    const numero = Number(texto);

    if (
        !Number.isFinite(numero) ||
        numero < 0 ||
        numero > 100
    ) {
        return null;
    }

    return texto;
}

function formatearPorcentajeIva(valor) {
    const numero = Number(valor);

    if (!Number.isFinite(numero)) {
        return '—';
    }

    return `${new Intl.NumberFormat(
        'es-VE',
        {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }
    ).format(numero)} %`;
}
function mostrarMensajeFlotante(
    mensaje,
    tipo = 'correcto'
) {
    window.clearTimeout(temporizadorMensaje);

    elementos.mensajeFlotanteConfiguracion.textContent =
        mensaje;

    elementos.mensajeFlotanteConfiguracion.classList.toggle(
        'mensaje-flotante-configuracion--error',
        tipo === 'error'
    );

    elementos.mensajeFlotanteConfiguracion.classList.add(
        'mensaje-flotante-configuracion--visible'
    );

    temporizadorMensaje = window.setTimeout(() => {
        elementos.mensajeFlotanteConfiguracion.classList.remove(
            'mensaje-flotante-configuracion--visible'
        );

        elementos.mensajeFlotanteConfiguracion.classList.remove(
            'mensaje-flotante-configuracion--error'
        );
    }, 3900);
}

function mostrarMensajeFormulario(
    elemento,
    mensaje,
    correcto = false
) {
    elemento.textContent = mensaje;

    elemento.classList.toggle(
        'mensaje-configuracion--correcto',
        correcto
    );
}

function limpiarMensajeFormulario(elemento) {
    elemento.textContent = '';

    elemento.classList.remove(
        'mensaje-configuracion--correcto'
    );
}

async function solicitarJSON(
    ruta,
    opciones = {}
) {
    const respuesta = await fetch(ruta, {
        cache: 'no-store',
        ...opciones
    });

    let resultado = null;

    try {
        resultado = await respuesta.json();
    } catch (error) {
        resultado = null;
    }

    if (!respuesta.ok || !resultado?.ok) {
        const error = new Error(
            resultado?.mensaje ||
            'No fue posible completar la operación.'
        );

        error.codigo = resultado?.codigo || null;

        throw error;
    }

    return resultado;
}

/* =========================================================
   CONTEXTO Y PERMISOS
   ========================================================= */

async function cargarContextoAplicacion() {
    try {
        const resultado = await solicitarJSON(
            '/api/aplicacion/estado'
        );

        const usuario = resultado.sesion?.usuario || null;

        const puedeConfigurar =
            resultado.licencia?.activa === true &&
            resultado.negocio?.configurado === true &&
            usuario?.rol === 'PROPIETARIO';

        if (!puedeConfigurar) {
            window.location.assign(
                resultado.destino || '/'
            );

            return false;
        }

        elementos.nombreNegocioSuperior.textContent =
            resultado.negocio?.nombreComercial ||
            'Mi negocio';

        elementos.nombreUsuarioLateral.textContent =
            usuario.nombreCompleto || 'Propietario';

        elementos.rolUsuarioLateral.textContent =
            formatearRol(usuario.rol);

        elementos.avatarUsuarioLateral.textContent =
            obtenerIniciales(usuario.nombreCompleto);

        elementos.estadoLicenciaSuperior.textContent =
            resultado.licencia?.estado === 'ACTIVA'
                ? 'Licencia activa'
                : 'Licencia no disponible';

        actualizarEstadoActualizacionSuperior(
            resultado.actualizacion?.disponible === true
        );

        return true;
    } catch (error) {
        console.error(
            'Error preparando Configuración:',
            error
        );

        mostrarMensajeFlotante(
            error.message ||
            'No fue posible validar el acceso a Configuración.',
            'error'
        );

        return false;
    }
}

function actualizarEstadoActualizacionSuperior(disponible) {
    if (elementos.estadoActualizacionSuperior) {
        if (disponible) {
            elementos.estadoActualizacionSuperior.hidden = false;
            elementos.estadoActualizacionSuperior.classList.add(
                'estado-actualizacion--visible'
            );
            elementos.estadoActualizacionSuperior.classList.remove(
                'estado-actualizacion--oculto'
            );
            elementos.estadoActualizacionSuperior.textContent =
                'Actualización pendiente';
        } else {
            elementos.estadoActualizacionSuperior.hidden = true;
            elementos.estadoActualizacionSuperior.classList.add(
                'estado-actualizacion--oculto'
            );
            elementos.estadoActualizacionSuperior.classList.remove(
                'estado-actualizacion--visible'
            );
        }
    }
}

async function cargarEstadoActualizacion() {
    try {
        const resultado = await solicitarJSON(
            '/api/sistema/actualizacion'
        );

        const estado = resultado.estado || {};

        elementos.versionActualSistema.textContent =
            estado.currentVersion || '-';
        elementos.versionRemotaSistema.textContent =
            estado.remoteVersion || 'Sin datos';
        elementos.estadoActualizacionSistema.textContent =
            estado.available
                ? 'Actualización disponible'
                : 'Sistema actualizado';
        elementos.notasActualizacionSistema.textContent =
            estado.notes ||
            'No hay notas disponibles.';

        elementos.botonAplicarActualizacion.disabled =
            !estado.available;

        actualizarEstadoActualizacionSuperior(
            Boolean(estado.available)
        );

        return estado;
    } catch (error) {
        console.error(
            'Error cargando estado de actualización:',
            error
        );

        mostrarMensajeFlotante(
            'No fue posible consultar el estado de actualización.',
            'error'
        );

        elementos.estadoActualizacionSistema.textContent =
            'Error al consultar actualización';

        elementos.botonAplicarActualizacion.disabled = true;

        return null;
    }
}

function mostrarModalActualizacion(mensaje, progreso) {
    elementos.modalActualizacion.hidden = false;
    elementos.modalActualizacion.setAttribute('aria-hidden', 'false');
    elementos.modalActualizacionMensaje.textContent = mensaje;
    elementos.modalActualizacionProgreso.textContent = progreso;
    document.body.style.overflow = 'hidden';
}

function ocultarModalActualizacion() {
    elementos.modalActualizacion.hidden = true;
    elementos.modalActualizacion.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
}

function actualizarTextoModalActualizacionDesdeEstado(estado) {
    if (!estado) {
        return;
    }

    const etapa = estado.step;
    const mensaje = estado.progressMessage || estado.lastUpdateResult || 'Actualización en progreso...';

    if (elementos.modalActualizacionMensaje) {
        if (etapa === 'download') {
            elementos.modalActualizacionMensaje.textContent = 'Descargando paquete remoto';
        } else if (etapa === 'extract') {
            elementos.modalActualizacionMensaje.textContent = 'Extrayendo paquete';
        } else if (etapa === 'package') {
            elementos.modalActualizacionMensaje.textContent = 'Preparando archivos';
        } else if (etapa === 'copy') {
            elementos.modalActualizacionMensaje.textContent = 'Copiando archivos';
        } else if (etapa === 'install') {
            elementos.modalActualizacionMensaje.textContent = 'Instalando dependencias';
        } else if (etapa === 'cleanup') {
            elementos.modalActualizacionMensaje.textContent = 'Finalizando y limpiando';
        } else if (etapa === 'restart') {
            elementos.modalActualizacionMensaje.textContent = 'Reiniciando servidor';
        } else {
            elementos.modalActualizacionMensaje.textContent = 'Actualización en progreso';
        }
    }

    if (elementos.modalActualizacionProgreso) {
        elementos.modalActualizacionProgreso.textContent = mensaje;
    }
}

async function buscarActualizacionSistema() {
    try {
        elementos.botonBuscarActualizacion.disabled = true;
        elementos.mensajeActualizacionSistema.textContent =
            'Buscando actualización...';

        const resultado = await solicitarJSON(
            '/api/sistema/actualizacion/buscar',
            {
                method: 'POST'
            }
        );

        const estado = resultado.estado || {};

        elementos.versionActualSistema.textContent =
            estado.currentVersion || '-';
        elementos.versionRemotaSistema.textContent =
            estado.remoteVersion || 'Sin datos';
        elementos.estadoActualizacionSistema.textContent =
            estado.available
                ? 'Actualización disponible'
                : 'Sistema actualizado';
        elementos.notasActualizacionSistema.textContent =
            estado.notes ||
            'No hay notas disponibles.';

        elementos.botonAplicarActualizacion.disabled =
            !estado.available;

        actualizarEstadoActualizacionSuperior(
            Boolean(estado.available)
        );

        elementos.mensajeActualizacionSistema.textContent =
            estado.available
                ? 'Puede aplicar la actualización ahora.'
                : 'No hay actualizaciones disponibles.';
    } catch (error) {
        console.error(
            'Error buscando actualización:',
            error
        );

        mostrarMensajeFlotante(
            error.message ||
            'No fue posible buscar actualizaciones.',
            'error'
        );

        elementos.mensajeActualizacionSistema.textContent =
            'Error al buscar actualización.';
    } finally {
        elementos.botonBuscarActualizacion.disabled = false;
    }
}

function abrirConfirmacionActualizacion() {
    if (!elementos.modalConfirmarActualizacion) {
        return;
    }

    elementos.modalConfirmarActualizacion.hidden = false;
    elementos.modalConfirmarActualizacion.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
}

function cerrarConfirmacionActualizacion() {
    if (!elementos.modalConfirmarActualizacion) {
        return;
    }

    elementos.modalConfirmarActualizacion.hidden = true;
    elementos.modalConfirmarActualizacion.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
}

async function aplicarActualizacionSistema() {
    if (!elementos.botonAplicarActualizacion?.disabled) {
        abrirConfirmacionActualizacion();
    }
}

async function confirmarAplicacionActualizacionSistema() {
    try {
        cerrarConfirmacionActualizacion();

        elementos.botonAplicarActualizacion.disabled = true;
        elementos.mensajeActualizacionSistema.textContent = 'Iniciando actualización...';
        mostrarModalActualizacion(
            'Iniciando actualización...',
            'Descargando archivos y preparando el sistema...'
        );

        const resultado = await solicitarJSON('/api/sistema/actualizacion/aplicar', { method: 'POST' });

        if (resultado && resultado.estado) {
            const estado = resultado.estado || {};

            elementos.versionActualSistema.textContent = estado.currentVersion || '-';
            elementos.versionRemotaSistema.textContent = estado.remoteVersion || 'Sin datos';
            elementos.estadoActualizacionSistema.textContent = estado.available ? 'Actualización disponible' : 'Sistema actualizado';
            elementos.notasActualizacionSistema.textContent = estado.notes || 'No hay notas disponibles.';
            elementos.mensajeActualizacionSistema.textContent = estado.lastUpdateResult || 'Actualización aplicada correctamente.';
            mostrarModalActualizacion(
                'Actualización completada',
                estado.lastUpdateResult || 'Actualización aplicada correctamente.'
            );

            window.setTimeout(() => {
                ocultarModalActualizacion();
                window.location.reload();
            }, 900);

            elementos.botonAplicarActualizacion.disabled = false;
            return;
        }

        elementos.mensajeActualizacionSistema.textContent = resultado.mensaje || 'Actualización iniciada en segundo plano...';
        mostrarModalActualizacion(
            'Actualización en progreso',
            'La actualización se está aplicando. Esto puede tardar algunos minutos.'
        );

        const intervalo = setInterval(async () => {
            try {
                const r = await solicitarJSON('/api/sistema/actualizacion', { method: 'GET' });
                const st = r.estado || {};

                elementos.versionActualSistema.textContent = st.currentVersion || '-';
                elementos.versionRemotaSistema.textContent = st.remoteVersion || 'Sin datos';
                elementos.estadoActualizacionSistema.textContent = st.available ? 'Actualización disponible' : 'Sistema actualizado';
                elementos.notasActualizacionSistema.textContent = st.notes || 'No hay notas disponibles.';
                actualizarTextoModalActualizacionDesdeEstado(st);

                if (!st.updateInProgress) {
                    clearInterval(intervalo);
                    elementos.mensajeActualizacionSistema.textContent = st.lastUpdateResult || 'Actualización finalizada.';
                    elementos.botonAplicarActualizacion.disabled = false;
                    elementos.modalActualizacionMensaje.textContent = 'Actualización finalizada';
                    elementos.modalActualizacionProgreso.textContent = st.lastUpdateResult || 'Actualización finalizada correctamente.';
                    window.setTimeout(() => {
                        ocultarModalActualizacion();
                        window.location.reload();
                    }, 900);
                }
            } catch (e) {
                console.error('Error consultando estado de actualización:', e);

                elementos.modalActualizacionMensaje.textContent = 'Reiniciando servidor';
                elementos.modalActualizacionProgreso.textContent = 'Se está cargando la nueva versión del sistema...';

                window.setTimeout(() => {
                    ocultarModalActualizacion();
                    window.location.reload();
                }, 1000);
            }
        }, 2000);
    } catch (error) {
        console.error(
            'Error aplicando actualización:',
            error
        );

        mostrarMensajeFlotante(
            error.message ||
            'No fue posible aplicar la actualización.',
            'error'
        );

        elementos.mensajeActualizacionSistema.textContent =
            'Error al aplicar actualización.';
        mostrarModalActualizacion(
            'Error al aplicar actualización',
            error.message || 'Revise la conexión y vuelva a intentar.'
        );
        window.setTimeout(() => {
            ocultarModalActualizacion();
        }, 2200);
    } finally {
        elementos.botonAplicarActualizacion.disabled = false;
    }
}

/* =========================================================
   RESUMEN FINANCIERO
   ========================================================= */

function renderizarConfiguracionFinanciera(
    configuracion
) {
    if (!configuracion) {
        return;
    }

    estadoVista.configuracion = configuracion;

    elementos.monedaBaseCabecera.textContent =
        configuracion.monedaBase || 'USD';

    elementos.preciosIncluyenIva.checked =
        configuracion.preciosIncluyenIva === true;

    elementos.ivaPorcentajeGlobal.value =
        Number(configuracion.ivaPorcentaje || 0)
            .toFixed(2)
            .replace('.', ',');

    elementos.decimalesUsd.value = String(
        configuracion.decimalesUsd ?? 2
    );

    elementos.decimalesVes.value = String(
        configuracion.decimalesVes ?? 2
    );

    elementos.estadoIvaResumen.textContent =
        `${formatearPorcentajeIva(
            configuracion.ivaPorcentaje
        )} · ${configuracion.preciosIncluyenIva
            ? 'Incluido'
            : 'Al final'
        }`;
}

function renderizarTasaVigente(tasa) {
    estadoVista.tasaVigente = tasa || null;

    const decimalesVes =
        estadoVista.configuracion?.decimalesVes ?? 2;

    if (!tasa) {
        elementos.valorTasaVigente.textContent =
            'Sin tasa';

        elementos.detalleTasaVigente.textContent =
            'Registre la primera tasa USD → VES.';

        return;
    }

    elementos.valorTasaVigente.textContent =
        `1 USD = ${formatearMonto(
            tasa.valor,
            'VES',
            decimalesVes
        )}`;

    const nota = tasa.nota
        ? ` · ${tasa.nota}`
        : '';

    elementos.detalleTasaVigente.textContent =
        `Actualizada ${formatearFechaHora(
            tasa.vigenteDesde
        )} por ${tasa.creadaPorNombre || 'Propietario'}${nota}`;
}

function renderizarMetodosPago(metodos) {
    const lista = Array.isArray(metodos)
        ? metodos
        : [];

    estadoVista.metodosPago = lista;

    const activos = lista.filter(
        (metodo) => metodo.estado === 'ACTIVO'
    );

    elementos.cantidadMetodosPago.textContent =
        String(activos.length);

    elementos.listaMetodosPago.replaceChildren();

    if (lista.length === 0) {
        const vacio = crearElemento(
            'p',
            'No hay métodos de pago registrados.'
        );

        vacio.className = 'lista-recursos__vacio';

        elementos.listaMetodosPago.appendChild(vacio);

        return;
    }

    for (const metodo of lista) {
        const recurso = crearElemento('div');

        recurso.className = 'recurso-configuracion';

        const datos = crearElemento('div');

        datos.className =
            'recurso-configuracion__datos';

        const nombre = crearElemento(
            'strong',
            metodo.nombre
        );

        const detalles = [];

        detalles.push(
            metodo.monedaOperativa === 'MIXTA'
                ? 'USD y VES'
                : metodo.monedaOperativa
        );

        if (metodo.requiereReferencia) {
            detalles.push('Referencia');
        }

        if (metodo.afectaEfectivoFisico) {
            detalles.push('Efectivo físico');
        }

        const descripcion = crearElemento(
            'span',
            detalles.join(' · ')
        );

        datos.append(nombre, descripcion);

        const estado = crearElemento(
            'span',
            metodo.estado === 'ACTIVO'
                ? 'Activo'
                : 'Inactivo'
        );

        estado.className =
            `recurso-configuracion__estado ${metodo.estado === 'ACTIVO'
                ? ''
                : 'recurso-configuracion__estado--inactivo'
                }`.trim();

        recurso.append(datos, estado);

        elementos.listaMetodosPago.appendChild(
            recurso
        );
    }
}

function renderizarCajasFisicas(cajas) {
    const lista = Array.isArray(cajas)
        ? cajas
        : [];

    estadoVista.cajasFisicas = lista;

    const activas = lista.filter(
        (caja) => caja.estado === 'ACTIVA'
    );

    elementos.cantidadCajasActivas.textContent =
        String(activas.length);

    elementos.cantidadCajasFisicas.textContent =
        String(lista.length);

    elementos.listaCajasFisicas.replaceChildren();

    if (lista.length === 0) {
        const vacio = crearElemento(
            'p',
            'No hay cajas físicas registradas.'
        );

        vacio.className = 'lista-recursos__vacio';

        elementos.listaCajasFisicas.appendChild(vacio);

        return;
    }

    for (const caja of lista) {
        const recurso = crearElemento('div');

        recurso.className = 'recurso-configuracion';

        const datos = crearElemento('div');

        datos.className =
            'recurso-configuracion__datos';

        const nombre = crearElemento(
            'strong',
            caja.nombre
        );

        const monedas = [];

        if (caja.permiteUsd) {
            monedas.push('USD');
        }

        if (caja.permiteVes) {
            monedas.push('VES');
        }

        const detalle = crearElemento(
            'span',
            `${caja.codigo} · ${monedas.length > 0
                ? monedas.join(' y ')
                : 'Sin moneda habilitada'
            }`
        );

        datos.append(nombre, detalle);

        const estado = crearElemento(
            'span',
            caja.estado === 'ACTIVA'
                ? 'Activa'
                : 'Inactiva'
        );

        estado.className =
            `recurso-configuracion__estado ${caja.estado === 'ACTIVA'
                ? ''
                : 'recurso-configuracion__estado--inactivo'
                }`.trim();

        recurso.append(datos, estado);

        elementos.listaCajasFisicas.appendChild(
            recurso
        );
    }
}

function crearInsigniaTasa(estadoTasa) {
    const estado = textoSeguro(estadoTasa)
        .toUpperCase();

    const textos = {
        VIGENTE: 'Vigente',
        HISTORICA: 'Histórica',
        ANULADA: 'Anulada'
    };

    const insignia = crearElemento(
        'span',
        textos[estado] || estado || '—'
    );

    insignia.className =
        `insignia-tasa ${estado === 'VIGENTE'
            ? 'insignia-tasa--vigente'
            : estado === 'HISTORICA'
                ? 'insignia-tasa--historica'
                : 'insignia-tasa--anulada'
        }`;

    return insignia;
}

function renderizarTasas(tasas) {
    const lista = Array.isArray(tasas)
        ? tasas
        : [];

    estadoVista.tasas = lista;

    elementos.cuerpoTablaTasas.replaceChildren();

    if (lista.length === 0) {
        const fila = document.createElement('tr');

        const celda = document.createElement('td');

        celda.colSpan = 5;
        celda.className = 'tabla-tasas__vacio';

        celda.textContent =
            'Todavía no hay tasas registradas.';

        fila.appendChild(celda);

        elementos.cuerpoTablaTasas.appendChild(fila);

        return;
    }

    const decimalesVes =
        estadoVista.configuracion?.decimalesVes ?? 2;

    // Mostrar primero la vigente y luego hasta 3 históricas recientes
    const vigente = lista.find(t => t.estado === 'VIGENTE') || null;
    const historicas = lista
        .filter(t => t.estado === 'HISTORICA')
        .sort((a, b) => new Date(b.vigenteDesde) - new Date(a.vigenteDesde))
        .slice(0, 3);

    const mostrar = [];
    if (vigente) mostrar.push(vigente);
    mostrar.push(...historicas);

    for (const tasa of mostrar) {
        const fila = document.createElement('tr');

        const celdaEstado = document.createElement('td');

        celdaEstado.appendChild(
            crearInsigniaTasa(tasa.estado)
        );

        const celdaValor = document.createElement('td');

        const valor = crearElemento(
            'span',
            `1 USD = ${formatearMonto(
                tasa.valor,
                'VES',
                decimalesVes
            )}`
        );

        valor.className = 'valor-tasa-tabla';

        celdaValor.appendChild(valor);

        const celdaFecha = crearElemento(
            'td',
            formatearFechaHora(tasa.vigenteDesde)
        );

        const celdaResponsable = crearElemento(
            'td',
            tasa.creadaPorNombre || '—'
        );

        const celdaNota = crearElemento(
            'td',
            tasa.nota || 'Sin nota'
        );

        fila.append(
            celdaEstado,
            celdaValor,
            celdaFecha,
            celdaResponsable,
            celdaNota
        );

        elementos.cuerpoTablaTasas.appendChild(fila);
    }
}

async function cargarResumenFinanciero() {
    const resultado = await solicitarJSON(
        '/api/finanzas/resumen'
    );

    renderizarConfiguracionFinanciera(
        resultado.configuracion
    );

    renderizarTasaVigente(
        resultado.tasaVigente
    );

    renderizarMetodosPago(
        resultado.metodosPago
    );

    renderizarCajasFisicas(
        resultado.cajasFisicas
    );
}

async function cargarHistorialTasas() {
    const resultado = await solicitarJSON(
        '/api/finanzas/tasas'
    );

    renderizarTasas(resultado.tasas);
}

async function recargarDatosFinancieros() {
    try {
        await cargarResumenFinanciero();

        await cargarHistorialTasas();
    } catch (error) {
        console.error(
            'Error cargando configuración financiera:',
            error
        );

        mostrarMensajeFlotante(
            error.message ||
            'No fue posible cargar la configuración financiera.',
            'error'
        );
    }
}

/* =========================================================
   ACTUALIZAR TASA
   ========================================================= */

async function guardarNuevaTasa(evento) {
    evento.preventDefault();

    limpiarMensajeFormulario(
        elementos.mensajeFormularioTasa
    );

    const valor = normalizarMontoParaServicio(
        elementos.valorNuevaTasa.value
    );

    const nota = textoSeguro(
        elementos.notaNuevaTasa.value
    );

    if (!valor) {
        mostrarMensajeFormulario(
            elementos.mensajeFormularioTasa,
            'Ingrese una tasa válida mayor que cero.'
        );

        elementos.valorNuevaTasa.focus();

        return;
    }

    if (nota.length > 250) {
        mostrarMensajeFormulario(
            elementos.mensajeFormularioTasa,
            'La nota no puede superar 250 caracteres.'
        );

        elementos.notaNuevaTasa.focus();

        return;
    }

    const textoOriginal =
        elementos.botonGuardarTasa.textContent;

    try {
        elementos.botonGuardarTasa.disabled = true;

        elementos.botonGuardarTasa.textContent =
            'Actualizando...';

        const resultado = await solicitarJSON(
            '/api/finanzas/tasas',
            {
                method: 'POST',

                headers: {
                    'Content-Type':
                        'application/json'
                },

                body: JSON.stringify({
                    valor,
                    nota
                })
            }
        );

        elementos.formularioTasa.reset();

        await recargarDatosFinancieros();

        mostrarMensajeFormulario(
            elementos.mensajeFormularioTasa,
            'Tasa actualizada correctamente.',
            true
        );

        mostrarMensajeFlotante(
            resultado.mensaje ||
            'La tasa referencial fue actualizada correctamente.'
        );
    } catch (error) {
        console.error(
            'Error guardando tasa:',
            error
        );

        mostrarMensajeFormulario(
            elementos.mensajeFormularioTasa,
            error.message ||
            'No fue posible actualizar la tasa.'
        );
    } finally {
        elementos.botonGuardarTasa.disabled = false;

        elementos.botonGuardarTasa.textContent =
            textoOriginal;
    }
}

/* =========================================================
   IVA Y DECIMALES
   ========================================================= */

async function guardarConfiguracionFinanciera(evento) {
    evento.preventDefault();

    limpiarMensajeFormulario(
        elementos.mensajeFormularioConfiguracion
    );

    const decimalesUsd = Number(
        elementos.decimalesUsd.value
    );

    const decimalesVes = Number(
        elementos.decimalesVes.value
    );
    const ivaPorcentaje =
        normalizarPorcentajeIvaParaServicio(
            elementos.ivaPorcentajeGlobal.value
        );

    if (ivaPorcentaje === null) {
        mostrarMensajeFormulario(
            elementos.mensajeFormularioConfiguracion,
            'Ingrese un IVA válido entre 0 y 100, con hasta 2 decimales.'
        );

        elementos.ivaPorcentajeGlobal.focus();

        return;
    }
    if (
        !Number.isInteger(decimalesUsd) ||
        decimalesUsd < 0 ||
        decimalesUsd > 4
    ) {
        mostrarMensajeFormulario(
            elementos.mensajeFormularioConfiguracion,
            'Los decimales de USD no son válidos.'
        );

        return;
    }

    if (
        !Number.isInteger(decimalesVes) ||
        decimalesVes < 0 ||
        decimalesVes > 4
    ) {
        mostrarMensajeFormulario(
            elementos.mensajeFormularioConfiguracion,
            'Los decimales de VES no son válidos.'
        );

        return;
    }

    const textoOriginal =
        elementos.botonGuardarConfiguracion.textContent;

    try {
        elementos.botonGuardarConfiguracion.disabled =
            true;

        elementos.botonGuardarConfiguracion.textContent =
            'Guardando...';

        const resultado = await solicitarJSON(
            '/api/finanzas/configuracion',
            {
                method: 'PUT',

                headers: {
                    'Content-Type':
                        'application/json'
                },

                body: JSON.stringify({
                    ivaPorcentaje,

                    preciosIncluyenIva:
                        elementos.preciosIncluyenIva.checked,

                    decimalesUsd,
                    decimalesVes
                })
            }
        );

        renderizarConfiguracionFinanciera(
            resultado.configuracion
        );

        renderizarTasaVigente(
            estadoVista.tasaVigente
        );

        renderizarTasas(estadoVista.tasas);

        mostrarMensajeFormulario(
            elementos.mensajeFormularioConfiguracion,
            'Configuración financiera guardada correctamente.',
            true
        );

        mostrarMensajeFlotante(
            resultado.mensaje ||
            'La configuración financiera fue actualizada correctamente.'
        );
    } catch (error) {
        console.error(
            'Error guardando configuración financiera:',
            error
        );

        mostrarMensajeFormulario(
            elementos.mensajeFormularioConfiguracion,
            error.message ||
            'No fue posible guardar la configuración.'
        );
    } finally {
        elementos.botonGuardarConfiguracion.disabled =
            false;

        elementos.botonGuardarConfiguracion.textContent =
            textoOriginal;
    }
}
/* =========================================================
   SEGURIDAD OPERATIVA
   ========================================================= */

function normalizarClaveAutorizacionParaServicio(valor) {
    const texto = textoSeguro(valor)
        .replace(/\s+/g, '');

    if (!/^\d{4,12}$/.test(texto)) {
        return null;
    }

    return texto;
}

function renderizarEstadoClaveAutorizacion(claveAutorizacion) {
    const configurada =
        claveAutorizacion?.configurada === true;

    estadoVista.claveAutorizacion =
        claveAutorizacion || {
            configurada: false
        };

    const autorizacionHabilitada =
        claveAutorizacion?.autorizacionHabilitada !== false;

    elementos.estadoClaveAutorizacion.textContent =
        configurada
            ? (autorizacionHabilitada
                ? 'Configurada'
                : 'Configurada (desactivada)')
            : 'Sin configurar';

    elementos.detalleClaveAutorizacion.textContent =
        configurada
            ? (autorizacionHabilitada
                ? `Última actualización: ${formatearFechaHora(
                    claveAutorizacion.actualizadaEn
                )}.`
                : 'Requerir clave está desactivado. Actívelo para proteger historial, reimpresión y devoluciones.')
            : 'Configure una clave para proteger historial, reimpresión y devoluciones.';

    elementos.bloqueClaveActualAutorizacion.hidden =
        !configurada;

    elementos.claveActualAutorizacion.required =
        configurada;

    elementos.botonGuardarClaveAutorizacion.textContent =
        configurada
            ? 'Cambiar clave de autorización'
            : 'Crear clave de autorización';

    if (elementos.toggleRequerirClaveAutorizacion) {
        elementos.toggleRequerirClaveAutorizacion.checked =
            claveAutorizacion?.autorizacionHabilitada !== false;
    }
}

async function guardarEstadoClaveAutorizacion(evento) {
    if (evento && typeof evento.preventDefault === 'function') {
        evento.preventDefault();
    }

    if (!elementos.toggleRequerirClaveAutorizacion) {
        return;
    }

    const actual = elementos.toggleRequerirClaveAutorizacion.checked;
    const previo = !actual;

    elementos.toggleRequerirClaveAutorizacion.disabled = true;

    try {
        const cuerpo = {
            autorizacionHabilitada: actual
        };

        const resultado = await solicitarJSON(
            '/api/seguridad-operativa/clave-autorizacion',
            {
                method: 'PUT',
                headers: {
                    'Content-Type':
                        'application/json'
                },
                body: JSON.stringify(cuerpo)
            }
        );

        estadoVista.claveAutorizacion = {
            ...estadoVista.claveAutorizacion,
            autorizacionHabilitada:
                resultado.claveAutorizacion?.autorizacionHabilitada === false
                    ? false
                    : true,
            configurada:
                resultado.claveAutorizacion?.configurada === true
        };

        renderizarEstadoClaveAutorizacion(
            estadoVista.claveAutorizacion
        );

        mostrarMensajeFlotante(
            actual
                ? 'Requerir clave de autorización activado.'
                : 'Requerir clave de autorización desactivado.',
            'correcto'
        );
    } catch (error) {
        elementos.toggleRequerirClaveAutorizacion.checked = previo;

        console.error(
            'Error actualizando estado de autorización:',
            error
        );

        mostrarMensajeFlotante(
            error.message ||
            'No se pudo actualizar el estado de autorización.',
            'error'
        );
    } finally {
        elementos.toggleRequerirClaveAutorizacion.disabled = false;
    }
}

async function cargarEstadoClaveAutorizacion() {
    try {
        const resultado = await solicitarJSON(
            '/api/seguridad-operativa/clave-autorizacion'
        );

        renderizarEstadoClaveAutorizacion(
            resultado.claveAutorizacion
        );
    } catch (error) {
        console.error(
            'Error consultando clave de autorización:',
            error
        );

        elementos.estadoClaveAutorizacion.textContent =
            'No disponible';

        elementos.detalleClaveAutorizacion.textContent =
            error.message ||
            'No fue posible consultar la seguridad operativa.';

        mostrarMensajeFlotante(
            error.message ||
            'No fue posible consultar la clave de autorización.',
            'error'
        );
    }
}

async function guardarClaveAutorizacion(evento) {
    evento.preventDefault();

    limpiarMensajeFormulario(
        elementos.mensajeFormularioClaveAutorizacion
    );

    const claveConfigurada =
        estadoVista.claveAutorizacion?.configurada === true;

    const claveActual =
        normalizarClaveAutorizacionParaServicio(
            elementos.claveActualAutorizacion.value
        );

    const claveNueva =
        normalizarClaveAutorizacionParaServicio(
            elementos.claveNuevaAutorizacion.value
        );

    const confirmarClaveNueva =
        normalizarClaveAutorizacionParaServicio(
            elementos.confirmarClaveNuevaAutorizacion.value
        );

    if (claveConfigurada && !claveActual) {
        mostrarMensajeFormulario(
            elementos.mensajeFormularioClaveAutorizacion,
            'Ingrese la clave actual. Debe tener entre 4 y 12 números.'
        );

        elementos.claveActualAutorizacion.focus();

        return;
    }

    if (!claveNueva) {
        mostrarMensajeFormulario(
            elementos.mensajeFormularioClaveAutorizacion,
            'Ingrese una nueva clave de 4 a 12 números.'
        );

        elementos.claveNuevaAutorizacion.focus();

        return;
    }

    if (!confirmarClaveNueva) {
        mostrarMensajeFormulario(
            elementos.mensajeFormularioClaveAutorizacion,
            'Confirme la nueva clave de autorización.'
        );

        elementos.confirmarClaveNuevaAutorizacion.focus();

        return;
    }

    if (claveNueva !== confirmarClaveNueva) {
        mostrarMensajeFormulario(
            elementos.mensajeFormularioClaveAutorizacion,
            'La confirmación de la clave no coincide.'
        );

        elementos.confirmarClaveNuevaAutorizacion.focus();

        return;
    }

    const textoOriginal =
        elementos.botonGuardarClaveAutorizacion.textContent;

    try {
        elementos.botonGuardarClaveAutorizacion.disabled =
            true;

        elementos.botonGuardarClaveAutorizacion.textContent =
            'Guardando...';

        const cuerpo = {
            claveNueva,
            confirmarClaveNueva
        };

        if (elementos.toggleRequerirClaveAutorizacion) {
            cuerpo.autorizacionHabilitada =
                elementos.toggleRequerirClaveAutorizacion.checked;
        }

        if (claveConfigurada) {
            cuerpo.claveActual = claveActual;
        }

        const resultado = await solicitarJSON(
            '/api/seguridad-operativa/clave-autorizacion',
            {
                method: 'PUT',

                headers: {
                    'Content-Type':
                        'application/json'
                },

                body: JSON.stringify(cuerpo)
            }
        );

        elementos.formularioClaveAutorizacion.reset();

        await cargarEstadoClaveAutorizacion();

        mostrarMensajeFormulario(
            elementos.mensajeFormularioClaveAutorizacion,
            resultado.mensaje ||
            'Clave de autorización guardada correctamente.',
            true
        );

        mostrarMensajeFlotante(
            resultado.mensaje ||
            'Clave de autorización guardada correctamente.'
        );
    } catch (error) {
        console.error(
            'Error guardando clave de autorización:',
            error
        );

        mostrarMensajeFormulario(
            elementos.mensajeFormularioClaveAutorizacion,
            error.message ||
            'No fue posible guardar la clave de autorización.'
        );
    } finally {
        elementos.botonGuardarClaveAutorizacion.disabled =
            false;

        elementos.botonGuardarClaveAutorizacion.textContent =
            textoOriginal;

        renderizarEstadoClaveAutorizacion(
            estadoVista.claveAutorizacion
        );
    }
}
/* =========================================================
   IMPRESIÓN TÉRMICA
   ========================================================= */

function normalizarEnteroConfiguracion(
    valor,
    minimo,
    maximo,
    predeterminado
) {
    const numero = Number(valor);

    if (
        !Number.isInteger(numero) ||
        numero < minimo ||
        numero > maximo
    ) {
        return predeterminado;
    }

    return numero;
}

function renderizarConfiguracionImpresion(configuracion) {
    if (!configuracion) {
        return;
    }

    estadoVista.impresion = configuracion;

    elementos.impresionHabilitada.checked =
        configuracion.impresionHabilitada === true ||
        configuracion.impresionHabilitada === 1;

    elementos.formatoPapelImpresion.value =
        configuracion.formatoPapel || '58MM';

    elementos.modoImpresion.value =
        configuracion.modoImpresion || 'SERIAL_COM';

    elementos.puertoSerialImpresion.value =
        configuracion.puertoSerial || 'COM3';

    elementos.baudRateImpresion.value =
        String(configuracion.baudRate || 9600);

    elementos.copiasVentaImpresion.value =
        String(configuracion.copiasVenta || 1);

    elementos.copiasReimpresion.value =
        String(configuracion.copiasReimpresion || 1);

    elementos.lineasAvanceFinal.value =
        String(configuracion.lineasAvanceFinal ?? 3);

    elementos.tituloComprobanteImpresion.value =
        configuracion.tituloComprobante ||
        'Comprobante de venta';

    elementos.nombreImpresoraWindows.value =
        configuracion.nombreImpresoraWindows || '';

    elementos.cortarPapelImpresion.checked =
        configuracion.cortarPapel === true ||
        configuracion.cortarPapel === 1;

    elementos.mostrarLogoTextoImpresion.checked =
        configuracion.mostrarLogoTexto === true ||
        configuracion.mostrarLogoTexto === 1;

    renderizarEstadoImpresion();
}

function renderizarEstadoImpresion() {
    const configuracion =
        estadoVista.impresion;

    if (!configuracion) {
        elementos.estadoImpresionConfiguracion.textContent =
            'Sin configuración cargada.';

        return;
    }

    const habilitada =
        configuracion.impresionHabilitada === true ||
        configuracion.impresionHabilitada === 1;

    if (
        !habilitada ||
        configuracion.modoImpresion === 'NINGUNA'
    ) {
        elementos.estadoImpresionConfiguracion.textContent =
            'Impresión deshabilitada.';

        return;
    }

    if (configuracion.modoImpresion === 'SERIAL_COM') {
        elementos.estadoImpresionConfiguracion.textContent =
            `${configuracion.formatoPapel || '58MM'} · ${configuracion.puertoSerial || 'COM'} · ${configuracion.baudRate || 9600}`;

        return;
    }

    elementos.estadoImpresionConfiguracion.textContent =
        `${configuracion.formatoPapel || '58MM'} · Driver Windows`;
}
async function cargarConfiguracionImpresion() {
    try {
        const resultado = await solicitarJSON(
            '/api/impresion/configuracion'
        );

        renderizarConfiguracionImpresion(
            resultado.configuracion
        );
    } catch (error) {
        console.error(
            'Error cargando configuración de impresión:',
            error
        );

        mostrarMensajeFlotante(
            error.message ||
            'No fue posible cargar la configuración de impresión.',
            'error'
        );
    }
}

function obtenerPayloadConfiguracionImpresion() {
    const modoImpresion =
        elementos.modoImpresion.value;

    const formatoPapel =
        elementos.formatoPapelImpresion.value;

    const puertoSerial =
        textoSeguro(
            elementos.puertoSerialImpresion.value
        ).toUpperCase();

    const baudRate =
        normalizarEnteroConfiguracion(
            elementos.baudRateImpresion.value,
            1200,
            115200,
            9600
        );

    const copiasVenta =
        normalizarEnteroConfiguracion(
            elementos.copiasVentaImpresion.value,
            1,
            5,
            1
        );

    const copiasReimpresion =
        normalizarEnteroConfiguracion(
            elementos.copiasReimpresion.value,
            1,
            5,
            1
        );

    const lineasAvanceFinal =
        normalizarEnteroConfiguracion(
            elementos.lineasAvanceFinal.value,
            0,
            12,
            3
        );

    const tituloComprobante =
        textoSeguro(
            elementos.tituloComprobanteImpresion.value
        ) || 'Comprobante de venta';

    if (
        modoImpresion === 'SERIAL_COM' &&
        !/^COM\d{1,3}$/i.test(puertoSerial)
    ) {
        return {
            error:
                'Ingrese un puerto válido. Ejemplo: COM3.'
        };
    }

    return {
        impresionHabilitada:
            elementos.impresionHabilitada.checked,

        modoImpresion,
        formatoPapel,
        puertoSerial,
        baudRate,

        nombreImpresoraWindows:
            textoSeguro(
                elementos.nombreImpresoraWindows.value
            ) || null,

        copiasVenta,
        copiasReimpresion,
        lineasAvanceFinal,

        cortarPapel:
            elementos.cortarPapelImpresion.checked,

        tituloComprobante,

        mostrarLogoTexto:
            elementos.mostrarLogoTextoImpresion.checked
    };
}

async function guardarConfiguracionImpresion(evento) {
    evento.preventDefault();

    limpiarMensajeFormulario(
        elementos.mensajeFormularioImpresion
    );

    const payload =
        obtenerPayloadConfiguracionImpresion();

    if (payload.error) {
        mostrarMensajeFormulario(
            elementos.mensajeFormularioImpresion,
            payload.error
        );

        return;
    }

    const textoOriginal =
        elementos.botonGuardarImpresion.textContent;

    try {
        elementos.botonGuardarImpresion.disabled = true;

        elementos.botonGuardarImpresion.textContent =
            'Guardando...';

        const resultado = await solicitarJSON(
            '/api/impresion/configuracion',
            {
                method: 'PUT',

                headers: {
                    'Content-Type':
                        'application/json'
                },

                body: JSON.stringify(payload)
            }
        );

        renderizarConfiguracionImpresion(
            resultado.configuracion
        );

        mostrarMensajeFormulario(
            elementos.mensajeFormularioImpresion,
            'Configuración de impresión guardada correctamente.',
            true
        );

        mostrarMensajeFlotante(
            resultado.mensaje ||
            'La configuración de impresión fue actualizada correctamente.'
        );
    } catch (error) {
        console.error(
            'Error guardando configuración de impresión:',
            error
        );

        mostrarMensajeFormulario(
            elementos.mensajeFormularioImpresion,
            error.message ||
            'No fue posible guardar la configuración de impresión.'
        );
    } finally {
        elementos.botonGuardarImpresion.disabled = false;

        elementos.botonGuardarImpresion.textContent =
            textoOriginal;
    }
}

async function probarImpresionConfigurada() {
    limpiarMensajeFormulario(
        elementos.mensajeFormularioImpresion
    );

    const textoOriginal =
        elementos.botonProbarImpresion.textContent;

    try {
        elementos.botonProbarImpresion.disabled = true;

        elementos.botonProbarImpresion.textContent =
            'Imprimiendo...';

        const resultado = await solicitarJSON(
            '/api/impresion/prueba',
            {
                method: 'POST'
            }
        );

        mostrarMensajeFormulario(
            elementos.mensajeFormularioImpresion,
            resultado.mensaje ||
            'Prueba de impresión enviada correctamente.',
            true
        );

        mostrarMensajeFlotante(
            'Prueba enviada a la impresora.'
        );
    } catch (error) {
        console.error(
            'Error probando impresión:',
            error
        );

        mostrarMensajeFormulario(
            elementos.mensajeFormularioImpresion,
            error.message ||
            'No fue posible imprimir la prueba.'
        );

        mostrarMensajeFlotante(
            error.message ||
            'No fue posible imprimir la prueba.',
            'error'
        );
    } finally {
        elementos.botonProbarImpresion.disabled = false;

        elementos.botonProbarImpresion.textContent =
            textoOriginal;
    }
}
/* =========================================================
   NAVEGACIÓN Y SESIÓN
   ========================================================= */

function navegarModulo(modulo) {
    const rutasDisponibles = {
        'Panel principal': '/panel',
        Clientes: '/clientes',
        Inventario: '/inventario',
        Ventas: '/ventas',
        Caja: '/caja',
        Usuarios: '/usuarios',
        Configuración: '/configuracion'
    };
    const ruta = rutasDisponibles[modulo];

    if (ruta) {
        window.location.assign(ruta);

        return;
    }

    mostrarMensajeFlotante(
        `${modulo} será construido en el siguiente bloque de Tenvik.`
    );
}

async function cerrarSesion() {
    const textoOriginal =
        elementos.botonCerrarSesion.textContent;

    try {
        elementos.botonCerrarSesion.disabled = true;

        elementos.botonCerrarSesion.textContent =
            'Cerrando...';

        const resultado = await solicitarJSON(
            '/api/autenticacion/cerrar-sesion',
            {
                method: 'POST',

                headers: {
                    'Content-Type':
                        'application/json'
                }
            }
        );

        window.location.assign(
            resultado.redireccion ||
            '/iniciar-sesion'
        );
    } catch (error) {
        console.error(
            'Error cerrando sesión:',
            error
        );

        window.location.assign('/iniciar-sesion');
    } finally {
        elementos.botonCerrarSesion.disabled = false;

        elementos.botonCerrarSesion.textContent =
            textoOriginal;
    }
}

/* =========================================================
   EVENTOS
   ========================================================= */

/* =========================================================
   EVENTOS
   ========================================================= */

document.querySelectorAll(
    '[data-modulo]'
).forEach((elemento) => {
    elemento.addEventListener('click', () => {
        navegarModulo(
            textoSeguro(elemento.dataset.modulo)
        );
    });
});

elementos.formularioTasa.addEventListener(
    'submit',
    guardarNuevaTasa
);

elementos.formularioConfiguracionFinanciera.addEventListener(
    'submit',
    guardarConfiguracionFinanciera
);

elementos.formularioImpresion.addEventListener(
    'submit',
    guardarConfiguracionImpresion
);

elementos.botonProbarImpresion.addEventListener(
    'click',
    probarImpresionConfigurada
);

elementos.formularioClaveAutorizacion.addEventListener(
    'submit',
    guardarClaveAutorizacion
);

if (elementos.toggleRequerirClaveAutorizacion) {
    elementos.toggleRequerirClaveAutorizacion.addEventListener(
        'change',
        guardarEstadoClaveAutorizacion
    );
}

if (elementos.estadoActualizacionSuperior) {
    elementos.estadoActualizacionSuperior.addEventListener(
        'click',
        () => {
            sessionStorage.setItem(
                'tenvik.focus.actualizacion',
                'true'
            );
        }
    );
}

elementos.botonCerrarSesion.addEventListener(
    'click',
    cerrarSesion
);

/* =========================================================
   IMPORTAR LICENCIA (desde Configuración)
   ========================================================= */

function actualizarArchivoLicenciaSeleccionadoConfiguracion() {
    try {
        const archivo = elementos.archivoLicenciaConfiguracion?.files[0];

        if (!archivo) {
            elementos.nombreArchivoLicenciaConfiguracion.textContent = 'Ningún archivo seleccionado';
            elementos.botonImportarLicenciaConfiguracion.disabled = true;
            return;
        }

        elementos.nombreArchivoLicenciaConfiguracion.textContent = archivo.name;
        elementos.botonImportarLicenciaConfiguracion.disabled = false;
        elementos.mensajeImportacionLicenciaConfiguracion.textContent = '';
    } catch (e) {
        console.error('Error actualizando archivo de licencia:', e);
    }
}

function calcularDiasRestantes(fechaActualISO, fechaVencimientoISO) {
    if (!fechaActualISO || !fechaVencimientoISO) return 0;

    const [ay, am, ad] = String(fechaActualISO).slice(0, 10).split('-').map(Number);
    const [by, bm, bd] = String(fechaVencimientoISO).slice(0, 10).split('-').map(Number);

    const d1 = Date.UTC(ay, am - 1, ad);
    const d2 = Date.UTC(by, bm - 1, bd);

    const diff = Math.floor((d2 - d1) / (24 * 60 * 60 * 1000)) + 1;

    return Number.isFinite(diff) ? Math.max(diff, 0) : 0;
}

async function mostrarEstadoLicenciaEnConfiguracion() {
    try {
        const resultado = await solicitarJSON('/api/licencia/estado');

        const fechaActual = resultado.fechaActual || new Date().toISOString().slice(0, 10);
        const licencia = resultado.licencia || {};

        const dias = calcularDiasRestantes(fechaActual, licencia.fecha_vencimiento);

        if (elementos.diasRestantesLicencia) {
            elementos.diasRestantesLicencia.textContent = String(dias);
        }

        const detalleEl = document.getElementById('detalleAplicacionLicencia');
        if (detalleEl) {
            detalleEl.textContent = licencia.detalle_estado || '—';
        }

        const detalleCont = document.getElementById('detalleLicenciaConfiguracion');
        if (detalleCont) {
            detalleCont.hidden = false;
        }
    } catch (error) {
        // No mostrar error crítico en configuración; solo ocultar detalles
        const detalleCont = document.getElementById('detalleLicenciaConfiguracion');
        if (detalleCont) detalleCont.hidden = true;
    }
}

async function importarLicenciaSeleccionadaConfiguracion() {
    const archivo = elementos.archivoLicenciaConfiguracion?.files[0];

    if (!archivo) return;

    const textoOriginal = elementos.botonImportarLicenciaConfiguracion.textContent;

    try {
        elementos.botonImportarLicenciaConfiguracion.disabled = true;
        elementos.botonImportarLicenciaConfiguracion.textContent = 'Validando...';
        elementos.mensajeImportacionLicenciaConfiguracion.textContent = '';

        const contenido = await archivo.text();
        const licencia = JSON.parse(contenido);

        const respuesta = await fetch('/api/licencia/importar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(licencia)
        });

        const resultado = await respuesta.json();

        if (!respuesta.ok || !resultado.ok) {
            throw new Error(resultado.mensaje || 'No fue posible importar la licencia.');
        }

        elementos.mensajeImportacionLicenciaConfiguracion.textContent = resultado.mensaje || 'Licencia importada correctamente.';

        // Refrescar estado desde servidor para obtener fechaActual y vencimiento
        await mostrarEstadoLicenciaEnConfiguracion();
    } catch (error) {
        console.error('Error importando licencia desde Configuración:', error);
        elementos.mensajeImportacionLicenciaConfiguracion.textContent = error.message || 'No fue posible importar la licencia.';
    } finally {
        elementos.botonImportarLicenciaConfiguracion.textContent = textoOriginal;
        elementos.botonImportarLicenciaConfiguracion.disabled = !Boolean(elementos.archivoLicenciaConfiguracion?.files[0]);
    }
}

// Listeners para la UI de importación de licencias
if (elementos.archivoLicenciaConfiguracion) {
    elementos.archivoLicenciaConfiguracion.addEventListener('change', actualizarArchivoLicenciaSeleccionadoConfiguracion);
}

if (elementos.botonImportarLicenciaConfiguracion) {
    elementos.botonImportarLicenciaConfiguracion.addEventListener('click', importarLicenciaSeleccionadaConfiguracion);
}

elementos.botonBuscarActualizacion.addEventListener(
    'click',
    buscarActualizacionSistema
);

elementos.botonAplicarActualizacion.addEventListener(
    'click',
    aplicarActualizacionSistema
);

if (elementos.botonCancelarConfirmacionActualizacion) {
    elementos.botonCancelarConfirmacionActualizacion.addEventListener(
        'click',
        cerrarConfirmacionActualizacion
    );
}

if (elementos.botonConfirmarAplicarActualizacion) {
    elementos.botonConfirmarAplicarActualizacion.addEventListener(
        'click',
        confirmarAplicacionActualizacionSistema
    );
}

/* =========================================================
   INICIO
   ========================================================= */

async function iniciarConfiguracion() {
    const tieneAcceso =
        await cargarContextoAplicacion();

    if (!tieneAcceso) {
        return;
    }

    await recargarDatosFinancieros();
    await cargarEstadoClaveAutorizacion();
    await cargarConfiguracionImpresion();
    await cargarEstadoActualizacion();
    await mostrarEstadoLicenciaEnConfiguracion();

    const sesionActualizacion = sessionStorage.getItem('tenvik.focus.actualizacion');
    if (sesionActualizacion === 'true') {
        sessionStorage.removeItem('tenvik.focus.actualizacion');
        const seccion = document.getElementById('seccionActualizacion');
        if (seccion) {
            seccion.scrollIntoView({ behavior: 'smooth', block: 'start' });
            const boton = document.getElementById('botonAplicarActualizacion');
            if (boton) {
                boton.focus({ preventScroll: true });
            }
        }
    }
}

iniciarConfiguracion();