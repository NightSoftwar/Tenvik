'use strict';

const elementos = {
    nombreNegocioSuperior: document.getElementById(
        'nombreNegocioSuperior'
    ),

    estadoLicenciaSuperior: document.getElementById(
        'estadoLicenciaSuperior'
    ),

    estadoActualizacionSuperior: document.getElementById(
        'estadoActualizacionSuperior'
    ),

    nombreUsuarioPrincipal: document.getElementById(
        'nombreUsuarioPrincipal'
    ),

    nombreUsuarioLateral: document.getElementById(
        'nombreUsuarioLateral'
    ),

    rolUsuarioLateral: document.getElementById(
        'rolUsuarioLateral'
    ),

    avatarUsuarioLateral: document.getElementById(
        'avatarUsuarioLateral'
    ),

    fechaActualPanel: document.getElementById(
        'fechaActualPanel'
    ),

    estadoLicenciaTarjeta: document.getElementById(
        'estadoLicenciaTarjeta'
    ),

    detalleLicenciaTarjeta: document.getElementById(
        'detalleLicenciaTarjeta'
    ),

    vencimientoLicenciaTarjeta: document.getElementById(
        'vencimientoLicenciaTarjeta'
    ),

    rolUsuarioTarjeta: document.getElementById(
        'rolUsuarioTarjeta'
    ),

    botonCerrarSesion: document.getElementById(
        'botonCerrarSesion'
    ),

    mensajePanel: document.getElementById(
        'mensajePanel'
    ),

    kpiVentasDia: document.getElementById(
        'kpiVentasDia'
    ),

    kpiVentasTransacciones: document.getElementById(
        'kpiVentasTransacciones'
    ),

    kpiStockCritico: document.getElementById(
        'kpiStockCritico'
    ),

    kpiCajaAbierta: document.getElementById(
        'kpiCajaAbierta'
    ),

    kpiClientesNuevos: document.getElementById(
        'kpiClientesNuevos'
    )
};

let temporizadorMensaje = null;

function textoSeguro(valor) {
    return String(valor ?? '').trim();
}

function formatearFecha(fechaISO) {
    const fecha = textoSeguro(fechaISO).slice(0, 10);

    if (!/^\d{4}-\d{2}-\d{2}$/.test(fecha)) {
        return 'No disponible';
    }

    const [anio, mes, dia] = fecha.split('-');

    return `${dia}/${mes}/${anio}`;
}

function formatearFechaActual() {
    return new Intl.DateTimeFormat('es-VE', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    }).format(new Date());
}

function obtenerIniciales(nombreCompleto) {
    const palabras = textoSeguro(nombreCompleto)
        .split(/\s+/)
        .filter(Boolean);

    if (palabras.length === 0) {
        return 'TV';
    }

    return palabras
        .slice(0, 2)
        .map((palabra) => palabra.charAt(0))
        .join('')
        .toUpperCase();
}

function formatearRol(rol) {
    const roles = {
        PROPIETARIO: 'Propietario',
        ADMINISTRADOR: 'Administrador',
        CAJERO: 'Cajero'
    };

    return roles[rol] || 'Usuario';
}

function formatearMoneda(valor) {
    const numero = Number(valor || 0);
    return `$ ${numero.toLocaleString('es-VE', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    })}`;
}

function mostrarMensaje(mensaje) {
    if (!elementos.mensajePanel) {
        console.warn('mensajePanel no encontrado');
        return;
    }

    window.clearTimeout(temporizadorMensaje);

    elementos.mensajePanel.textContent = mensaje;

    elementos.mensajePanel.classList.add(
        'mensaje-flotante--visible'
    );

    temporizadorMensaje = window.setTimeout(() => {
        elementos.mensajePanel.classList.remove(
            'mensaje-flotante--visible'
        );
    }, 3200);
}

function formatearTendencia(valor) {
    if (valor === null || valor === undefined || Number.isNaN(Number(valor))) {
        return '--';
    }

    const numero = Number(valor);
    const simbolo = numero >= 0 ? '+' : '';
    return `${simbolo}${numero}%`;
}

function actualizarTendenciasKpis(tendencias = {}) {
    document.querySelectorAll('[data-trend]').forEach((elemento) => {
        const clave = textoSeguro(elemento.dataset.trend);
        const valor = tendencias[clave];

        if (valor === null || valor === undefined || Number.isNaN(Number(valor))) {
            elemento.textContent = '';
            elemento.classList.remove('kpi-card__trend--up', 'kpi-card__trend--down');
            elemento.classList.add('kpi-card__trend--empty');
            return;
        }

        elemento.classList.remove('kpi-card__trend--empty');

        const numero = Number(valor);
        const esPositivo = numero >= 0;

        elemento.textContent = formatearTendencia(numero);
        elemento.classList.toggle('kpi-card__trend--up', esPositivo);
        elemento.classList.toggle('kpi-card__trend--down', !esPositivo);
    });
}

function formatearNombreCliente(nombre) {
    const valor = textoSeguro(nombre);

    if (!valor) {
        return 'Cliente contado';
    }

    const nombreNormalizado = valor.toLowerCase();
    if (
        nombreNormalizado.includes('cliente contado') ||
        nombreNormalizado.includes('consumidor final') ||
        nombreNormalizado.includes('consumidor') ||
        nombreNormalizado.includes('publico general')
    ) {
        return 'Cliente contado';
    }

    const partes = valor.split(/\s+/).filter(Boolean);
    if (partes.length >= 2) {
        const nombre = partes[0];
        const segundo = partes[1];
        const inicial = textoSeguro(segundo).charAt(0).toUpperCase();
        return `${nombre} ${inicial}.`;
    }

    return valor;
}

function formatearHora(fechaISO) {
    if (!fechaISO) {
        return '--:--';
    }

    const fecha = new Date(fechaISO);
    if (Number.isNaN(fecha.getTime())) {
        return '--:--';
    }

    return fecha.toLocaleTimeString('es-VE', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
    });
}

function abrirHistorialVentasPanel() {
    const modal = document.getElementById('modalHistorialVentasPanel');
    const cuerpo = document.getElementById('historialVentasBody');

    if (!modal || !cuerpo) {
        return;
    }

    modal.hidden = false;
    modal.setAttribute('aria-hidden', 'false');
    cuerpo.innerHTML = '<tr><td colspan="5">Cargando historial...</td></tr>';

    fetch('/api/ventas?limite=20', {
        cache: 'no-store',
        headers: {
            Accept: 'application/json'
        }
    })
        .then(async (respuesta) => {
            const datos = await respuesta.json();

            if (!respuesta.ok || !datos.ok) {
                throw new Error(
                    datos.mensaje ||
                    'No fue posible cargar el historial.'
                );
            }

            const ventas = Array.isArray(datos.ventas)
                ? datos.ventas
                : [];

            if (ventas.length === 0) {
                cuerpo.innerHTML = '<tr><td colspan="5">No hay ventas registradas.</td></tr>';
                return;
            }

            cuerpo.innerHTML = ventas.map((venta) => {
                const numeroFactura = textoSeguro(venta.numeroFactura || venta.id || 'Sin factura');
                const cliente = formatearNombreCliente(venta.clienteNombre);
                const monto = Number(venta.totalUsd || venta.totalBs || 0);
                const fecha = formatearFecha(venta.creadoEn);
                const hora = formatearHora(venta.creadoEn);

                return `
                    <tr>
                        <td>#${numeroFactura}</td>
                        <td>${cliente}</td>
                        <td>${formatearMoneda(monto)}</td>
                        <td>${fecha}</td>
                        <td>${hora}</td>
                    </tr>
                `;
            }).join('');
        })
        .catch((error) => {
            console.error('Error cargando historial del panel:', error);
            cuerpo.innerHTML = '<tr><td colspan="5">No fue posible cargar el historial.</td></tr>';
        });
}

function cerrarHistorialVentasPanel() {
    const modal = document.getElementById('modalHistorialVentasPanel');

    if (!modal) {
        return;
    }

    modal.hidden = true;
    modal.setAttribute('aria-hidden', 'true');
}

function renderUltimasVentas(ventas = []) {
    const contenedor = document.getElementById('ultimasVentasBody');
    if (!contenedor) {
        return;
    }

    const lista = Array.isArray(ventas) ? ventas : [];

    if (lista.length === 0) {
        contenedor.innerHTML = `
            <tr>
                <td colspan="4">Sin ventas recientes</td>
            </tr>
        `;
        return;
    }

    contenedor.innerHTML = lista.map((venta) => {
        const numeroFactura = venta.numeroFactura ?? venta.id ?? 0;
        const clienteNombre = formatearNombreCliente(venta.clienteNombre);
        const totalUsd = Number(venta.totalUsd || 0);
        const hora = formatearHora(venta.creadoEn);

        return `
            <tr>
                <td>#${numeroFactura}</td>
                <td>${clienteNombre}</td>
                <td>${formatearMoneda(totalUsd)}</td>
                <td>${hora}</td>
            </tr>
        `;
    }).join('');
}

function renderAlertasProductos(alertas = []) {
    const contenedor = document.getElementById(
        'alertasProductosLista'
    );

    if (!contenedor) {
        return;
    }

    const productos = Array.isArray(alertas)
        ? alertas
        : [];

    const irAInventarioConBusqueda = (nombreProducto) => {
        const nombre = textoSeguro(nombreProducto);
        const url = new URL('/inventario', window.location.origin);

        if (nombre) {
            url.searchParams.set('busqueda', nombre);
        }

        window.location.href = url.toString();
    };

    if (productos.length === 0) {
        contenedor.innerHTML = `
            <li>
                <strong>Sin alertas</strong>
                <span>No hay productos bajo el stock mínimo.</span>
            </li>
        `;
        return;
    }

    contenedor.innerHTML = productos.map((producto) => {
        const nombre = textoSeguro(producto.nombre || 'Producto');
        const disponible = Number(producto.disponible || 0);
        const textoCantidad = disponible === 1
            ? '1 unidad restante'
            : `${disponible} unidades restantes`;

        return `
            <li>
                <button
                    type="button"
                    class="alert-list__item"
                    data-producto="${nombre.replace(/"/g, '&quot;')}"
                >
                    <strong>${nombre}</strong>
                    <span>${textoCantidad}</span>
                </button>
            </li>
        `;
    }).join('');

    contenedor.querySelectorAll('.alert-list__item').forEach((boton) => {
        boton.addEventListener('click', () => {
            irAInventarioConBusqueda(boton.dataset.producto || '');
        });
    });
}

function renderTopProductosSemana(productos = []) {
    const contenedor = document.getElementById('topProductosSemanaLista');

    if (!contenedor) {
        return;
    }

    const lista = Array.isArray(productos) ? productos : [];

    if (lista.length === 0) {
        contenedor.innerHTML = `
            <div class="top-productos-table__empty">
                No hay ventas registradas esta semana.
            </div>
        `;
        return;
    }

    contenedor.innerHTML = lista.map((producto) => {
        const posicion = Number(producto.posicion || 0);
        const nombre = textoSeguro(producto.nombre || 'Producto');
        const sku = textoSeguro(producto.sku || '');
        const unidades = Number(producto.unidades || 0);
        const ingreso = Number(producto.ingresoTotal || 0);
        const precioUnitario = Number(producto.precioUnitario || 0);

        const nombreProducto = sku
            ? `<div class="top-productos-item__nombre-wrap"><strong>${nombre}</strong><small>${sku}</small></div>`
            : `<strong class="top-productos-item__nombre-solo">${nombre}</strong>`;

        return `
            <div class="top-productos-table__row">
                <div class="top-productos-item__rank">#${posicion}</div>
                <div class="top-productos-item__nombre">${nombreProducto}</div>
                <div class="top-productos-item__unitario">${formatearMoneda(precioUnitario)}</div>
                <div class="top-productos-item__cantidad">${unidades} und.</div>
                <div class="top-productos-item__monto">${formatearMoneda(ingreso)}</div>
            </div>
        `;
    }).join('');
}

function renderGraficoVentasSemana(ventasSemana = []) {
    const contenedor = document.getElementById(
        'chartVentasSemanal'
    );
    const indicadorMasVendido = document.getElementById(
        'chartVentasMeta'
    );

    if (!contenedor) {
        return;
    }

    const datos = Array.isArray(ventasSemana)
        ? ventasSemana
        : [];

    const mapearDia = (valor) => {
        const texto = textoSeguro(valor).toLowerCase().replace(/\./g, '').trim();

        const equivalencias = {
            l: 'Lun',
            lun: 'Lun',
            m: 'Mar',
            mar: 'Mar',
            mi: 'Mié',
            mie: 'Mié',
            mié: 'Mié',
            mier: 'Mié',
            miercoles: 'Mié',
            j: 'Jue',
            jue: 'Jue',
            juev: 'Jue',
            v: 'Vie',
            vie: 'Vie',
            s: 'Sáb',
            sab: 'Sáb',
            d: 'Dom',
            dom: 'Dom'
        };

        return equivalencias[texto] || textoSeguro(valor).slice(0, 3) || '';
    };

    const maxVenta = datos.reduce(
        (max, item) => Math.max(max, Number(item.total || 0)),
        0
    );

    const diaMasVendido = datos.reduce((mejor, item) => {
        const totalActual = Number(item.total || 0);

        if (!mejor || totalActual > Number(mejor.total || 0)) {
            return item;
        }

        return mejor;
    }, null);

    contenedor.innerHTML = datos.map((item) => {
        const total = Number(item.total || 0);
        const porcentaje = maxVenta > 0
            ? Math.round((total / maxVenta) * 100)
            : 0;
        const alto = total > 0 ? Math.max(porcentaje, 10) : 0;
        const diaFormateado = mapearDia(item.dia);

        return `
            <div class="bar-item ${item.maximo ? 'bar-item--max' : ''}" title="${formatearMoneda(total)} - ${porcentaje}% del día más vendido">
                <span class="bar-item__tooltip">
                    <strong>${formatearMoneda(total)}</strong>
                    <em>${porcentaje}%</em>
                </span>
                <span class="bar-item__value" style="height:${alto}%"></span>
                <small>${diaFormateado}</small>
            </div>
        `;
    }).join('');

    if (indicadorMasVendido) {
        if (diaMasVendido && Number(diaMasVendido.total || 0) > 0) {
            indicadorMasVendido.textContent =
                `Día más vendido: ${diaMasVendido.dia} • ${Math.round((diaMasVendido.total / maxVenta) * 100)}%`;
        } else {
            indicadorMasVendido.textContent = 'Sin ventas esta semana';
        }
    }
}

function actualizarPanel(datos) {
    const negocio = datos.negocio || {};
    const sesion = datos.sesion || {};
    const usuario = sesion.usuario || {};
    const licencia = datos.licencia || {};

    const nombreNegocio =
        negocio.nombreComercial || 'Mi negocio';

    const nombreUsuario =
        usuario.nombreCompleto || 'Usuario';

    const rolUsuario = formatearRol(
        usuario.rol
    );

    if (elementos.nombreNegocioSuperior) {
        elementos.nombreNegocioSuperior.textContent =
            nombreNegocio;
    }

    if (elementos.nombreUsuarioPrincipal) {
        elementos.nombreUsuarioPrincipal.textContent =
            nombreUsuario;
    }

    if (elementos.nombreUsuarioLateral) {
        elementos.nombreUsuarioLateral.textContent =
            nombreUsuario;
    }

    if (elementos.rolUsuarioLateral) {
        elementos.rolUsuarioLateral.textContent =
            rolUsuario;
    }

    if (elementos.avatarUsuarioLateral) {
        elementos.avatarUsuarioLateral.textContent =
            obtenerIniciales(nombreUsuario);
    }

    if (elementos.rolUsuarioTarjeta) {
        elementos.rolUsuarioTarjeta.textContent =
            rolUsuario;
    }

    if (elementos.fechaActualPanel) {
        elementos.fechaActualPanel.textContent =
            formatearFechaActual();
    }

    const licenciaActiva =
        licencia.activa === true &&
        licencia.estado === 'ACTIVA';

    if (elementos.estadoLicenciaSuperior) {
        elementos.estadoLicenciaSuperior.textContent =
            licenciaActiva
                ? 'Licencia activa'
                : 'Licencia no disponible';
    }

    if (elementos.estadoActualizacionSuperior) {
        const disponible = Boolean(datos?.actualizacion?.disponible);
        if (disponible) {
            elementos.estadoActualizacionSuperior.hidden = false;
            elementos.estadoActualizacionSuperior.classList.add('estado-actualizacion--visible');
            elementos.estadoActualizacionSuperior.classList.remove('estado-actualizacion--oculto');
        } else {
            elementos.estadoActualizacionSuperior.hidden = true;
            elementos.estadoActualizacionSuperior.classList.add('estado-actualizacion--oculto');
            elementos.estadoActualizacionSuperior.classList.remove('estado-actualizacion--visible');
        }
    }

    if (elementos.estadoLicenciaTarjeta) {
        elementos.estadoLicenciaTarjeta.textContent =
            licenciaActiva
                ? 'Activa'
                : licencia.estado || 'No disponible';
    }

    if (elementos.detalleLicenciaTarjeta) {
        elementos.detalleLicenciaTarjeta.textContent =
            licenciaActiva
                ? 'La instalación está habilitada para trabajar.'
                : 'Revise la activación de la instalación.';
    }

    if (elementos.vencimientoLicenciaTarjeta) {
        elementos.vencimientoLicenciaTarjeta.textContent =
            formatearFecha(
                licencia.fechaVencimiento
            );
    }
}

async function cargarResumenPanel() {
    try {
        const respuesta = await fetch(
            '/api/panel/resumen',
            {
                cache: 'no-store',
                headers: {
                    'Accept': 'application/json'
                }
            }
        );

        const datos = await respuesta.json();

        if (!respuesta.ok || !datos.ok) {
            throw new Error(
                datos.mensaje ||
                'No fue posible cargar el resumen del panel.'
            );
        }

        const resumen = datos.resumen || {};
        const ventasDia = Number(resumen.ventasDia || 0);
        const transaccionesVenta = Number(resumen.transaccionesVenta || 0);
        const stockCritico = Number(resumen.stockCritico || 0);
        const cajasOperativas = Number(resumen.cajasOperativas || 0);
        const clientesNuevos = Number(resumen.clientesNuevos || 0);

        actualizarTendenciasKpis(resumen.tendencias || {});
        renderUltimasVentas(resumen.ultimasVentas || []);
        renderAlertasProductos(resumen.alertasProductos || []);
        renderGraficoVentasSemana(resumen.ventasSemana || []);
        renderTopProductosSemana(resumen.topProductosSemana || []);

        if (elementos.kpiVentasDia) {
            elementos.kpiVentasDia.textContent =
                formatearMoneda(ventasDia);
        }

        if (elementos.kpiVentasTransacciones) {
            elementos.kpiVentasTransacciones.textContent =
                `${transaccionesVenta} transacciones`;
        }

        if (elementos.kpiStockCritico) {
            elementos.kpiStockCritico.textContent =
                String(stockCritico);
        }

        if (elementos.kpiCajaAbierta) {
            elementos.kpiCajaAbierta.textContent =
                String(cajasOperativas);
        }

        if (elementos.kpiClientesNuevos) {
            elementos.kpiClientesNuevos.textContent =
                String(clientesNuevos);
        }
    } catch (error) {
        console.error(
            'Error cargando resumen del panel:',
            error
        );

        if (elementos.kpiVentasDia) {
            elementos.kpiVentasDia.textContent =
                '$ 0.00';
        }

        if (elementos.kpiVentasTransacciones) {
            elementos.kpiVentasTransacciones.textContent =
                '0 transacciones';
        }

        if (elementos.kpiStockCritico) {
            elementos.kpiStockCritico.textContent = '0';
        }

        if (elementos.kpiCajaAbierta) {
            elementos.kpiCajaAbierta.textContent = '0';
        }

        if (elementos.kpiClientesNuevos) {
            elementos.kpiClientesNuevos.textContent = '0';
        }
    }
}

async function cargarEstadoPanel() {
    try {
        const respuesta = await fetch(
            '/api/aplicacion/estado',
            {
                cache: 'no-store'
            }
        );

        const datos = await respuesta.json();

        if (!respuesta.ok || !datos.ok) {
            throw new Error(
                datos.mensaje ||
                'No fue posible consultar el estado de Tenvik.'
            );
        }

        actualizarPanel(datos);

        if (datos.destino !== '/panel') {
            window.setTimeout(() => {
                window.location.assign(
                    datos.destino || '/'
                );
            }, 150);

            return;
        }

        if (!datos.sesion?.usuario) {
            window.setTimeout(() => {
                window.location.assign(
                    '/iniciar-sesion'
                );
            }, 150);

            return;
        }

        await cargarResumenPanel();
    } catch (error) {
        console.error(
            'Error cargando panel:',
            error
        );

        mostrarMensaje(
            error.message ||
            'No fue posible cargar el panel.'
        );
    }
}

async function cerrarSesion() {
    const textoOriginal =
        elementos.botonCerrarSesion.textContent;

    try {
        elementos.botonCerrarSesion.disabled = true;

        elementos.botonCerrarSesion.textContent =
            'Cerrando...';

        const respuesta = await fetch(
            '/api/autenticacion/cerrar-sesion',
            {
                method: 'POST',
                headers: {
                    'Content-Type':
                        'application/json'
                }
            }
        );

        const datos = await respuesta.json();

        if (!respuesta.ok || !datos.ok) {
            throw new Error(
                datos.mensaje ||
                'No fue posible cerrar la sesión.'
            );
        }

        window.location.assign(
            datos.redireccion || '/iniciar-sesion'
        );
    } catch (error) {
        console.error(
            'Error cerrando sesión:',
            error
        );

        mostrarMensaje(
            error.message ||
            'No fue posible cerrar la sesión.'
        );
    } finally {
        elementos.botonCerrarSesion.disabled = false;

        elementos.botonCerrarSesion.textContent =
            textoOriginal;
    }
}

document.querySelectorAll(
    '[data-modulo]'
).forEach((elemento) => {
    elemento.addEventListener('click', () => {
        const modulo = textoSeguro(
            elemento.dataset.modulo
        );

        if (modulo === 'Ventas' && window.location.pathname === '/panel') {
            abrirHistorialVentasPanel();
            return;
        }

        const rutasDisponibles = {
            'Panel principal': '/panel',
            Clientes: '/clientes',
            Inventario: '/inventario',
            Ventas: '/ventas',
            Reportes: '/reportes',
            Caja: '/caja',
            Usuarios: '/usuarios',
            Configuración: '/configuracion'
        };

        const ruta = rutasDisponibles[modulo];

        if (ruta) {
            window.location.assign(ruta);
            return;
        }

        mostrarMensaje(
            `${modulo} será el próximo módulo que construiremos.`
        );
    });
});

const modalHistorialVentasPanel = document.getElementById('modalHistorialVentasPanel');
if (modalHistorialVentasPanel) {
    modalHistorialVentasPanel.addEventListener('click', (evento) => {
        if (evento.target && evento.target.matches('[data-cerrar-historial-ventas="true"]')) {
            cerrarHistorialVentasPanel();
        }
    });
}

document.addEventListener('keydown', (evento) => {
    if (evento.key === 'Escape') {
        const modal = document.getElementById('modalHistorialVentasPanel');
        if (modal && !modal.hidden) {
            cerrarHistorialVentasPanel();
        }
    }
});

document.querySelectorAll(
    '[data-accion]'
).forEach((elemento) => {
    elemento.addEventListener('click', () => {
        const accion = textoSeguro(
            elemento.dataset.accion
        );

        if (accion === 'reporte-ventas-productos') {
            sessionStorage.setItem(
                'tenvik.focus.ventasProductos',
                'true'
            );
            window.location.assign('/reportes');
            return;
        }

        if (accion === 'actualizar-tasa') {
            sessionStorage.setItem(
                'tenvik.focus.tasa',
                'true'
            );
            window.location.assign('/configuracion');
            return;
        }

        if (accion === 'agregar-inventario') {
            sessionStorage.setItem(
                'tenvik.focus.ingresoInventario',
                'true'
            );
            window.location.assign('/inventario');
            return;
        }

        if (accion === 'nuevo-cajero') {
            sessionStorage.setItem(
                'tenvik.focus.nuevoCajero',
                'true'
            );
            window.location.assign('/usuarios');
            return;
        }

        if (accion === 'agregar-producto-inventario') {
            sessionStorage.setItem(
                'tenvik.focus.nuevoProductoInventario',
                'true'
            );
            window.location.assign('/inventario');
            return;
        }
    });
});

if (elementos.kpiStockCritico) {
    elementos.kpiStockCritico.closest('.kpi-card')?.addEventListener(
        'click',
        () => {
            window.location.assign(
                '/inventario?filtroResumen=STOCK_MINIMO'
            );
        }
    );
}

if (elementos.kpiClientesNuevos) {
    elementos.kpiClientesNuevos.closest('.kpi-card')?.addEventListener(
        'click',
        () => {
            window.location.assign(
                '/clientes?soloSemana=1'
            );
        }
    );
}

if (elementos.estadoActualizacionSuperior) {
    elementos.estadoActualizacionSuperior.addEventListener(
        'click',
        () => {
            sessionStorage.setItem(
                'tenvik.focus.actualizacion',
                'true'
            );
        }
    );
}

elementos.botonCerrarSesion.addEventListener(
    'click',
    cerrarSesion
);

cargarEstadoPanel();