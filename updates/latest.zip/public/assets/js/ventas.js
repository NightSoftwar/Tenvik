'use strict';

/* =========================================================
   TENViK · PUNTO DE VENTA
   CONTEXTO OPERATIVO Y CLIENTE
   ========================================================= */

const DOCUMENTO_CONSUMIDOR_FINAL = 'V-';

const elementos = {
    botonMarcaVentas: document.getElementById(
        'botonMarcaVentas'
    ),

    estadoCajaVentas: document.getElementById(
        'estadoCajaVentas'
    ),

    textoEstadoCajaVentas: document.getElementById(
        'textoEstadoCajaVentas'
    ),

    nombreUsuarioVentas: document.getElementById(
        'nombreUsuarioVentas'
    ),

    rolUsuarioVentas: document.getElementById(
        'rolUsuarioVentas'
    ),

    tasaVentas: document.getElementById(
        'tasaVentas'
    ),

    documentoClienteVentas: document.getElementById(
        'documentoClienteVentas'
    ),

    estadoClienteVentas: document.getElementById(
        'estadoClienteVentas'
    ),

    detalleClienteVentas: document.getElementById(
        'detalleClienteVentas'
    ),

    botonLimpiarClienteVentas: document.getElementById(
        'botonLimpiarClienteVentas'
    ),
    botonEditarClienteVentas: document.getElementById(
        'botonEditarClienteVentas'
    ),
    codigoProductoVentas: document.getElementById(
        'codigoProductoVentas'
    ),

    cantidadProductoVentas: document.getElementById(
        'cantidadProductoVentas'
    ),
    etiquetaCantidadProductoVentas: document.getElementById(
        'etiquetaCantidadProductoVentas'
    ),
    botonBuscarProductoVentas: document.getElementById(
        'botonBuscarProductoVentas'
    ),

    botonAgregarProductoVentas: document.getElementById(
        'botonAgregarProductoVentas'
    ),
    productoSeleccionadoVentas: document.getElementById(
        'productoSeleccionadoVentas'
    ),

    nombreProductoSeleccionadoVentas: document.getElementById(
        'nombreProductoSeleccionadoVentas'
    ),

    detalleProductoSeleccionadoVentas: document.getElementById(
        'detalleProductoSeleccionadoVentas'
    ),

    botonLimpiarProductoSeleccionadoVentas: document.getElementById(
        'botonLimpiarProductoSeleccionadoVentas'
    ),

    cuerpoTablaVentas: document.getElementById(
        'cuerpoTablaVentas'
    ),

    filaVaciaVentas: document.getElementById(
        'filaVaciaVentas'
    ),

    contadorLineasVentas: document.getElementById(
        'contadorLineasVentas'
    ),

    cantidadProductosVentas: document.getElementById(
        'cantidadProductosVentas'
    ),

    cantidadUnidadesVentas: document.getElementById(
        'cantidadUnidadesVentas'
    ),

    subtotalBsVentas: document.getElementById(
        'subtotalBsVentas'
    ),

    ivaBsVentas: document.getElementById(
        'ivaBsVentas'
    ),

    totalBsVentas: document.getElementById(
        'totalBsVentas'
    ),

    totalUsdVentas: document.getElementById(
        'totalUsdVentas'
    ),

    modalBuscarProductoVentas: document.getElementById(
        'modalBuscarProductoVentas'
    ),

    busquedaProductoVentas: document.getElementById(
        'busquedaProductoVentas'
    ),

    resultadosBusquedaProductoVentas: document.getElementById(
        'resultadosBusquedaProductoVentas'
    ),

    botonCerrarBuscarProductoVentas: document.getElementById(
        'botonCerrarBuscarProductoVentas'
    ),

    botonCancelarBuscarProductoVentas: document.getElementById(
        'botonCancelarBuscarProductoVentas'
    ),
    botonCobrarVentas: document.getElementById(
        'botonCobrarVentas'
    ),
    botonVaciarCarritoVentas: document.getElementById(
        'botonVaciarCarritoVentas'
    ),

    botonIrPanelVentas: document.getElementById(
        'botonIrPanelVentas'
    ),
    botonCerrarSesionVentas: document.getElementById(
        'botonCerrarSesionVentas'
    ),

    modalRegistroRapidoClienteVentas: document.getElementById(
        'modalRegistroRapidoClienteVentas'
    ),
    subtituloRegistroRapidoClienteVentas:
        document.getElementById(
            'subtituloRegistroRapidoClienteVentas'
        ),

    tituloRegistroRapidoClienteVentas:
        document.getElementById(
            'tituloRegistroRapidoClienteVentas'
        ),
    formularioRegistroRapidoClienteVentas:
        document.getElementById(
            'formularioRegistroRapidoClienteVentas'
        ),

    tipoPersonaClienteRapidoVentas: document.getElementById(
        'tipoPersonaClienteRapidoVentas'
    ),

    identificacionClienteRapidoVentas: document.getElementById(
        'identificacionClienteRapidoVentas'
    ),

    nombreClienteRapidoVentas: document.getElementById(
        'nombreClienteRapidoVentas'
    ),

    etiquetaNombreClienteRapidoVentas:
        document.getElementById(
            'etiquetaNombreClienteRapidoVentas'
        ),
    direccionClienteRapidoVentas: document.getElementById(
        'direccionClienteRapidoVentas'
    ),
    telefonoClienteRapidoVentas: document.getElementById(
        'telefonoClienteRapidoVentas'
    ),

    correoClienteRapidoVentas: document.getElementById(
        'correoClienteRapidoVentas'
    ),

    mensajeRegistroRapidoClienteVentas:
        document.getElementById(
            'mensajeRegistroRapidoClienteVentas'
        ),

    botonCerrarRegistroRapidoClienteVentas:
        document.getElementById(
            'botonCerrarRegistroRapidoClienteVentas'
        ),

    botonCancelarRegistroRapidoClienteVentas:
        document.getElementById(
            'botonCancelarRegistroRapidoClienteVentas'
        ),

    botonConsumidorFinalRegistroVentas:
        document.getElementById(
            'botonConsumidorFinalRegistroVentas'
        ),

    botonGuardarRegistroRapidoClienteVentas:
        document.getElementById(
            'botonGuardarRegistroRapidoClienteVentas'
        ),

    mensajeFlotanteVentas: document.getElementById(
        'mensajeFlotanteVentas'
    ),
    modalCobroVentas: document.getElementById('modalCobroVentas'),
    botonCerrarCobroVentas: document.getElementById('botonCerrarCobroVentas'),
    botonCancelarCobroVentas: document.getElementById('botonCancelarCobroVentas'),
    botonConfirmarCobroVentas: document.getElementById('botonConfirmarCobroVentas'),

    modalTotalBsVentas: document.getElementById('modalTotalBsVentas'),
    modalTotalUsdVentas: document.getElementById('modalTotalUsdVentas'),
    modalPendienteVentas: document.getElementById('modalPendienteVentas'),
    modalCanceladoVentas: document.getElementById('modalCanceladoVentas'),
    modalDiferenciaVentas: document.getElementById('modalDiferenciaVentas'),
    modalVueltoVentas: document.getElementById('modalVueltoVentas'),

    modalZelleVentas: document.getElementById('modalZelleVentas'),
    formularioZelleVentas: document.getElementById('formularioZelleVentas'),
    botonCerrarZelleVentas: document.getElementById('botonCerrarZelleVentas'),
    botonCancelarZelleVentas: document.getElementById('botonCancelarZelleVentas'),
    botonConfirmarZelleVentas: document.getElementById('botonConfirmarZelleVentas'),
    zelleMontoVentas: document.getElementById('zelleMontoVentas'),
    zelleRemitenteVentas: document.getElementById('zelleRemitenteVentas'),
    zelleReferenciaVentas: document.getElementById('zelleReferenciaVentas'),
    zelleMensajeVentas: document.getElementById('zelleMensajeVentas'),

    modalConfirmacionVentas: document.getElementById('modalConfirmacionVentas'),
    fondoConfirmacionVentas: document.getElementById('fondoConfirmacionVentas'),
    formularioConfirmacionVentas: document.getElementById('formularioConfirmacionVentas'),
    tituloConfirmacionVentas: document.getElementById('tituloModalConfirmacionVentas'),
    descripcionConfirmacionVentas: document.getElementById('descripcionConfirmacionVentas'),
    subtextoConfirmacionVentas: document.getElementById('subtextoConfirmacionVentas'),
    botonCerrarConfirmacionVentas: document.getElementById('botonCerrarConfirmacionVentas'),
    botonCancelarConfirmacionVentas: document.getElementById('botonCancelarConfirmacionVentas'),
    botonConfirmarConfirmacionVentas: document.getElementById('botonConfirmarConfirmacionVentas'),

    metodoPagoVentas1: document.getElementById('metodoPagoVentas1'),
    montoPagoVentas1: document.getElementById('montoPagoVentas1'),
    referenciaPagoVentas1: document.getElementById('referenciaPagoVentas1'),
    estadoPagoVentas1: document.getElementById('estadoPagoVentas1'),

    metodoPagoVentas2: document.getElementById('metodoPagoVentas2'),
    montoPagoVentas2: document.getElementById('montoPagoVentas2'),
    referenciaPagoVentas2: document.getElementById('referenciaPagoVentas2'),

    metodoPagoVentas3: document.getElementById('metodoPagoVentas3'),
    montoPagoVentas3: document.getElementById('montoPagoVentas3'),
    referenciaPagoVentas3: document.getElementById('referenciaPagoVentas3'),

    metodoPagoVentas4: document.getElementById('metodoPagoVentas4'),
    montoPagoVentas4: document.getElementById('montoPagoVentas4'),
    referenciaPagoVentas4: document.getElementById('referenciaPagoVentas4'),

    metodoPagoVentas5: document.getElementById('metodoPagoVentas5'),
    montoPagoVentas5: document.getElementById('montoPagoVentas5'),
    referenciaPagoVentas5: document.getElementById('referenciaPagoVentas5'),

    modalAutorizarOperacionVentas: document.getElementById('modalAutorizarOperacionVentas'),
    fondoAutorizarOperacionVentas: document.getElementById('fondoAutorizarOperacionVentas'),
    formularioAutorizarOperacionVentas: document.getElementById('formularioAutorizarOperacionVentas'),
    tituloAutorizarOperacionVentas: document.getElementById('tituloAutorizarOperacionVentas'),
    descripcionAutorizarOperacionVentas: document.getElementById('descripcionAutorizarOperacionVentas'),
    claveAutorizarOperacionVentas: document.getElementById('claveAutorizarOperacionVentas'),
    mensajeAutorizarOperacionVentas: document.getElementById('mensajeAutorizarOperacionVentas'),
    botonCerrarAutorizarOperacionVentas: document.getElementById('botonCerrarAutorizarOperacionVentas'),
    botonCancelarAutorizarOperacionVentas: document.getElementById('botonCancelarAutorizarOperacionVentas'),
    botonConfirmarAutorizarOperacionVentas: document.getElementById('botonConfirmarAutorizarOperacionVentas'),

    modalHistorialVentas: document.getElementById('modalHistorialVentas'),
    fondoHistorialVentas: document.getElementById('fondoHistorialVentas'),
    botonCerrarHistorialVentas: document.getElementById('botonCerrarHistorialVentas'),
    botonCancelarHistorialVentas: document.getElementById('botonCancelarHistorialVentas'),
    botonActualizarHistorialVentas: document.getElementById('botonActualizarHistorialVentas'),
    botonBuscarFacturaHistorialVentas: document.getElementById('botonBuscarFacturaHistorialVentas'),
    busquedaHistorialVentas: document.getElementById('busquedaHistorialVentas'),
    estadoHistorialVentas: document.getElementById('estadoHistorialVentas'),
    listadoHistorialVentas: document.getElementById('listadoHistorialVentas'),
    detalleHistorialVentas: document.getElementById('detalleHistorialVentas'),
};

const estado = {
    contexto: null,
    clienteSeleccionado: null,
    puedeVender: false,
    cargandoContexto: false,
    buscandoCliente: false,
    guardandoClienteRapido: false,
    modalClienteRapidoAbierto: false,
    temporizadorMensaje: null,
    modoCliente: 'REGISTRO',
    clienteEditandoId: null,
    cargandoClienteEdicion: false,
    productoSeleccionado: null,
    zelleAutorizacionValidada: false,
    zelleAutorizacionFilaNumero: null,
    confirmacionVentas: {
        ejecucion: null,
        textoTitulo: '',
        textoDescripcion: '',
        textoConfirmar: ''
    },
    productoEditandoCarritoId: null,
    carrito: [],
    buscandoProducto: false,
    modalBuscarProductoAbierto: false,
    resultadosBusquedaProductos: [],
    temporizadorBusquedaProducto: null,
    autorizarClaveVentasRequerida: null,
    dvAutorizacionValidada: false,
    confirmacionVentas: {
        ejecucion: null,
        textoTitulo: '',
        textoDescripcion: '',
        textoConfirmar: ''
    }
};
estado.operacionAutorizacionPendiente = null;
estado.claveTemporalHistorialVentas = null;
estado.claveTemporalDevolucionVentas = null;
estado.ventaHistorialSeleccionada = null;
estado.reimprimiendoHistorialVentas = false;
let devolucionVentasPreparada = null;
let devolucionVentasConfirmando = false;
let pasoDevolucionVentas = 'PRODUCTOS';
let ultimoEnterPago = { input: null, timestamp: 0 };

const METODOS_DEVOLUCION_VENTAS = {
    EFECTIVO_BS: {
        codigo: 'EFECTIVO_BS',
        nombre: 'Efectivo Bs.',
        moneda: 'VES',
        requiereReferencia: false
    },

    EFECTIVO_USD: {
        codigo: 'EFECTIVO_USD',
        nombre: 'Efectivo USD',
        moneda: 'USD',
        requiereReferencia: false
    },

    PAGO_MOVIL: {
        codigo: 'PAGO_MOVIL',
        nombre: 'Pago móvil',
        moneda: 'VES',
        requiereReferencia: true
    },

    TRANSFERENCIA_BS: {
        codigo: 'TRANSFERENCIA_BS',
        nombre: 'Transferencia Bs.',
        moneda: 'VES',
        requiereReferencia: true
    },

    PUNTO_VENTA: {
        codigo: 'PUNTO_VENTA',
        nombre: 'Punto de venta',
        moneda: 'VES',
        requiereReferencia: true
    },

    BIOPAGO: {
        codigo: 'BIOPAGO',
        nombre: 'Biopago',
        moneda: 'VES',
        requiereReferencia: true
    },
    DV: {
        codigo: 'DV',
        nombre: 'Devolución (consumir)',
        moneda: 'VES',
        requiereReferencia: false
    }
};

let contadorMetodosDevolucionVentas = 0;

/* =========================================================
   UTILIDADES
   ========================================================= */

function obtenerPrimerValorDisponible(...valores) {
    for (const valor of valores) {
        if (
            valor !== null &&
            valor !== undefined &&
            String(valor).trim() !== ''
        ) {
            return valor;
        }
    }

    return null;
}

function convertirNumero(valor) {
    const numero = Number(valor ?? 0);

    return Number.isFinite(numero)
        ? numero
        : 0;
}

function formatearNumero(valor) {
    return new Intl.NumberFormat(
        'es-VE',
        {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }
    ).format(
        convertirNumero(valor)
    );
}

function normalizarTextoMontoPago(valor) {
    const texto = String(valor ?? '')
        .trim()
        .replace(/\s+/g, '')
        .replace(/[^\d,.-]/g, '');

    if (!texto) {
        return '';
    }

    if (!texto.includes(',') && !texto.includes('.')) {
        return texto;
    }

    const ultimoPunto = texto.lastIndexOf('.');
    const ultimaComa = texto.lastIndexOf(',');

    if (ultimaComa > ultimoPunto) {
        return texto
            .replace(/\./g, '')
            .replace(',', '.');
    }

    if (ultimoPunto > ultimaComa) {
        const parteEntera = texto.slice(0, ultimoPunto);
        const parteDecimal = texto.slice(ultimoPunto + 1);

        if (parteDecimal.length === 3 && parteEntera.replace(/\D/g, '').length > 0) {
            return parteEntera.replace(/,/g, '') + parteDecimal;
        }

        return texto.replace(/,/g, '');
    }

    if (texto.includes(',')) {
        return texto.replace(/,/g, '.');
    }

    return texto;
}

function obtenerMontoPagoNormalizado(valor) {
    const textoNormalizado = normalizarTextoMontoPago(valor);

    if (!textoNormalizado) {
        return 0;
    }

    const numero = Number(textoNormalizado);

    return Number.isFinite(numero)
        ? numero
        : 0;
}

function formatearMontoPagoInput(input) {
    const monto = obtenerMontoPagoNormalizado(input.value);

    if (monto === 0 && String(input.value ?? '').trim() === '') {
        input.value = '';
        return;
    }

    input.value = new Intl.NumberFormat('de-DE', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
        signDisplay: 'auto'
    }).format(monto);
}

function formatearBolivares(valor) {
    return `Bs. ${formatearNumero(valor)}`;
}

function limpiarTexto(valor) {
    return String(valor || '')
        .trim();
}

function normalizarDocumentoCliente(valor) {
    let documento = limpiarTexto(valor)
        .toUpperCase()
        .replace(/\s+/g, '');

    /*
        Permite escribir V12345678 y transforma automáticamente
        el resultado a V-12345678.
    */
    if (/^[VJPC]\d/.test(documento)) {
        documento =
            `${documento.slice(0, 1)}-${documento.slice(1)}`;
    }

    return documento;
}

function esDocumentoConsumidorFinal(documento) {
    return normalizarDocumentoCliente(documento) ===
        DOCUMENTO_CONSUMIDOR_FINAL;
}

function esPrefijoIncompleto(documento) {
    const documentoSeguro =
        normalizarDocumentoCliente(documento);

    return [
        'J-',
        'P-',
        'C-'
    ].includes(documentoSeguro);
}

function inferirTipoPersona(documento) {
    const documentoSeguro =
        normalizarDocumentoCliente(documento);

    return documentoSeguro.startsWith('J-')
        ? 'JURIDICA'
        : 'NATURAL';
}

function normalizarRolVisible(rol) {
    const rolSeguro = String(rol || '')
        .trim()
        .toUpperCase();

    if (rolSeguro === 'PROPIETARIO') {
        return 'Propietario';
    }

    if (rolSeguro === 'CAJERO') {
        return 'Cajero';
    }

    return rolSeguro || 'Usuario';
}

function obtenerTasaDelContexto(contexto) {
    const turno =
        contexto?.turnoActivo || {};

    const tasaVigente =
        contexto?.tasaVigente || {};

    return obtenerPrimerValorDisponible(
        turno.tasaUsdVes,
        turno.tasa_usd_ves,
        turno.valorUsdVes,
        turno.valor_usd_ves,

        tasaVigente.valorUsdVes,
        tasaVigente.valor_usd_ves,
        tasaVigente.valor,
        tasaVigente.tasa
    );
}

function obtenerNombreCliente(cliente) {
    const datosCliente =
        cliente?.cliente &&
            typeof cliente.cliente === 'object'
            ? cliente.cliente
            : cliente || {};

    const nombreDirecto =
        obtenerPrimerValorDisponible(
            datosCliente.nombre_o_razon_social,
            datosCliente.nombreORazonSocial,

            datosCliente.nombreCompleto,
            datosCliente.nombre_completo,

            datosCliente.nombreRazonSocial,
            datosCliente.nombre_razon_social,

            datosCliente.razonSocial,
            datosCliente.razon_social,

            datosCliente.nombreCliente,
            datosCliente.nombre_cliente,

            datosCliente.nombres,
            datosCliente.nombre,

            datosCliente.descripcion
        );

    if (nombreDirecto) {
        return nombreDirecto;
    }

    const partesNombre = [
        datosCliente.primerNombre,
        datosCliente.primer_nombre,
        datosCliente.segundoNombre,
        datosCliente.segundo_nombre,
        datosCliente.primerApellido,
        datosCliente.primer_apellido,
        datosCliente.segundoApellido,
        datosCliente.segundo_apellido,
        datosCliente.apellidos
    ]
        .map((parte) => limpiarTexto(parte))
        .filter(Boolean);

    if (partesNombre.length > 0) {
        return partesNombre.join(' ');
    }

    return 'Cliente registrado';
}
function obtenerDocumentoCliente(cliente) {
    return obtenerPrimerValorDisponible(
        cliente?.identificacion,
        cliente?.identificacionFiscal,
        cliente?.identificacion_fiscal,
        cliente?.cedulaRif,
        cliente?.cedula_rif,
        cliente?.documento,
        cliente?.rif,
        cliente?.cedula,
        null
    );
}
function obtenerObjetoCliente(cliente) {
    if (
        cliente?.cliente &&
        typeof cliente.cliente === 'object'
    ) {
        return cliente.cliente;
    }

    return cliente || {};
}

function obtenerClienteId(cliente) {
    const datosCliente =
        obtenerObjetoCliente(cliente);

    const id = obtenerPrimerValorDisponible(
        datosCliente.id,
        datosCliente.clienteId,
        datosCliente.cliente_id
    );

    const idNumerico = Number.parseInt(id, 10);

    return Number.isInteger(idNumerico) &&
        idNumerico > 0
        ? idNumerico
        : null;
}

function obtenerDireccionCliente(cliente) {
    const datosCliente =
        obtenerObjetoCliente(cliente);

    return obtenerPrimerValorDisponible(
        datosCliente.direccion,
        datosCliente.direccionFiscal,
        datosCliente.direccion_fiscal,
        ''
    );
}

function obtenerTelefonoCliente(cliente) {
    const datosCliente =
        obtenerObjetoCliente(cliente);

    return obtenerPrimerValorDisponible(
        datosCliente.telefono,
        datosCliente.celular,
        ''
    );
}

function obtenerCorreoCliente(cliente) {
    const datosCliente =
        obtenerObjetoCliente(cliente);

    return obtenerPrimerValorDisponible(
        datosCliente.correo,
        datosCliente.email,
        ''
    );
}
function enfocarElemento(elemento) {
    if (!elemento || elemento.disabled) {
        return;
    }

    window.setTimeout(() => {
        elemento.focus();
    }, 40);
}

function enfocarDocumentoCliente() {
    enfocarElemento(
        elementos.documentoClienteVentas
    );

    window.setTimeout(() => {
        const campo =
            elementos.documentoClienteVentas;

        const longitud = campo.value.length;

        campo.setSelectionRange(
            longitud,
            longitud
        );
    }, 45);
}

function enfocarCodigoProducto() {
    enfocarElemento(
        elementos.codigoProductoVentas
    );
}

function mostrarMensaje(mensaje) {
    window.clearTimeout(
        estado.temporizadorMensaje
    );

    elementos.mensajeFlotanteVentas.textContent =
        mensaje;

    elementos.mensajeFlotanteVentas.hidden = false;

    estado.temporizadorMensaje =
        window.setTimeout(() => {
            elementos.mensajeFlotanteVentas.hidden =
                true;
        }, 4200);
}
/* =========================================================
   PRODUCTOS Y CARRITO
   ========================================================= */

function numeroDecimalSeguro(valor) {
    const numero = Number(
        String(valor ?? '0')
            .replace(/\s+/g, '')
            .replace(',', '.')
    );

    return Number.isFinite(numero)
        ? numero
        : 0;
}

function formatearUsd(valor) {
    return `US$ ${formatearNumero(valor)}`;
}

function formatearCantidadGeneral(valor) {
    return new Intl.NumberFormat(
        'es-VE',
        {
            minimumFractionDigits: 0,
            maximumFractionDigits: 3
        }
    ).format(
        numeroDecimalSeguro(valor)
    );
}

function esProductoPorPesoVentas(producto) {
    const tipoVenta = String(
        producto?.tipoVenta ||
        producto?.tipo_venta ||
        ''
    )
        .trim()
        .toUpperCase();

    const unidad = String(
        producto?.unidadMedida ||
        producto?.unidad_medida ||
        ''
    )
        .trim()
        .toUpperCase();

    return tipoVenta === 'FRACCIONABLE' ||
        unidad === 'KG';
}

function obtenerUnidadProductoVentas(producto) {
    return esProductoPorPesoVentas(producto)
        ? 'kg'
        : 'und';
}

function obtenerDescripcionTipoVenta(producto) {
    return esProductoPorPesoVentas(producto)
        ? 'Por peso · KG'
        : 'Por unidad · UND';
}

function formatearCantidadProductoVentas(
    cantidad,
    producto
) {
    const porPeso =
        esProductoPorPesoVentas(producto);

    return `${new Intl.NumberFormat(
        'es-VE',
        {
            minimumFractionDigits: porPeso ? 3 : 0,
            maximumFractionDigits: porPeso ? 3 : 0
        }
    ).format(
        numeroDecimalSeguro(cantidad)
    )} ${obtenerUnidadProductoVentas(producto)}`;
}

function obtenerConfiguracionFinancieraVentas() {
    return estado.contexto?.configuracionFinanciera || {};
}

function obtenerIvaPorcentajeVentas() {
    return numeroDecimalSeguro(
        obtenerConfiguracionFinancieraVentas()
            .ivaPorcentaje || 0
    );
}

function preciosIncluyenIvaVentas() {
    const valor =
        obtenerConfiguracionFinancieraVentas()
            .preciosIncluyenIva;

    return valor === true ||
        valor === 1 ||
        valor === '1' ||
        valor === 'true';
}

function obtenerTasaVentaNumero() {
    return numeroDecimalSeguro(
        obtenerTasaDelContexto(
            estado.contexto || {}
        )
    );
}

function normalizarCantidadProductoVenta(
    valor,
    producto
) {
    const texto = limpiarTexto(valor)
        .replace(/\s+/g, '')
        .replace(',', '.');

    const porPeso =
        esProductoPorPesoVentas(producto);

    const expresion = porPeso
        ? /^(?:0|[1-9]\d{0,14})(?:\.\d{1,3})?$/
        : /^(?:0|[1-9]\d{0,14})$/;

    if (!expresion.test(texto)) {
        return null;
    }

    const numero = Number(texto);

    if (
        !Number.isFinite(numero) ||
        numero <= 0
    ) {
        return null;
    }

    return numero;
}

function obtenerCantidadProductoEnCarrito(productoId) {
    return estado.carrito
        .filter((linea) => Number(linea.producto.id) === Number(productoId))
        .reduce((total, linea) => {
            return total + numeroDecimalSeguro(linea.cantidad);
        }, 0);
}

function validarExistenciaDisponible(
    producto,
    cantidadNueva
) {
    const disponible = numeroDecimalSeguro(
        producto.existenciaDisponible
    );

    const cantidadActual =
        obtenerCantidadProductoEnCarrito(producto.id);

    const cantidadFinal =
        cantidadActual + cantidadNueva;

    return cantidadFinal <= disponible + 0.000001;
}

function calcularLineaVenta(linea) {
    const producto =
        linea.producto;

    const cantidad =
        numeroDecimalSeguro(linea.cantidad);

    const precioUnitarioUsd =
        numeroDecimalSeguro(
            producto.precioVentaUsd
        );

    const brutoUsd =
        precioUnitarioUsd * cantidad;

    const ivaPorcentaje =
        producto.aplicaIva
            ? obtenerIvaPorcentajeVentas()
            : 0;

    let subtotalUsd = brutoUsd;
    let ivaUsd = 0;
    let totalUsd = brutoUsd;

    if (ivaPorcentaje > 0) {
        if (preciosIncluyenIvaVentas()) {
            subtotalUsd =
                brutoUsd / (1 + (ivaPorcentaje / 100));

            ivaUsd =
                brutoUsd - subtotalUsd;

            totalUsd =
                brutoUsd;
        } else {
            subtotalUsd =
                brutoUsd;

            ivaUsd =
                brutoUsd * (ivaPorcentaje / 100);

            totalUsd =
                subtotalUsd + ivaUsd;
        }
    }

    const tasa =
        obtenerTasaVentaNumero();

    return {
        cantidad,
        precioUnitarioUsd,
        ivaPorcentaje,
        subtotalUsd,
        ivaUsd,
        totalUsd,

        subtotalBs:
            subtotalUsd * tasa,

        ivaBs:
            ivaUsd * tasa,

        totalBs:
            totalUsd * tasa
    };
}

function calcularTotalesVenta() {
    return estado.carrito.reduce(
        (totales, linea) => {
            const calculo =
                calcularLineaVenta(linea);

            totales.subtotalUsd += calculo.subtotalUsd;
            totales.ivaUsd += calculo.ivaUsd;
            totales.totalUsd += calculo.totalUsd;

            totales.subtotalBs += calculo.subtotalBs;
            totales.ivaBs += calculo.ivaBs;
            totales.totalBs += calculo.totalBs;

            return totales;
        },
        {
            subtotalUsd: 0,
            ivaUsd: 0,
            totalUsd: 0,
            subtotalBs: 0,
            ivaBs: 0,
            totalBs: 0
        }
    );
}

function actualizarTotalesVenta() {
    const totales =
        calcularTotalesVenta();

    elementos.subtotalBsVentas.textContent =
        formatearBolivares(totales.subtotalBs);

    elementos.ivaBsVentas.textContent =
        formatearBolivares(totales.ivaBs);

    elementos.totalBsVentas.textContent =
        formatearBolivares(totales.totalBs);

    elementos.totalUsdVentas.textContent =
        formatearUsd(totales.totalUsd);
}

function actualizarContadoresCarrito() {
    const lineas =
        estado.carrito.length;

    const cantidadTotal =
        estado.carrito.reduce(
            (total, linea) => {
                return total + numeroDecimalSeguro(
                    linea.cantidad
                );
            },
            0
        );

    elementos.contadorLineasVentas.textContent =
        lineas === 1
            ? '1 producto'
            : `${lineas} productos`;

    elementos.cantidadProductosVentas.textContent =
        String(lineas);

    elementos.cantidadUnidadesVentas.textContent =
        formatearCantidadGeneral(cantidadTotal);
}

function crearCelda(texto, clase = '') {
    const celda = document.createElement('td');

    if (clase) {
        celda.className = clase;
    }

    celda.textContent = texto;

    return celda;
}

function renderizarCarritoVentas() {
    elementos.cuerpoTablaVentas.replaceChildren();

    if (estado.carrito.length === 0) {
        elementos.cuerpoTablaVentas.appendChild(
            elementos.filaVaciaVentas
        );
    } else {
        const fragmento =
            document.createDocumentFragment();

        estado.carrito.forEach((linea) => {
            const producto =
                linea.producto;

            const calculo =
                calcularLineaVenta(linea);

            const fila =
                document.createElement('tr');

            fila.dataset.productoId =
                String(producto.id);

            if (
                Number(estado.productoEditandoCarritoId) ===
                Number(producto.id)
            ) {
                fila.classList.add(
                    'tabla-ventas__fila-editando'
                );
            }

            fila.appendChild(
                crearCelda(
                    producto.codigoInterno || producto.codigoBarras || '—'
                )
            );

            const celdaDescripcion =
                document.createElement('td');

            const descripcion =
                document.createElement('div');

            descripcion.className =
                'producto-carrito-ventas';

            const nombre =
                document.createElement('strong');

            nombre.textContent =
                producto.nombre || 'Producto';

            const detalle =
                document.createElement('span');

            detalle.textContent =
                obtenerDescripcionTipoVenta(producto);

            descripcion.append(
                nombre,
                detalle
            );

            celdaDescripcion.appendChild(
                descripcion
            );

            fila.appendChild(
                celdaDescripcion
            );

            fila.appendChild(
                crearCelda(
                    formatearCantidadProductoVentas(
                        linea.cantidad,
                        producto
                    ),
                    'celda-cantidad-ventas'
                )
            );

            fila.appendChild(
                crearCelda(
                    `${formatearUsd(
                        calculo.precioUnitarioUsd
                    )} / ${obtenerUnidadProductoVentas(producto)}`,
                    'celda-monto-ventas'
                )
            );

            fila.appendChild(
                crearCelda(
                    calculo.ivaPorcentaje > 0
                        ? `${formatearNumero(
                            calculo.ivaPorcentaje
                        )}%`
                        : 'Exento',
                    'celda-monto-ventas'
                )
            );

            fila.appendChild(
                crearCelda(
                    formatearBolivares(
                        calculo.ivaBs
                    ),
                    'celda-monto-ventas'
                )
            );

            fila.appendChild(
                crearCelda(
                    formatearBolivares(
                        calculo.subtotalBs
                    ),
                    'celda-monto-ventas'
                )
            );

            fila.appendChild(
                crearCelda(
                    formatearBolivares(
                        calculo.totalBs
                    ),
                    'celda-monto-ventas'
                )
            );

            const celdaAccion =
                document.createElement('td');

            const acciones =
                document.createElement('div');

            acciones.className =
                'acciones-carrito-ventas';

            const botonEditar =
                document.createElement('button');

            botonEditar.type = 'button';
            botonEditar.className =
                'boton-editar-producto-ventas';
            botonEditar.textContent =
                'Editar';
            botonEditar.dataset.editarProductoId =
                String(producto.id);

            const botonQuitar =
                document.createElement('button');

            botonQuitar.type = 'button';
            botonQuitar.className =
                'boton-quitar-producto-ventas';
            botonQuitar.textContent =
                'Quitar';
            botonQuitar.dataset.quitarProductoId =
                String(producto.id);

            acciones.append(
                botonEditar,
                botonQuitar
            );

            celdaAccion.appendChild(
                acciones
            );

            fila.appendChild(
                celdaAccion
            );

            fragmento.appendChild(
                fila
            );
        });

        elementos.cuerpoTablaVentas.appendChild(
            fragmento
        );
    }

    actualizarContadoresCarrito();
    actualizarTotalesVenta();
    actualizarControlesSegunCaja();
}

function limpiarProductoSeleccionado({
    enfocar = false
} = {}) {
    estado.productoSeleccionado = null;
    estado.productoEditandoCarritoId = null;

    elementos.productoSeleccionadoVentas.hidden =
        true;

    elementos.nombreProductoSeleccionadoVentas.textContent =
        '—';

    elementos.detalleProductoSeleccionadoVentas.textContent =
        '—';

    elementos.codigoProductoVentas.value =
        '';

    elementos.cantidadProductoVentas.value =
        '1';

    elementos.etiquetaCantidadProductoVentas.textContent =
        'Cantidad';

    elementos.cantidadProductoVentas.inputMode =
        'numeric';

    elementos.cantidadProductoVentas.placeholder =
        '1';

    elementos.botonAgregarProductoVentas.innerHTML =
        '<span aria-hidden="true">+</span> Agregar';

    renderizarCarritoVentas();

    actualizarControlesSegunCaja();

    if (enfocar) {
        enfocarCodigoProducto();
    }
}
function cancelarEdicionProductoCarrito({
    mostrarAviso = false
} = {}) {
    if (estado.productoEditandoCarritoId === null) {
        return;
    }

    estado.productoEditandoCarritoId = null;

    elementos.botonAgregarProductoVentas.innerHTML =
        '<span aria-hidden="true">+</span> Agregar';

    if (mostrarAviso) {
        mostrarMensaje(
            'Edición cancelada. El producto seleccionado se agregará como una nueva línea.'
        );
    }

    renderizarCarritoVentas();
}
function seleccionarProductoVenta(
    producto,
    codigoSeleccionado = null
) {
    if (!producto) {
        mostrarMensaje(
            'No se recibió un producto válido.'
        );

        return;
    }

    const productoId =
        Number(producto.id);

    const editandoProductoId =
        estado.productoEditandoCarritoId === null
            ? null
            : Number(estado.productoEditandoCarritoId);

    if (
        editandoProductoId !== null &&
        editandoProductoId !== productoId
    ) {
        cancelarEdicionProductoCarrito({
            mostrarAviso: true
        });
    }

    const disponible =
        numeroDecimalSeguro(
            producto.existenciaDisponible
        );

    if (disponible <= 0) {
        mostrarMensaje(
            'Este producto no tiene existencia disponible.'
        );

        return;
    }

    estado.productoSeleccionado =
        producto;

    const porPeso =
        esProductoPorPesoVentas(producto);

    elementos.codigoProductoVentas.value =
        codigoSeleccionado ||
        producto.codigoInterno ||
        producto.codigoBarras ||
        '';

    elementos.etiquetaCantidadProductoVentas.textContent =
        porPeso
            ? 'Peso kg'
            : 'Cantidad';

    elementos.cantidadProductoVentas.inputMode =
        porPeso
            ? 'decimal'
            : 'numeric';

    elementos.cantidadProductoVentas.placeholder =
        porPeso
            ? 'Ej.: 0,500'
            : 'Ej.: 1';

    elementos.cantidadProductoVentas.value =
        porPeso
            ? ''
            : '1';

    elementos.nombreProductoSeleccionadoVentas.textContent =
        `${codigoSeleccionado || producto.codigoInterno || producto.codigoBarras || '—'} · ${producto.nombre}`;

    elementos.detalleProductoSeleccionadoVentas.textContent =
        `${formatearUsd(
            producto.precioVentaUsd
        )} / ${obtenerUnidadProductoVentas(producto)} · Disponible: ${formatearCantidadProductoVentas(
            producto.existenciaDisponible,
            producto
        )}`;

    elementos.productoSeleccionadoVentas.hidden =
        false;

    actualizarControlesSegunCaja();

    enfocarElemento(
        elementos.cantidadProductoVentas
    );

    window.setTimeout(() => {
        elementos.cantidadProductoVentas.select();
    }, 60);
}
function formatearCantidadParaCampoVentas(
    cantidad,
    producto
) {
    const numero =
        numeroDecimalSeguro(cantidad);

    if (esProductoPorPesoVentas(producto)) {
        return new Intl.NumberFormat(
            'es-VE',
            {
                minimumFractionDigits: 3,
                maximumFractionDigits: 3
            }
        ).format(numero);
    }

    return String(
        Math.trunc(numero)
    );
}

function iniciarEdicionProductoCarrito(productoId) {
    const linea = estado.carrito.find((item) => {
        return Number(item.producto.id) ===
            Number(productoId);
    });

    if (!linea) {
        mostrarMensaje(
            'No se encontró la línea del carrito.'
        );

        return;
    }

    estado.productoEditandoCarritoId =
        Number(linea.producto.id);

    seleccionarProductoVenta(
        linea.producto
    );

    estado.productoEditandoCarritoId =
        Number(linea.producto.id);

    elementos.cantidadProductoVentas.value =
        formatearCantidadParaCampoVentas(
            linea.cantidad,
            linea.producto
        );

    elementos.botonAgregarProductoVentas.innerHTML =
        '<span aria-hidden="true">✓</span> Actualizar';

    renderizarCarritoVentas();

    enfocarElemento(
        elementos.cantidadProductoVentas
    );

    window.setTimeout(() => {
        elementos.cantidadProductoVentas.select();
    }, 60);
}
async function buscarProductosVenta(
    termino,
    limite = 12
) {
    const parametros = new URLSearchParams({
        q: limpiarTexto(termino),
        limite: String(limite)
    });

    const respuesta = await fetch(
        `/api/ventas/productos/buscar?${parametros.toString()}`,
        {
            method: 'GET',
            headers: {
                Accept: 'application/json'
            }
        }
    );

    const datos = await respuesta.json();

    if (!respuesta.ok || !datos.ok) {
        throw new Error(
            datos.mensaje ||
            'No fue posible buscar productos.'
        );
    }

    return datos;
}

async function buscarProductoPorCodigoVenta() {
    if (
        !estado.puedeVender ||
        estado.buscandoProducto
    ) {
        return;
    }

    const codigo =
        limpiarTexto(
            elementos.codigoProductoVentas.value
        );

    if (!codigo) {
        abrirModalBuscarProducto();

        return;
    }

    estado.buscandoProducto = true;

    elementos.botonAgregarProductoVentas.disabled =
        true;

    try {
        const datos =
            await buscarProductosVenta(
                codigo,
                12
            );

        if (datos.productoExacto) {
            seleccionarProductoVenta(
                datos.productoExacto,
                codigo
            );

            return;
        }

        if (
            Array.isArray(datos.productos) &&
            datos.productos.length === 1
        ) {
            seleccionarProductoVenta(
                datos.productos[0],
                codigo
            );

            return;
        }

        if (
            Array.isArray(datos.productos) &&
            datos.productos.length > 1
        ) {
            abrirModalBuscarProducto({
                termino: codigo,
                productos: datos.productos
            });

            return;
        }

        limpiarProductoSeleccionado();

        mostrarMensaje(
            'No se encontró un producto activo con ese código.'
        );
    } catch (error) {
        console.error(
            'Error buscando producto desde Ventas:',
            error
        );

        mostrarMensaje(
            error.message ||
            'No fue posible buscar el producto.'
        );
    } finally {
        estado.buscandoProducto = false;

        actualizarControlesSegunCaja();
    }
}

function agregarProductoSeleccionadoAlCarrito() {
    const producto =
        estado.productoSeleccionado;

    if (!estado.puedeVender) {
        mostrarMensaje(
            'La Caja no está abierta para vender.'
        );

        return;
    }

    if (!producto) {
        mostrarMensaje(
            'Seleccione primero un producto.'
        );

        enfocarCodigoProducto();

        return;
    }

    const cantidad =
        normalizarCantidadProductoVenta(
            elementos.cantidadProductoVentas.value,
            producto
        );

    if (cantidad === null) {
        mostrarMensaje(
            esProductoPorPesoVentas(producto)
                ? 'Ingrese un peso válido en kg. Ejemplo: 0,500.'
                : 'Ingrese una cantidad entera válida. Ejemplo: 1, 2 o 3.'
        );

        enfocarElemento(
            elementos.cantidadProductoVentas
        );

        return;
    }

    const estaEditando =
        estado.productoEditandoCarritoId !== null;

    if (estaEditando) {
        const lineaEditar =
            estado.carrito.find((linea) => {
                return Number(linea.producto.id) ===
                    Number(estado.productoEditandoCarritoId);
            });

        if (!lineaEditar) {
            mostrarMensaje(
                'No se encontró el producto que se estaba editando.'
            );

            limpiarProductoSeleccionado({
                enfocar: true
            });

            return;
        }

        const disponible =
            numeroDecimalSeguro(
                lineaEditar.producto.existenciaDisponible
            );

        if (cantidad > disponible + 0.000001) {
            mostrarMensaje(
                `No hay existencia suficiente. Disponible: ${formatearCantidadProductoVentas(
                    lineaEditar.producto.existenciaDisponible,
                    lineaEditar.producto
                )}.`
            );

            return;
        }

        lineaEditar.cantidad = cantidad;

        renderizarCarritoVentas();

        mostrarMensaje(
            'Cantidad actualizada correctamente.'
        );

        limpiarProductoSeleccionado({
            enfocar: true
        });

        return;
    }

    if (
        !validarExistenciaDisponible(
            producto,
            cantidad
        )
    ) {
        mostrarMensaje(
            `No hay existencia suficiente. Disponible: ${formatearCantidadProductoVentas(
                producto.existenciaDisponible,
                producto
            )}.`
        );

        return;
    }

    const lineaExistente =
        estado.carrito.find((linea) => {
            return Number(linea.producto.id) ===
                Number(producto.id);
        });

    if (lineaExistente) {
        lineaExistente.cantidad =
            numeroDecimalSeguro(
                lineaExistente.cantidad
            ) + cantidad;
    } else {
        estado.carrito.push({
            producto,
            cantidad
        });
    }

    renderizarCarritoVentas();

    limpiarProductoSeleccionado({
        enfocar: true
    });
}

function quitarProductoCarrito(productoId) {
    const linea =
        estado.carrito.find((item) => {
            return Number(item.producto.id) ===
                Number(productoId);
        });

    if (!linea) {
        mostrarMensaje(
            'No se encontró el producto en el carrito.'
        );

        return;
    }

    abrirModalConfirmacionVentas({
        titulo: 'Quitar producto',
        descripcion: `¿Desea quitar "${linea.producto.nombre}" del carrito?`,
        subtexto: 'Esta acción eliminará el producto de la venta.',
        confirmar: 'Quitar',
        ejecutar: () => {
            estado.carrito =
                estado.carrito.filter((item) => {
                    return Number(item.producto.id) !==
                        Number(productoId);
                });

            if (
                Number(estado.productoEditandoCarritoId) ===
                Number(productoId)
            ) {
                estado.productoEditandoCarritoId = null;
                estado.productoSeleccionado = null;
            }

            limpiarProductoSeleccionado({
                enfocar: true
            });

            renderizarCarritoVentas();

            mostrarMensaje(
                'Producto quitado del carrito.'
            );
        }
    });
}

function vaciarCarritoVentas() {
    if (estado.carrito.length === 0) {
        mostrarMensaje(
            'El carrito ya está vacío.'
        );

        return;
    }

    abrirModalConfirmacionVentas({
        titulo: 'Vaciar carrito',
        descripcion: '¿Desea vaciar todos los productos del carrito?',
        subtexto: 'Esta acción eliminará todos los productos del carrito.',
        confirmar: 'Vaciar',
        ejecutar: () => {
            estado.carrito = [];

            limpiarProductoSeleccionado({
                enfocar: true
            });

            renderizarCarritoVentas();

            mostrarMensaje(
                'El carrito ha sido vaciado.'
            );
        }
    });
}

function mostrarEstadoBusquedaProducto(mensaje) {
    elementos.resultadosBusquedaProductoVentas.replaceChildren();

    const contenedor =
        document.createElement('div');

    contenedor.className =
        'resultados-producto-ventas__vacio';

    const icono =
        document.createElement('span');

    icono.setAttribute(
        'aria-hidden',
        'true'
    );

    icono.textContent = '⌕';

    const texto =
        document.createElement('p');

    texto.textContent = mensaje;

    contenedor.append(
        icono,
        texto
    );

    elementos.resultadosBusquedaProductoVentas.appendChild(
        contenedor
    );
}

function renderizarResultadosBusquedaProducto(productos) {
    estado.resultadosBusquedaProductos =
        Array.isArray(productos)
            ? productos
            : [];

    elementos.resultadosBusquedaProductoVentas.replaceChildren();

    if (estado.resultadosBusquedaProductos.length === 0) {
        mostrarEstadoBusquedaProducto(
            'No se encontraron productos disponibles.'
        );

        return;
    }

    const fragmento =
        document.createDocumentFragment();

    estado.resultadosBusquedaProductos.forEach((producto) => {
        const disponible =
            numeroDecimalSeguro(
                producto.existenciaDisponible
            );

        const boton =
            document.createElement('button');

        boton.type = 'button';
        boton.className =
            'resultado-producto-ventas';
        boton.dataset.productoId =
            String(producto.id);
        boton.disabled =
            disponible <= 0;

        const info =
            document.createElement('div');

        info.className =
            'resultado-producto-ventas__info';

        const nombre =
            document.createElement('strong');

        nombre.textContent =
            producto.nombre || 'Producto';

        const detalle =
            document.createElement('span');

        detalle.textContent =
            `${producto.codigoInterno || producto.codigoBarras || 'Sin código'} · ${obtenerDescripcionTipoVenta(producto)}`;

        info.append(
            nombre,
            detalle
        );

        const meta =
            document.createElement('div');

        meta.className =
            'resultado-producto-ventas__meta';

        const precio =
            document.createElement('strong');

        precio.textContent =
            `${formatearUsd(
                producto.precioVentaUsd
            )} / ${obtenerUnidadProductoVentas(producto)}`;

        const existencia =
            document.createElement('span');

        existencia.textContent =
            `Disp.: ${formatearCantidadProductoVentas(
                producto.existenciaDisponible,
                producto
            )}`;

        meta.append(
            precio,
            existencia
        );

        boton.append(
            info,
            meta
        );

        fragmento.appendChild(
            boton
        );
    });

    elementos.resultadosBusquedaProductoVentas.appendChild(
        fragmento
    );
}

function abrirModalBuscarProducto({
    termino = '',
    productos = null
} = {}) {
    if (!estado.puedeVender) {
        mostrarMensaje(
            'La Caja no está abierta para vender.'
        );

        return;
    }

    estado.modalBuscarProductoAbierto = true;

    elementos.modalBuscarProductoVentas.hidden =
        false;

    elementos.modalBuscarProductoVentas.setAttribute(
        'aria-hidden',
        'false'
    );

    elementos.busquedaProductoVentas.value =
        termino;

    if (Array.isArray(productos)) {
        renderizarResultadosBusquedaProducto(
            productos
        );
    } else {
        mostrarEstadoBusquedaProducto(
            'Escriba para buscar productos disponibles.'
        );
    }

    window.setTimeout(() => {
        elementos.busquedaProductoVentas.focus();

        if (termino) {
            elementos.busquedaProductoVentas.select();
        }
    }, 60);
}

function cerrarModalBuscarProducto() {
    estado.modalBuscarProductoAbierto = false;

    elementos.modalBuscarProductoVentas.hidden =
        true;

    elementos.modalBuscarProductoVentas.setAttribute(
        'aria-hidden',
        'true'
    );

    elementos.busquedaProductoVentas.value =
        '';

    estado.resultadosBusquedaProductos = [];
}

async function ejecutarBusquedaModalProducto() {
    const busqueda =
        limpiarTexto(
            elementos.busquedaProductoVentas.value
        );

    if (!busqueda) {
        mostrarEstadoBusquedaProducto(
            'Escriba para buscar productos disponibles.'
        );

        return;
    }

    mostrarEstadoBusquedaProducto(
        'Buscando productos...'
    );

    try {
        const datos =
            await buscarProductosVenta(
                busqueda,
                12
            );

        renderizarResultadosBusquedaProducto(
            datos.productos || []
        );
    } catch (error) {
        console.error(
            'Error buscando productos en F2:',
            error
        );

        mostrarEstadoBusquedaProducto(
            error.message ||
            'No fue posible buscar productos.'
        );
    }
}
/* =========================================================
   CONTROLES SEGÚN CAJA
   ========================================================= */

function actualizarControlesSegunCaja() {
    const habilitado =
        estado.puedeVender === true;

    const tieneProductoSeleccionado =
        Boolean(estado.productoSeleccionado);

    const controlesGenerales = [
        elementos.documentoClienteVentas,
        elementos.codigoProductoVentas,
        elementos.botonBuscarProductoVentas
    ];

    controlesGenerales.forEach((control) => {
        if (!control) {
            return;
        }

        control.disabled = !habilitado;
    });

    elementos.cantidadProductoVentas.disabled =
        !habilitado ||
        !tieneProductoSeleccionado;

    elementos.botonAgregarProductoVentas.disabled =
        !habilitado ||
        !tieneProductoSeleccionado;

    const documento =
        normalizarDocumentoCliente(
            elementos.documentoClienteVentas.value
        );

    elementos.botonLimpiarClienteVentas.disabled =
        !habilitado ||
        documento === '' ||
        documento === DOCUMENTO_CONSUMIDOR_FINAL;

    const clienteId =
        obtenerClienteId(
            estado.clienteSeleccionado
        );

    elementos.botonEditarClienteVentas.disabled =
        !habilitado || clienteId === null;

    elementos.botonCobrarVentas.disabled =
        !habilitado ||
        estado.carrito.length === 0;
    elementos.botonVaciarCarritoVentas.disabled =
        !habilitado ||
        estado.carrito.length === 0;
}
/* =========================================================
   BLOQUEO DE INTERFAZ: CAJA ABIERTA OTRO DÍA
   ========================================================= */
function bloquearInterfazVentasOtroDia() {
    if (document.getElementById('ventas-bloqueo-otro-dia')) {
        return;
    }

    const overlay = document.createElement('div');
    overlay.id = 'ventas-bloqueo-otro-dia';

    Object.assign(overlay.style, {
        position: 'fixed',
        inset: '0',
        backgroundColor: 'rgba(255,152,0,0.06)',
        zIndex: '1000',
        pointerEvents: 'auto'
    });

    document.body.appendChild(overlay);

    if (elementos.estadoCajaVentas) {
        elementos.estadoCajaVentas.classList.add(
            'estado-caja-ventas--advertencia'
        );

        elementos.estadoCajaVentas.style.backgroundColor = '#ff9800';
        elementos.estadoCajaVentas.style.color = '#ffffff';
    }

    // Asegurar que los botones permitidos se mantengan encima y habilitados
    if (elementos.botonIrPanelVentas) {
        elementos.botonIrPanelVentas.disabled = false;
        elementos.botonIrPanelVentas.style.zIndex = '1001';
        elementos.botonIrPanelVentas.style.position = 'relative';
    }

    if (elementos.botonCerrarSesionVentas) {
        elementos.botonCerrarSesionVentas.disabled = false;
        elementos.botonCerrarSesionVentas.style.zIndex = '1001';
        elementos.botonCerrarSesionVentas.style.position = 'relative';
    }

    // Forzar actualización de controles para deshabilitar inputs y botones relevantes
    actualizarControlesSegunCaja();
}

function desbloquearInterfazVentas() {
    const overlay = document.getElementById('ventas-bloqueo-otro-dia');

    if (overlay) {
        overlay.remove();
    }

    if (elementos.estadoCajaVentas) {
        elementos.estadoCajaVentas.style.backgroundColor = '';
        elementos.estadoCajaVentas.style.color = '';
        elementos.estadoCajaVentas.classList.remove(
            'estado-caja-ventas--advertencia'
        );
    }

    if (elementos.botonIrPanelVentas) {
        elementos.botonIrPanelVentas.style.zIndex = '';
        elementos.botonIrPanelVentas.style.position = '';
    }

    if (elementos.botonCerrarSesionVentas) {
        elementos.botonCerrarSesionVentas.style.zIndex = '';
        elementos.botonCerrarSesionVentas.style.position = '';
    }

    actualizarControlesSegunCaja();
}
/* =========================================================
   ESTADO DEL CLIENTE
   ========================================================= */

function mostrarConsumidorFinal() {
    estado.clienteSeleccionado = null;

    elementos.estadoClienteVentas.textContent =
        'Consumidor final';

    elementos.estadoClienteVentas.className =
        'estado-cliente-ventas';

    elementos.detalleClienteVentas.className =
        'campo-venta__ayuda';

    elementos.detalleClienteVentas.textContent =
        'V- activo. Presione Enter para continuar sin datos de cliente.';
}

function mostrarBuscandoCliente() {
    elementos.estadoClienteVentas.textContent =
        'Buscando cliente...';

    elementos.estadoClienteVentas.className =
        'estado-cliente-ventas';

    elementos.detalleClienteVentas.className =
        'campo-venta__ayuda';

    elementos.detalleClienteVentas.textContent =
        'Consultando los datos del cliente registrado.';
}

function mostrarClienteEncontrado(cliente) {
    estado.clienteSeleccionado = cliente;

    const nombre =
        obtenerNombreCliente(cliente);

    const documento =
        obtenerDocumentoCliente(cliente);

    elementos.estadoClienteVentas.textContent =
        'Cliente encontrado';

    elementos.estadoClienteVentas.className =
        'estado-cliente-ventas estado-cliente-ventas--encontrado';

    elementos.detalleClienteVentas.className =
        'campo-venta__ayuda campo-venta__ayuda--cliente-encontrado';

    elementos.detalleClienteVentas.textContent =
        nombre;
}

function mostrarClienteNoEncontrado() {
    estado.clienteSeleccionado = null;

    elementos.estadoClienteVentas.textContent =
        'Cliente no encontrado';

    elementos.estadoClienteVentas.className =
        'estado-cliente-ventas estado-cliente-ventas--no-encontrado';

    elementos.detalleClienteVentas.className =
        'campo-venta__ayuda';

    elementos.detalleClienteVentas.textContent =
        'Debe registrar el cliente o continuar como Consumidor final.';
}

function establecerClientePredeterminado({
    enfocar = false
} = {}) {
    estado.clienteSeleccionado = null;

    elementos.documentoClienteVentas.value =
        DOCUMENTO_CONSUMIDOR_FINAL;

    mostrarConsumidorFinal();
    actualizarControlesSegunCaja();

    if (enfocar) {
        enfocarDocumentoCliente();
    }
}

function continuarComoConsumidorFinal() {
    cerrarModalRegistroRapidoCliente({
        devolverFoco: false
    });

    establecerClientePredeterminado();

    enfocarCodigoProducto();
}

/* =========================================================
   MODAL DE REGISTRO RÁPIDO
   ========================================================= */

function actualizarEtiquetaNombreClienteRapido() {
    const esJuridica =
        elementos.tipoPersonaClienteRapidoVentas.value ===
        'JURIDICA';

    elementos.etiquetaNombreClienteRapidoVentas.textContent =
        esJuridica
            ? 'Razón social'
            : 'Nombre completo';

    elementos.nombreClienteRapidoVentas.placeholder =
        esJuridica
            ? 'Ej.: Distribuidora Tenvik, C.A.'
            : 'Ej.: María González';
}

function abrirModalRegistroRapidoCliente(documento) {
    const documentoSeguro =
        normalizarDocumentoCliente(documento);

    estado.modoCliente = 'REGISTRO';
    estado.clienteEditandoId = null;
    estado.modalClienteRapidoAbierto = true;

    elementos.formularioRegistroRapidoClienteVentas.reset();

    elementos.subtituloRegistroRapidoClienteVentas.textContent =
        'Cliente no encontrado';

    elementos.tituloRegistroRapidoClienteVentas.textContent =
        'Registrar cliente rápido';

    elementos.botonGuardarRegistroRapidoClienteVentas.textContent =
        'Registrar y continuar';

    elementos.botonConsumidorFinalRegistroVentas.hidden =
        false;

    elementos.tipoPersonaClienteRapidoVentas.disabled =
        false;

    elementos.identificacionClienteRapidoVentas.disabled =
        false;

    elementos.direccionClienteRapidoVentas.required =
        true;

    elementos.tipoPersonaClienteRapidoVentas.value =
        inferirTipoPersona(documentoSeguro);

    elementos.identificacionClienteRapidoVentas.value =
        documentoSeguro;

    elementos.mensajeRegistroRapidoClienteVentas.textContent =
        '';

    actualizarEtiquetaNombreClienteRapido();

    elementos.modalRegistroRapidoClienteVentas.hidden =
        false;

    elementos.modalRegistroRapidoClienteVentas.setAttribute(
        'aria-hidden',
        'false'
    );

    window.setTimeout(() => {
        elementos.nombreClienteRapidoVentas.focus();
    }, 50);
}

function abrirModalEdicionCliente(cliente) {
    const datosCliente =
        obtenerObjetoCliente(cliente);

    estado.modoCliente = 'EDICION';
    estado.clienteEditandoId =
        obtenerClienteId(datosCliente);

    estado.modalClienteRapidoAbierto = true;

    elementos.formularioRegistroRapidoClienteVentas.reset();

    elementos.subtituloRegistroRapidoClienteVentas.textContent =
        'Cliente seleccionado';

    elementos.tituloRegistroRapidoClienteVentas.textContent =
        'Actualizar cliente';

    elementos.botonGuardarRegistroRapidoClienteVentas.textContent =
        'Guardar cambios';

    elementos.botonConsumidorFinalRegistroVentas.hidden =
        true;

    elementos.tipoPersonaClienteRapidoVentas.value =
        datosCliente.tipo_persona ||
        datosCliente.tipoPersona ||
        'NATURAL';

    elementos.identificacionClienteRapidoVentas.value =
        obtenerDocumentoCliente(datosCliente) || '';

    elementos.nombreClienteRapidoVentas.value =
        obtenerNombreCliente(datosCliente);

    elementos.direccionClienteRapidoVentas.value =
        obtenerDireccionCliente(datosCliente);

    elementos.telefonoClienteRapidoVentas.value =
        obtenerTelefonoCliente(datosCliente);

    elementos.correoClienteRapidoVentas.value =
        obtenerCorreoCliente(datosCliente);

    /*
        El cajero no modifica identidad del cliente
        durante una venta.
    */
    elementos.tipoPersonaClienteRapidoVentas.disabled =
        true;

    elementos.identificacionClienteRapidoVentas.disabled =
        true;

    /*
        Para un cliente existente la dirección puede quedar
        vacía mientras se actualiza otro dato.
    */
    elementos.direccionClienteRapidoVentas.required =
        false;

    elementos.mensajeRegistroRapidoClienteVentas.textContent =
        '';

    actualizarEtiquetaNombreClienteRapido();

    elementos.modalRegistroRapidoClienteVentas.hidden =
        false;

    elementos.modalRegistroRapidoClienteVentas.setAttribute(
        'aria-hidden',
        'false'
    );

    window.setTimeout(() => {
        elementos.nombreClienteRapidoVentas.focus();
        elementos.nombreClienteRapidoVentas.select();
    }, 50);
}

function cerrarModalRegistroRapidoCliente({
    devolverFoco = true
} = {}) {
    estado.modalClienteRapidoAbierto = false;
    estado.modoCliente = 'REGISTRO';
    estado.clienteEditandoId = null;

    elementos.modalRegistroRapidoClienteVentas.hidden =
        true;

    elementos.modalRegistroRapidoClienteVentas.setAttribute(
        'aria-hidden',
        'true'
    );

    elementos.mensajeRegistroRapidoClienteVentas.textContent =
        '';

    elementos.tipoPersonaClienteRapidoVentas.disabled =
        false;

    elementos.identificacionClienteRapidoVentas.disabled =
        false;

    elementos.direccionClienteRapidoVentas.required =
        true;

    elementos.botonConsumidorFinalRegistroVentas.hidden =
        false;

    if (devolverFoco) {
        enfocarDocumentoCliente();
    }
}

function obtenerDatosClienteRapido() {
    return {
        tipoPersona:
            elementos.tipoPersonaClienteRapidoVentas.value,

        nombreCompleto: limpiarTexto(
            elementos.nombreClienteRapidoVentas.value
        ),

        identificacion: normalizarDocumentoCliente(
            elementos.identificacionClienteRapidoVentas.value
        ),
        direccion: limpiarTexto(
            elementos.direccionClienteRapidoVentas.value
        ),
        telefono: limpiarTexto(
            elementos.telefonoClienteRapidoVentas.value
        ),

        correo: limpiarTexto(
            elementos.correoClienteRapidoVentas.value
        )
    };
}
async function editarClienteSeleccionado() {
    if (
        !estado.puedeVender ||
        estado.modalClienteRapidoAbierto ||
        estado.cargandoClienteEdicion
    ) {
        return;
    }

    const clienteId =
        obtenerClienteId(
            estado.clienteSeleccionado
        );

    if (!clienteId) {
        mostrarMensaje(
            'Seleccione o registre un cliente para editar.'
        );

        return;
    }

    estado.cargandoClienteEdicion = true;

    elementos.botonEditarClienteVentas.disabled =
        true;

    try {
        const respuesta = await fetch(
            `/api/ventas/clientes/${clienteId}`,
            {
                method: 'GET',
                headers: {
                    Accept: 'application/json'
                }
            }
        );

        const datos = await respuesta.json();

        if (!respuesta.ok || !datos.ok) {
            throw new Error(
                datos.mensaje ||
                'No fue posible consultar los datos del cliente.'
            );
        }

        const cliente =
            datos.cliente || datos;

        estado.clienteSeleccionado = cliente;

        abrirModalEdicionCliente(cliente);
    } catch (error) {
        console.error(
            'Error preparando la edición del cliente:',
            error
        );

        mostrarMensaje(
            error.message ||
            'No fue posible abrir los datos del cliente.'
        );
    } finally {
        estado.cargandoClienteEdicion = false;

        actualizarControlesSegunCaja();
    }
}
async function guardarClienteRapido(evento) {
    evento.preventDefault();

    if (estado.guardandoClienteRapido) {
        return;
    }

    const datosCliente =
        obtenerDatosClienteRapido();

    const esEdicion =
        estado.modoCliente === 'EDICION';

    const clienteId =
        estado.clienteEditandoId;

    if (!datosCliente.nombreCompleto) {
        elementos.mensajeRegistroRapidoClienteVentas.textContent =
            'Ingrese el nombre completo o razón social del cliente.';

        elementos.nombreClienteRapidoVentas.focus();

        return;
    }

    if (
        !esEdicion &&
        !datosCliente.identificacion
    ) {
        elementos.mensajeRegistroRapidoClienteVentas.textContent =
            'Ingrese una identificación válida.';

        elementos.identificacionClienteRapidoVentas.focus();

        return;
    }

    if (
        !esEdicion &&
        !datosCliente.direccion
    ) {
        elementos.mensajeRegistroRapidoClienteVentas.textContent =
            'Ingrese la dirección del cliente.';

        elementos.direccionClienteRapidoVentas.focus();

        return;
    }

    if (esEdicion && !clienteId) {
        elementos.mensajeRegistroRapidoClienteVentas.textContent =
            'No fue posible identificar el cliente a actualizar.';

        return;
    }

    estado.guardandoClienteRapido = true;

    const textoOriginal = esEdicion
        ? 'Guardar cambios'
        : 'Registrar y continuar';

    elementos.botonGuardarRegistroRapidoClienteVentas.disabled =
        true;

    elementos.botonGuardarRegistroRapidoClienteVentas.textContent =
        esEdicion
            ? 'Guardando...'
            : 'Registrando...';

    elementos.mensajeRegistroRapidoClienteVentas.textContent =
        '';

    try {
        const ruta = esEdicion
            ? `/api/ventas/clientes/${clienteId}`
            : '/api/ventas/clientes-rapido';

        const metodo = esEdicion
            ? 'PUT'
            : 'POST';

        const datosEnviar = esEdicion
            ? {
                nombreCompleto:
                    datosCliente.nombreCompleto,

                direccion:
                    datosCliente.direccion,

                telefono:
                    datosCliente.telefono,

                correo:
                    datosCliente.correo
            }
            : datosCliente;

        const respuesta = await fetch(
            ruta,
            {
                method: metodo,

                headers: {
                    'Content-Type': 'application/json',
                    Accept: 'application/json'
                },

                body: JSON.stringify(datosEnviar)
            }
        );

        const datos = await respuesta.json();

        if (!respuesta.ok || !datos.ok) {
            throw new Error(
                datos.mensaje ||
                'No fue posible guardar los datos del cliente.'
            );
        }

        const clienteRespuesta =
            datos.cliente || {};

        const clienteFinal = {
            ...obtenerObjetoCliente(
                estado.clienteSeleccionado
            ),

            ...obtenerObjetoCliente(
                clienteRespuesta
            ),

            id: obtenerClienteId(
                clienteRespuesta
            ) || clienteId
        };

        estado.clienteSeleccionado =
            clienteFinal;

        elementos.documentoClienteVentas.value =
            obtenerDocumentoCliente(clienteFinal) ||
            datosCliente.identificacion ||
            elementos.documentoClienteVentas.value;

        mostrarClienteEncontrado(clienteFinal);

        cerrarModalRegistroRapidoCliente({
            devolverFoco: false
        });

        actualizarControlesSegunCaja();

        mostrarMensaje(
            esEdicion
                ? 'Datos del cliente actualizados correctamente.'
                : 'Cliente registrado y seleccionado correctamente.'
        );

        enfocarCodigoProducto();
    } catch (error) {
        console.error(
            'Error guardando cliente desde Ventas:',
            error
        );

        elementos.mensajeRegistroRapidoClienteVentas.textContent =
            error.message ||
            'No fue posible guardar los datos del cliente.';
    } finally {
        estado.guardandoClienteRapido = false;

        elementos.botonGuardarRegistroRapidoClienteVentas.disabled =
            false;

        elementos.botonGuardarRegistroRapidoClienteVentas.textContent =
            textoOriginal;
    }
}

/* =========================================================
   BÚSQUEDA DE CLIENTE
   ========================================================= */

function obtenerClienteExacto(datos) {
    const coincidenciaDirecta =
        obtenerPrimerValorDisponible(
            datos?.cliente,
            datos?.coincidencia,
            datos?.clienteEncontrado,
            datos?.cliente_encontrado
        );

    if (
        coincidenciaDirecta &&
        typeof coincidenciaDirecta === 'object'
    ) {
        return coincidenciaDirecta;
    }

    const coincidenciaExacta =
        datos?.coincidenciaExacta === true ||
        datos?.coincidencia_exacta === true;

    const lista =
        obtenerPrimerValorDisponible(
            datos?.clientes,
            datos?.resultados,
            datos?.items,
            datos?.datos
        );

    if (
        coincidenciaExacta &&
        Array.isArray(lista) &&
        lista.length > 0
    ) {
        return lista[0];
    }

    return null;
}

async function buscarClientePorDocumento() {
    if (
        !estado.puedeVender ||
        estado.buscandoCliente ||
        estado.modalClienteRapidoAbierto
    ) {
        return;
    }

    const documento =
        normalizarDocumentoCliente(
            elementos.documentoClienteVentas.value
        );

    elementos.documentoClienteVentas.value =
        documento;

    /*
        V- sin número significa Consumidor final.
        No se hace consulta a la base de datos.
    */
    if (
        documento === '' ||
        esDocumentoConsumidorFinal(documento)
    ) {
        continuarComoConsumidorFinal();

        return;
    }

    /*
        Evita abrir un modal cuando todavía falta escribir
        el número de identificación.
    */
    if (esPrefijoIncompleto(documento)) {
        elementos.estadoClienteVentas.textContent =
            'Documento incompleto';

        elementos.estadoClienteVentas.className =
            'estado-cliente-ventas estado-cliente-ventas--no-encontrado';

        elementos.detalleClienteVentas.textContent =
            'Complete el número de identificación para buscar o registrar el cliente.';

        mostrarMensaje(
            'Complete el número de identificación.'
        );

        enfocarDocumentoCliente();

        return;
    }

    estado.buscandoCliente = true;

    mostrarBuscandoCliente();

    try {
        const parametros = new URLSearchParams({
            q: documento,
            limite: '8'
        });

        const respuesta = await fetch(
            `/api/clientes/busqueda-rapida?${parametros.toString()}`,
            {
                method: 'GET',

                headers: {
                    Accept: 'application/json'
                }
            }
        );

        const datos = await respuesta.json();

        if (!respuesta.ok || !datos.ok) {
            throw new Error(
                datos.mensaje ||
                'No fue posible buscar el cliente.'
            );
        }

        const cliente =
            obtenerClienteExacto(datos);

        if (cliente) {
            elementos.documentoClienteVentas.value =
                obtenerDocumentoCliente(cliente) ||
                documento;

            mostrarClienteEncontrado(cliente);

            actualizarControlesSegunCaja();

            enfocarCodigoProducto();

            return;
        }

        mostrarClienteNoEncontrado();

        actualizarControlesSegunCaja();

        abrirModalRegistroRapidoCliente(documento);
    } catch (error) {
        console.error(
            'Error buscando cliente desde Ventas:',
            error
        );

        estado.clienteSeleccionado = null;

        elementos.estadoClienteVentas.textContent =
            'No disponible';

        elementos.estadoClienteVentas.className =
            'estado-cliente-ventas estado-cliente-ventas--no-encontrado';

        elementos.detalleClienteVentas.textContent =
            error.message ||
            'No fue posible consultar los clientes.';
    } finally {
        estado.buscandoCliente = false;
    }
}

function limpiarClienteSeleccionado() {
    establecerClientePredeterminado({
        enfocar: true
    });
}

/* =========================================================
   RENDERIZADO DEL CONTEXTO
   ========================================================= */

function mostrarEstadoCargando() {
    estado.puedeVender = false;

    elementos.estadoCajaVentas.className =
        'estado-caja-ventas estado-caja-ventas--cargando';

    elementos.textoEstadoCajaVentas.textContent =
        'Verificando estado...';

    elementos.nombreUsuarioVentas.textContent =
        'Cargando usuario...';

    elementos.rolUsuarioVentas.textContent =
        '—';

    elementos.tasaVentas.textContent =
        'Tasa: —';

    mostrarConsumidorFinal();
    actualizarControlesSegunCaja();
}

function renderizarContextoOperacion(contexto) {
    estado.contexto = contexto;

    estado.puedeVender =
        contexto.puedeVender === true;

    const codigoCaja =
        contexto.codigo || null;

    const esCajaOtroDia =
        codigoCaja === 'CAJA_ABIERTO_OTRO_DIA';

    const usuario =
        contexto.usuario || {};

    const nombreUsuario =
        obtenerPrimerValorDisponible(
            usuario.nombreCompleto,
            usuario.nombre_completo,
            usuario.usuario,
            'Usuario'
        );

    elementos.nombreUsuarioVentas.textContent =
        nombreUsuario;

    elementos.rolUsuarioVentas.textContent =
        normalizarRolVisible(usuario.rol);
    elementos.botonIrPanelVentas.hidden =
        String(usuario.rol || '').toUpperCase() !== 'PROPIETARIO';

    const tasa =
        obtenerTasaDelContexto(contexto);

    if (esCajaOtroDia) {
        elementos.estadoCajaVentas.className =
            'estado-caja-ventas estado-caja-ventas--advertencia';

        elementos.textoEstadoCajaVentas.textContent =
            'Caja bloqueada · requiere cierre y arqueo';

        elementos.tasaVentas.textContent =
            'Tasa: —';
        bloquearInterfazVentasOtroDia();
    } else if (estado.puedeVender) {
        desbloquearInterfazVentas();
        elementos.estadoCajaVentas.className =
            'estado-caja-ventas';

        elementos.textoEstadoCajaVentas.textContent =
            'Abierta · lista para vender';

        elementos.tasaVentas.textContent = tasa
            ? `Tasa: ${formatearBolivares(tasa)}`
            : 'Tasa: no disponible';
    } else {
        desbloquearInterfazVentas();
        elementos.estadoCajaVentas.className =
            'estado-caja-ventas estado-caja-ventas--cerrada';

        elementos.textoEstadoCajaVentas.textContent =
            'Cerrada · ventas bloqueadas';

        elementos.tasaVentas.textContent =
            'Tasa: —';
    }

    establecerClientePredeterminado({
        enfocar: estado.puedeVender
    });
}

/* =========================================================
   CONSULTA DEL CONTEXTO
   ========================================================= */

async function cargarContextoOperacionVentas() {
    if (estado.cargandoContexto) {
        return;
    }

    estado.cargandoContexto = true;

    mostrarEstadoCargando();

    try {
        const respuesta = await fetch(
            '/api/ventas/contexto-operacion',
            {
                method: 'GET',

                headers: {
                    Accept: 'application/json'
                }
            }
        );

        const datos = await respuesta.json();

        if (!respuesta.ok || !datos.ok) {
            const error = new Error(
                datos.mensaje ||
                'No fue posible preparar el Punto de Venta.'
            );

            error.codigo =
                datos.codigo || null;

            throw error;
        }

        renderizarContextoOperacion(datos);

        if (
            !datos.puedeVender &&
            datos.redireccion
        ) {
            window.setTimeout(() => {
                window.location.assign(
                    datos.redireccion || '/caja'
                );
            }, 250);
            return;
        }

        if (!datos.puedeVender) {
            mostrarMensaje(
                datos.mensaje ||
                'No existe una Caja abierta para registrar ventas.'
            );
        }
    } catch (error) {
        console.error(
            'Error cargando el contexto de Ventas:',
            error
        );

        estado.puedeVender = false;

        elementos.estadoCajaVentas.className =
            'estado-caja-ventas estado-caja-ventas--cerrada';

        elementos.textoEstadoCajaVentas.textContent =
            'No disponible';

        elementos.tasaVentas.textContent =
            'Tasa: —';

        mostrarConsumidorFinal();
        actualizarControlesSegunCaja();

        mostrarMensaje(
            error.message ||
            'No fue posible consultar el estado de Caja.'
        );

        if (
            error.codigo === 'SESION_NO_ACTIVA' ||
            error.codigo === 'USUARIO_SIN_PERMISO'
        ) {
            window.setTimeout(() => {
                window.location.assign(
                    '/iniciar-sesion'
                );
            }, 700);
        }
    } finally {
        estado.cargandoContexto = false;
    }
}

/* =========================================================
   SESIÓN Y NAVEGACIÓN
   ========================================================= */

async function cerrarSesionVentas() {
    elementos.botonCerrarSesionVentas.disabled = true;

    try {
        const respuesta = await fetch(
            '/api/autenticacion/cerrar-sesion',
            {
                method: 'POST',

                headers: {
                    Accept: 'application/json'
                }
            }
        );

        const datos = await respuesta.json();

        window.location.assign(
            datos.redireccion || '/iniciar-sesion'
        );
    } catch (error) {
        console.error(
            'Error cerrando sesión desde Ventas:',
            error
        );

        elementos.botonCerrarSesionVentas.disabled =
            false;

        mostrarMensaje(
            'No fue posible cerrar sesión. Intente nuevamente.'
        );
    }
}
const METODOS_PAGO_VENTAS = {
    EFECTIVO_USD: {
        codigo: 'EFECTIVO_USD',
        nombre: 'Efectivo USD',
        moneda: 'USD',
        requiereReferencia: false
    },
    EFECTIVO_VES: {
        codigo: 'EFECTIVO_VES',
        nombre: 'Efectivo Bs.',
        moneda: 'VES',
        requiereReferencia: false
    },
    PAGO_MOVIL: {
        codigo: 'PAGO_MOVIL',
        nombre: 'Pago móvil',
        moneda: 'VES',
        requiereReferencia: true
    },
    TRANSFERENCIA_VES: {
        codigo: 'TRANSFERENCIA_VES',
        nombre: 'Transferencia Bs.',
        moneda: 'VES',
        requiereReferencia: true
    },
    PUNTO_VENTA: {
        codigo: 'PUNTO_VENTA',
        nombre: 'Punto de venta',
        moneda: 'VES',
        requiereReferencia: true
    },
    BIOPAGO: {
        codigo: 'BIOPAGO',
        nombre: 'Biopago',
        moneda: 'VES',
        requiereReferencia: true
    },
    ZELLE: {
        codigo: 'ZELLE',
        nombre: 'Zelle',
        moneda: 'USD',
        requiereReferencia: true
    },
    TARJETA_DEBITO: {
        codigo: 'TARJETA_DEBITO',
        nombre: 'Tarjeta de débito',
        moneda: 'VES',
        requiereReferencia: true
    },
    TRANSACCION_ELECTRONICA: {
        codigo: 'TRANSACCION_ELECTRONICA',
        nombre: 'Transacción electrónica',
        moneda: 'VES',
        requiereReferencia: true
    },
    DV: {
        codigo: 'DV',
        nombre: 'Devolución (consumir)',
        moneda: 'VES',
        requiereReferencia: true
    },
    BINANCE: {
        codigo: 'BINANCE',
        nombre: 'Binance',
        moneda: 'USD',
        requiereReferencia: true
    }
};

const CODIGOS_ABREVIADOS_PAGO = {
    'EF': 'EFECTIVO_VES',
    'DL': 'EFECTIVO_USD',
    'PM': 'PAGO_MOVIL',
    'TR': 'TRANSFERENCIA_VES',
    'BI': 'BIOPAGO',
    'ZL': 'ZELLE',
    'BN': 'BINANCE',               // ← futuro
    'TD': 'TARJETA_DEBITO',        // ← futuro
    'TE': 'TRANSACCION_ELECTRONICA', // ← futuro
    'DV': 'DV'                     // devolución
};

// También puedes crear la inversa para mostrar descripción rápidamente
const DESCRIPCION_METODO = {};
Object.values(METODOS_PAGO_VENTAS).forEach(m => {
    DESCRIPCION_METODO[m.codigo] = m.nombre;
});
// Añade los métodos que aún no están en METODOS_PAGO_VENTAS
DESCRIPCION_METODO['DV'] = 'Devolución (consumir)';
DESCRIPCION_METODO['BINANCE'] = 'Binance';
DESCRIPCION_METODO['TARJETA_DEBITO'] = 'Tarjeta de débito';
DESCRIPCION_METODO['TRANSACCION_ELECTRONICA'] = 'Transacción electrónica';
function obtenerFilasPagoVentas() {
    return [1, 2, 3, 4, 5].map((numero) => {
        return {
            numero,
            fila: document.querySelector(`[data-fila-pago="${numero}"]`),
            metodo: document.getElementById(`metodoPagoVentas${numero}`),   // input
            descripcion: document.getElementById(`descripcionPagoVentas${numero}`), // celda descripción
            moneda: document.getElementById(`monedaPagoVentas${numero}`),   // span moneda
            monto: elementos[`montoPagoVentas${numero}`],
            referencia: elementos[`referenciaPagoVentas${numero}`]
        };
    });
}
function actualizarFilaPagoDesdeCodigo(filaPago) {
    const codigoAbreviado = filaPago.metodo.value.trim().toUpperCase();
    filaPago.metodo.value = codigoAbreviado;
    const codigoReal = CODIGOS_ABREVIADOS_PAGO[codigoAbreviado];

    if (codigoReal) {
        const metodo = METODOS_PAGO_VENTAS[codigoReal] || {
            codigo: codigoReal,
            nombre: DESCRIPCION_METODO[codigoReal] || codigoReal,
            moneda: 'VES',
            requiereReferencia: true
        };
        filaPago.descripcion.textContent = metodo.nombre;
        filaPago.moneda.textContent = metodo.moneda;
        filaPago.metodo.dataset.codigoReal = codigoReal;
        filaPago.monto.disabled = false;
        filaPago.referencia.disabled = metodo.requiereReferencia === false;
        filaPago.monto.focus();

        if (codigoReal === 'DV') {
            estado.dvAutorizacionValidada = false;
            estado.dvAutorizacionFilaNumero = filaPago.numero;
            solicitarAutorizacionDVVentas(filaPago);
        } else if (codigoReal === 'ZELLE') {
            estado.zelleAutorizacionValidada = false;
            estado.zelleAutorizacionFilaNumero = filaPago.numero;
            filaPago.monto.disabled = true;
            filaPago.referencia.disabled = true;
            filaPago.fila.classList.add('fila-pago-ventas--zelle');
            solicitarAutorizacionZelleVentas(filaPago);
        } else {
            if (estado.dvAutorizacionFilaNumero === filaPago.numero) {
                estado.dvAutorizacionValidada = false;
                estado.dvAutorizacionFilaNumero = null;
            }
            if (estado.zelleAutorizacionFilaNumero === filaPago.numero) {
                estado.zelleAutorizacionValidada = false;
                estado.zelleAutorizacionFilaNumero = null;
                delete estado.zelleDetalles[filaPago.numero];
            }
        }
    } else {
        filaPago.descripcion.textContent = '—';
        filaPago.moneda.textContent = '—';
        filaPago.metodo.dataset.codigoReal = '';
        filaPago.monto.disabled = true;
        filaPago.referencia.disabled = true;
    }
    actualizarModalCobroVentas();
}

function activarFilaPagoVentas(filaPago) {
    filaPago.fila.classList.remove('fila-pago-ventas--bloqueada');
    filaPago.metodo.removeAttribute('disabled');
    filaPago.metodo.disabled = false;
}

function bloquearFilaPagoVentas(filaPago) {
    filaPago.metodo.disabled = true;
    filaPago.metodo.value = '';
    filaPago.monto.disabled = true;
    filaPago.referencia.disabled = true;
    if (filaPago.descripcion) filaPago.descripcion.textContent = '—';
    if (filaPago.moneda) filaPago.moneda.textContent = '—';
}
function reiniciarModalCobroVentas() {
    estado.zelleDetalles = {};
    estado.zelleAutorizacionValidada = false;
    estado.zelleAutorizacionFilaNumero = null;

    obtenerFilasPagoVentas().forEach((filaPago, indice) => {
        filaPago.metodo.value = '';
        if (filaPago.descripcion) filaPago.descripcion.textContent = '—';
        if (filaPago.moneda) filaPago.moneda.textContent = '—';
        filaPago.metodo.dataset.codigoReal = '';
        filaPago.monto.value = '';
        filaPago.referencia.value = '';
        filaPago.fila.classList.remove('fila-pago-ventas--zelle');

        if (indice === 0) {
            activarFilaPagoVentas(filaPago);
            return;
        }
        bloquearFilaPagoVentas(filaPago);
    });

    elementos.botonConfirmarCobroVentas.disabled = true;
}
function obtenerTotalVentaActual() {
    const totales = calcularTotalesVenta();

    return {
        ...totales,

        totalBsNumero: Number(totales.totalBs || 0),
        totalUsdNumero: Number(totales.totalUsd || 0)
    };
}

function calcularPagosModalCobroVentas() {
    const tasa =
        obtenerTasaVentaNumero();

    const filas =
        obtenerFilasPagoVentas();

    const pagos = [];

    for (const filaPago of filas) {
        if (filaPago.metodo.disabled) {
            continue;
        }

        const codigoReal = filaPago.metodo.dataset.codigoReal;
        const metodo = METODOS_PAGO_VENTAS[codigoReal];
        if (!metodo) continue;

        const monto =
            obtenerMontoPagoNormalizado(
                filaPago.monto.value
            );

        if (!metodo || monto === 0) {
            continue;
        }

        const montoBsEquivalente =
            metodo.moneda === 'USD'
                ? monto * tasa
                : monto;

        const montoUsdEquivalente =
            metodo.moneda === 'USD'
                ? monto
                : monto / tasa;

        pagos.push({
            metodoPago: metodo.codigo,
            monto,
            referencia: String(
                filaPago.referencia.value || ''
            ).trim(),

            moneda: metodo.moneda,

            montoBsEquivalente,
            montoUsdEquivalente
        });
    }

    const totalPagadoBs =
        pagos.reduce((total, pago) => {
            return total + pago.montoBsEquivalente;
        }, 0);

    const totalPagadoUsd =
        pagos.reduce((total, pago) => {
            return total + pago.montoUsdEquivalente;
        }, 0);

    return {
        pagos,
        totalPagadoBs,
        totalPagadoUsd
    };
}

function actualizarZelleFilaPago(filaPago) {
    if (!filaPago || filaPago.metodo.dataset.codigoReal !== 'ZELLE') {
        return;
    }

    const detalle = estado.zelleDetalles[filaPago.numero] || {
        remitente: '',
        referencia: ''
    };

    filaPago.referencia.value =
        detalle.remitente && detalle.referencia
            ? `${detalle.remitente} · ${detalle.referencia}`
            : detalle.referencia || '';
}

function obtenerZelleDetalleFila(numero) {
    return estado.zelleDetalles[numero] || {
        remitente: '',
        referencia: ''
    };
}

function guardarZelleDetalleFila(numero, detalle) {
    estado.zelleDetalles[numero] = {
        remitente: String(detalle.remitente || '').trim(),
        referencia: String(detalle.referencia || '').trim()
    };
}

function validarMontoZelle(valor) {
    return obtenerMontoPagoNormalizado(valor) > 0;
}

function actualizarModalCobroVentas() {
    const totalVenta =
        obtenerTotalVentaActual();

    const resumenPagos =
        calcularPagosModalCobroVentas();

    const pendiente =
        Math.min(
            0,
            resumenPagos.totalPagadoBs -
            totalVenta.totalBsNumero
        );

    const pendienteUsd =
        Math.min(
            0,
            resumenPagos.totalPagadoUsd -
            totalVenta.totalUsdNumero
        );

    const vuelto =
        Math.max(
            0,
            resumenPagos.totalPagadoBs -
            totalVenta.totalBsNumero
        );

    const vueltoUsd =
        totalVenta.totalBsNumero > 0
            ? vuelto / obtenerTasaVentaNumero()
            : 0;

    const diferencia =
        resumenPagos.totalPagadoBs -
        totalVenta.totalBsNumero;

    const diferenciaUsd =
        resumenPagos.totalPagadoUsd -
        totalVenta.totalUsdNumero;

    elementos.modalTotalBsVentas.textContent =
        formatearBolivares(
            totalVenta.totalBsNumero
        );

    elementos.modalTotalUsdVentas.textContent =
        formatearUsd(
            totalVenta.totalUsdNumero
        );

    elementos.modalPendienteVentas.innerHTML =
        `${formatearBolivares(pendiente)} <span class="modal-cobro-ventas__subtexto">(${formatearUsd(pendienteUsd)})</span>`;

    elementos.modalCanceladoVentas.innerHTML =
        `${formatearBolivares(
            resumenPagos.totalPagadoBs
        )} <span class="modal-cobro-ventas__subtexto">(${formatearUsd(resumenPagos.totalPagadoUsd)})</span>`;

    elementos.modalDiferenciaVentas.innerHTML =
        `${formatearBolivares(diferencia)} <span class="modal-cobro-ventas__subtexto">(${formatearUsd(diferenciaUsd)})</span>`;

    elementos.modalVueltoVentas.innerHTML =
        `${formatearBolivares(vuelto)} <span class="modal-cobro-ventas__subtexto">(${formatearUsd(vueltoUsd)})</span>`;

    elementos.botonConfirmarCobroVentas.disabled =
        estado.carrito.length === 0 ||
        resumenPagos.pagos.length === 0 ||
        resumenPagos.totalPagadoBs + 0.01 <
        totalVenta.totalBsNumero;
}

function obtenerFilaPagoVentasPorNumero(numero) {
    return obtenerFilasPagoVentas().find((filaPago) => filaPago.numero === numero);
}

function avanzarFocoPagoVentas(filaPago, { desdeReferencia = false } = {}) {
    if (!filaPago) {
        return;
    }

    const totalVenta = obtenerTotalVentaActual();
    const resumenPagos = calcularPagosModalCobroVentas();
    const pendiente = Math.max(
        0,
        totalVenta.totalBsNumero - resumenPagos.totalPagadoBs
    );

    const pagoExcedido = resumenPagos.totalPagadoBs > totalVenta.totalBsNumero + 0.01;
    if (pendiente <= 0.01 && !pagoExcedido) {
        return;
    }

    const metodo = filaPago.metodo.dataset.codigoReal
        ? METODOS_PAGO_VENTAS[filaPago.metodo.dataset.codigoReal]
        : null;

    if (metodo?.requiereReferencia) {
        if (!desdeReferencia) {
            if (!filaPago.referencia.disabled) {
                filaPago.referencia.focus();
                filaPago.referencia.select();
            }
            return;
        }

        const referencia = String(filaPago.referencia?.value || '').trim();
        if (!referencia) {
            if (!filaPago.referencia.disabled) {
                filaPago.referencia.focus();
                filaPago.referencia.select();
            }
            return;
        }
    }

    const siguienteFila = obtenerFilasPagoVentas().find(
        (siguiente) => siguiente.numero === filaPago.numero + 1
    );

    if (!siguienteFila) {
        return;
    }

    activarFilaPagoVentas(siguienteFila);
    siguienteFila.metodo.focus();
    siguienteFila.metodo.select();
}

function actualizarFilasPagoVentas() {
    const filas = obtenerFilasPagoVentas();
    filas.forEach((filaPago, indice) => {
        if (filaPago.metodo.disabled) return;

        const codigoReal = filaPago.metodo.dataset.codigoReal;
        const metodo = codigoReal
            ? METODOS_PAGO_VENTAS[codigoReal]
            : null;
        const esDV = codigoReal === 'DV';
        const dvAutorizada = esDV && estado.dvAutorizacionFilaNumero === filaPago.numero && estado.dvAutorizacionValidada;

        filaPago.monto.disabled = !codigoReal || (esDV && !dvAutorizada);
        filaPago.referencia.disabled = esDV
            ? !dvAutorizada
            : !codigoReal || metodo?.requiereReferencia === false;

        if (esDV && dvAutorizada) {
            filaPago.fila.classList.add('fila-pago-ventas--dv');
        } else {
            filaPago.fila.classList.remove('fila-pago-ventas--dv');
        }

        const monto = obtenerMontoPagoNormalizado(filaPago.monto.value);
        const referencia = String(filaPago.referencia?.value || '').trim();
        const requiereReferencia = metodo?.requiereReferencia === true;
        const puedeActivarSiguiente = codigoReal && monto !== 0 && (!requiereReferencia || referencia !== '');
        const siguiente = filas[indice + 1];
        if (!siguiente) return;

        if (puedeActivarSiguiente) {
            activarFilaPagoVentas(siguiente);
            return;
        }
        for (let i = indice + 1; i < filas.length; i++) {
            bloquearFilaPagoVentas(filas[i]);
        }
    });
    actualizarModalCobroVentas();
}

function procesarEnterPagoVenta(input, filaPago, evento) {
    if (evento?.key === 'Enter') {
        const ahora = Date.now();
        if (
            ultimoEnterPago.input === input &&
            ahora - ultimoEnterPago.timestamp < 120
        ) {
            return;
        }
        ultimoEnterPago.input = input;
        ultimoEnterPago.timestamp = ahora;
    }

    const filaActual = obtenerFilaPagoVentasPorNumero(filaPago.numero);
    if (!filaActual || filaActual.metodo.disabled) {
        return;
    }

    if (input.id.startsWith('montoPagoVentas')) {
        const texto = String(input.value ?? '').trim();
        const monto = obtenerMontoPagoNormalizado(texto);

        if (texto === '' || monto === 0) {
            return;
        }
    }

    window.setTimeout(() => {
        if (input.id.startsWith('montoPagoVentas')) {
            formatearMontoPagoInput(input);
        }
        actualizarFilasPagoVentas();
        actualizarModalCobroVentas();
        avanzarFocoPagoVentas(filaActual, {
            desdeReferencia: input.id.startsWith('referenciaPagoVentas')
        });
    }, 0);
}

function abrirModalZelleVentas(filaPago) {
    if (!filaPago) return;

    const detalle = obtenerZelleDetalleFila(filaPago.numero);

    elementos.zelleMontoVentas.value = filaPago.monto.value || detalle.monto || '';
    elementos.zelleRemitenteVentas.value = detalle.remitente || '';
    elementos.zelleReferenciaVentas.value = detalle.referencia || '';
    elementos.zelleMensajeVentas.textContent = '';

    elementos.modalZelleVentas.hidden = false;
    elementos.modalZelleVentas.setAttribute('aria-hidden', 'false');

    window.setTimeout(() => {
        elementos.zelleMontoVentas.focus();
        elementos.zelleMontoVentas.select();
    }, 40);
}

function cerrarModalZelleVentas() {
    elementos.modalZelleVentas.hidden = true;
    elementos.modalZelleVentas.setAttribute('aria-hidden', 'true');
    elementos.zelleMensajeVentas.textContent = '';
}

async function solicitarAutorizacionZelleVentas(filaPago) {
    if (!filaPago) return;

    estado.zelleAutorizacionFilaNumero = filaPago.numero;
    filaPago.monto.disabled = true;
    filaPago.referencia.disabled = true;
    actualizarModalCobroVentas();

    const requiere = await requiereClaveAutorizacionVentas().catch(
        () => true
    );

    if (!requiere) {
        estado.zelleAutorizacionValidada = true;
        abrirModalZelleVentas(filaPago);
        return;
    }

    abrirModalAutorizacionVentas({
        titulo: 'Autorizar Zelle',
        descripcion:
            'Ingrese la clave de autorización del propietario para registrar un pago Zelle.',
        ejecutar: async (clave) => {
            await validarClaveAutorizacionZelleParaVenta(clave);
            estado.zelleAutorizacionValidada = true;
            abrirModalZelleVentas(filaPago);
        }
    });
}

function validarClaveAutorizacionZelleParaVenta(clave) {
    const claveNormalizada = normalizarClaveOperacionVentas(clave);

    if (!claveNormalizada) {
        throw new Error(
            'Ingrese una clave de autorización válida.'
        );
    }

    return solicitarJSONVentas(
        '/api/seguridad-operativa/verificar',
        {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                clave: claveNormalizada,
                accion: 'CREAR_ZELLE',
                detalle:
                    'Autorización para venta con método Zelle desde Punto de Venta.'
            })
        }
    );
}

function activarFilaPagoVentas(filaPago) {
    filaPago.fila.classList.remove('fila-pago-ventas--bloqueada');
    filaPago.metodo.removeAttribute('disabled');
    filaPago.metodo.disabled = false;
}

function abrirModalCobroVentas() {
    if (!estado.puedeVender) {
        mostrarMensaje(
            'La caja no está abierta para vender.'
        );

        return;
    }

    if (estado.carrito.length === 0) {
        mostrarMensaje(
            'Agregue productos antes de cobrar.'
        );

        return;
    }

    estado.dvAutorizacionValidada = false;
    estado.dvAutorizacionFilaNumero = null;
    estado.zelleAutorizacionValidada = false;
    estado.zelleAutorizacionFilaNumero = null;
    reiniciarModalCobroVentas();
    actualizarModalCobroVentas();

    elementos.modalCobroVentas.hidden = false;
    elementos.modalCobroVentas.setAttribute(
        'aria-hidden',
        'false'
    );

    window.setTimeout(() => {
        elementos.metodoPagoVentas1.focus();
    }, 40);
}

function cerrarModalCobroVentas() {
    elementos.modalCobroVentas.hidden = true;
    elementos.modalCobroVentas.setAttribute(
        'aria-hidden',
        'true'
    );
    estado.dvAutorizacionValidada = false;
    estado.dvAutorizacionFilaNumero = null;
    estado.zelleAutorizacionValidada = false;
    estado.zelleAutorizacionFilaNumero = null;
}

function construirPagosParaConfirmarVenta() {
    const resumenPagos = calcularPagosModalCobroVentas();

    if (resumenPagos.pagos.length === 0) {
        throw new Error('Registre al menos un método de pago.');
    }

    return resumenPagos.pagos.map((pago) => {
        return {
            metodoPago: pago.metodoPago,
            monto: pago.monto,
            referencia: pago.referencia
        };
    });
}

/* =========================================================
   ACCESIBILIDAD: desactivar autocompletado y navegación con flechas
   dentro del modal de métodos de pago
   ========================================================= */

function desactivarAutocompleteGlobal() {
    try {
        // Formas comunes: foro y todos los inputs
        document.querySelectorAll('form').forEach((f) => {
            try { f.setAttribute('autocomplete', 'off'); } catch (e) {}
        });

        document.querySelectorAll('input, textarea, select').forEach((el) => {
            try {
                el.setAttribute('autocomplete', 'off');
                el.setAttribute('autocorrect', 'off');
                el.setAttribute('autocapitalize', 'off');
                el.setAttribute('spellcheck', 'false');
                // Some browsers ignore 'off' — use harmless alternative token
                el.setAttribute('data-autocomplete-disabled', '1');
            } catch (e) {}
        });
    } catch (e) {
        // no hacer nada si falla
    }
}

function inicializarNavegacionFlechasPagos() {
    const ids = [];
    for (let i = 1; i <= 5; i++) {
        ids.push(`metodoPagoVentas${i}`);
        ids.push(`montoPagoVentas${i}`);
        ids.push(`referenciaPagoVentas${i}`);
    }

    const orden = ids.map((id) => document.getElementById(id)).filter(Boolean);

    function focoEnIndice(indice) {
        if (indice < 0 || indice >= orden.length) return;
        const el = orden[indice];
        if (!el || el.disabled) return;
        el.focus();
        if (typeof el.select === 'function') {
            try { el.select(); } catch (e) {}
        }
    }

    function indiceDeElemento(el) {
        return orden.indexOf(el);
    }

    function moverFoco(el, direccion) {
        if (!el) return;
        const idx = indiceDeElemento(el);
        if (idx === -1) return;
        let i = idx + (direccion === 'next' ? 1 : -1);
        // buscar siguiente foco disponible (no disabled)
        while (i >= 0 && i < orden.length) {
            const cand = orden[i];
            if (cand && !cand.disabled) {
                focoEnIndice(i);
                return;
            }
            i += (direccion === 'next' ? 1 : -1);
        }
    }

    function keyHandler(e) {
        const el = e.target;
        if (!el || !el.id) return;
        if (!el.id.startsWith('metodoPagoVentas') && !el.id.startsWith('montoPagoVentas') && !el.id.startsWith('referenciaPagoVentas')) return;

        // Flechas y tabulación con shift (permitir tab normal)
        if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
            e.preventDefault();
            moverFoco(el, 'next');
            return;
        }

        if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
            e.preventDefault();
            moverFoco(el, 'prev');
            return;
        }
    }

    orden.forEach((el) => {
        if (!el) return;
        el.addEventListener('keydown', keyHandler);
        // asegurar que el autocompletado está desactivado también aquí
        try {
            el.setAttribute('autocomplete', 'off');
        } catch (e) {}
    });
}

// Inicializar cuando el DOM esté listo
if (document.readyState === 'loading') {
    window.addEventListener('DOMContentLoaded', () => {
        desactivarAutocompleteGlobal();
        inicializarNavegacionFlechasPagos();
    });
} else {
    desactivarAutocompleteGlobal();
    inicializarNavegacionFlechasPagos();
}

function pagosContienenDevolucionVentas(pagos) {
    return Array.isArray(pagos) && pagos.some((pago) => pago?.metodoPago === 'DV');
}

async function solicitarAutorizacionDVVentas(filaPago) {
    if (estado.dvAutorizacionValidada) {
        return;
    }

    estado.dvAutorizacionFilaNumero = filaPago?.numero || null;
    if (filaPago) {
        filaPago.monto.disabled = true;
        filaPago.referencia.disabled = true;
        actualizarModalCobroVentas();
    }

    const requiere = await requiereClaveAutorizacionVentas().catch(
        () => true
    );

    if (!requiere) {
        estado.dvAutorizacionValidada = true;
        if (filaPago) {
            filaPago.monto.disabled = false;
            filaPago.referencia.disabled = false;
            filaPago.fila.classList.add('fila-pago-ventas--dv');
            actualizarModalCobroVentas();
            filaPago.monto.focus();
            filaPago.monto.select();
        }
        return;
    }

    abrirModalAutorizacionVentas({
        titulo: 'Autorizar método DV',
        descripcion:
            'Ingrese la clave de autorización del propietario para usar el método DV en esta venta.',
        ejecutar: async (clave) => {
            await validarClaveAutorizacionDVParaVenta(clave);
            estado.dvAutorizacionValidada = true;
            if (filaPago) {
                filaPago.monto.disabled = false;
                filaPago.referencia.disabled = false;
                actualizarModalCobroVentas();
                filaPago.monto.focus();
                filaPago.monto.select();
            }
        }
    });
}

async function validarClaveAutorizacionDVParaVenta(clave) {
    const claveNormalizada =
        normalizarClaveOperacionVentas(clave);

    if (!claveNormalizada) {
        throw new Error(
            'Ingrese una clave de autorización válida.'
        );
    }

    await solicitarJSONVentas(
        '/api/seguridad-operativa/verificar',
        {
            method: 'POST',

            headers: {
                'Content-Type': 'application/json'
            },

            body: JSON.stringify({
                clave: claveNormalizada,
                accion: 'CREAR_DEVOLUCION',
                detalle:
                    'Autorización para venta con método DV desde Punto de Venta.'
            })
        }
    );
}

async function prepararConfirmarVentaDesdeModal() {
    const resumenPagos = calcularPagosModalCobroVentas();
    const necesitaAutorizacionDV =
        pagosContienenDevolucionVentas(resumenPagos.pagos);

    if (necesitaAutorizacionDV && !estado.dvAutorizacionValidada) {
        await solicitarAutorizacionDVVentas();

        if (!estado.dvAutorizacionValidada) {
            return;
        }
    }

    await confirmarVentaDesdeModal();
}

function construirProductosParaConfirmarVenta() {
    return estado.carrito.map((linea) => {
        return {
            productoId: linea.producto.id,
            cantidad: linea.cantidad
        };
    });
}

function construirClienteParaConfirmarVenta() {
    if (!estado.clienteSeleccionado?.id) {
        return null;
    }

    return {
        id: estado.clienteSeleccionado.id
    };
}
async function imprimirFacturaVentaRegistradaAutomaticamente(venta) {
    const ventaId =
        Number(
            venta?.id ||
            venta?.ventaId ||
            venta?.venta_id
        );

    if (
        !Number.isInteger(ventaId) ||
        ventaId < 1
    ) {
        throw new Error(
            'La venta fue registrada, pero no se recibió un ID válido para imprimir.'
        );
    }

    return solicitarJSONVentas(
        `/api/impresion/venta/${encodeURIComponent(ventaId)}`,
        {
            method: 'POST',

            headers: {
                'Content-Type': 'application/json'
            },

            body: JSON.stringify({
                tipoCopia: 'VENTA'
            })
        }
    );
}
function reiniciarCicloVentaDespuesDeConfirmar() {
    estado.clienteSeleccionado = null;

    elementos.documentoClienteVentas.value = '';

    elementos.estadoClienteVentas.textContent =
        'Esperando cliente';

    elementos.estadoClienteVentas.className =
        'estado-cliente-ventas';

    elementos.detalleClienteVentas.className =
        'campo-venta__ayuda';

    elementos.detalleClienteVentas.textContent =
        'Ingrese cédula, RIF o pasaporte. Use V- para consumidor final.';

    actualizarControlesSegunCaja();

    window.setTimeout(() => {
        elementos.documentoClienteVentas.focus();
        elementos.documentoClienteVentas.select();
    }, 80);
}
async function confirmarVentaDesdeModal() {
    const textoOriginal =
        elementos.botonConfirmarCobroVentas.textContent;

    try {
        elementos.botonConfirmarCobroVentas.disabled = true;
        elementos.botonConfirmarCobroVentas.textContent =
            'Confirmando.';

        const cuerpo = {
            cliente: construirClienteParaConfirmarVenta(),
            productos: construirProductosParaConfirmarVenta(),
            pagos: construirPagosParaConfirmarVenta()
        };

        const respuesta = await fetch(
            '/api/ventas/confirmar',
            {
                method: 'POST',

                headers: {
                    'Content-Type': 'application/json'
                },

                body: JSON.stringify(cuerpo)
            }
        );

        const datos = await respuesta.json();

        if (!respuesta.ok || !datos.ok) {
            throw new Error(
                datos.mensaje ||
                'No fue posible confirmar la venta.'
            );
        }

        const ventaRegistrada =
            datos.venta || {};

        cerrarModalCobroVentas();

        estado.carrito = [];

        limpiarProductoSeleccionado({
            enfocar: false
        });

        reiniciarCicloVentaDespuesDeConfirmar();

        mostrarMensaje(
            'Venta registrada correctamente. Imprimiendo ticket.'
        );

        console.log(
            'Venta registrada:',
            ventaRegistrada
        );

        try {
            await imprimirFacturaVentaRegistradaAutomaticamente(
                ventaRegistrada
            );

            mostrarMensaje(
                `Venta ${ventaRegistrada.numeroFactura || ''} registrada y enviada a impresión.`
            );
        } catch (errorImpresion) {
            console.error(
                'La venta fue registrada, pero no se pudo imprimir:',
                errorImpresion
            );

            /*
                Si la impresión está deshabilitada por configuración,
                no tratamos eso como falla grave.
            */
            if (
                /deshabilitada/i.test(
                    errorImpresion.message || ''
                )
            ) {
                mostrarMensaje(
                    datos.mensaje ||
                    'Venta registrada correctamente.'
                );

                return;
            }

            mostrarMensaje(
                `Venta registrada, pero no se pudo imprimir: ${errorImpresion.message || 'verifique la impresora.'}`
            );
        }
    } catch (error) {
        console.error(
            'Error confirmando venta:',
            error
        );

        mostrarMensaje(
            error.message ||
            'No fue posible confirmar la venta.'
        );

        actualizarModalCobroVentas();
    } finally {
        elementos.botonConfirmarCobroVentas.disabled = false;

        elementos.botonConfirmarCobroVentas.textContent =
            textoOriginal;
    }
}
function escaparHTMLVentas(valor) {
    return String(valor ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

async function solicitarJSONVentas(ruta, opciones = {}) {
    const respuesta = await fetch(ruta, {
        cache: 'no-store',
        ...opciones
    });

    let datos = null;

    try {
        datos = await respuesta.json();
    } catch (error) {
        datos = null;
    }

    if (!respuesta.ok || !datos?.ok) {
        throw new Error(
            datos?.mensaje ||
            'No fue posible completar la operación.'
        );
    }

    return datos;
}

function normalizarClaveOperacionVentas(valor) {
    const texto = String(valor ?? '')
        .trim()
        .replace(/\s+/g, '');

    if (!/^\d{4,12}$/.test(texto)) {
        return null;
    }

    return texto;
}

function formatearFechaHoraHistorialVentas(valor) {
    if (!valor) {
        return 'Sin fecha';
    }

    const fecha = new Date(
        String(valor).includes(' ')
            ? String(valor).replace(' ', 'T')
            : valor
    );

    if (Number.isNaN(fecha.getTime())) {
        return String(valor);
    }

    return new Intl.DateTimeFormat('es-VE', {
        dateStyle: 'short',
        timeStyle: 'short'
    }).format(fecha);
}

function formatearCantidadHistorialVentas(valor, unidad = '') {
    const numero = Number(valor || 0);

    const cantidad = Number.isFinite(numero)
        ? numero.toLocaleString('es-VE', {
            minimumFractionDigits: 0,
            maximumFractionDigits: 3
        })
        : '0';

    return `${cantidad} ${unidad || ''}`.trim();
}

/* =========================================================
   MODAL DE AUTORIZACIÓN
   ========================================================= */

function abrirModalAutorizacionVentas(configuracion) {
    estado.operacionAutorizacionPendiente =
        configuracion;

    elementos.tituloAutorizarOperacionVentas.textContent =
        configuracion.titulo || 'Clave requerida';

    elementos.descripcionAutorizarOperacionVentas.textContent =
        configuracion.descripcion ||
        'Ingrese la clave de autorización del propietario.';

    elementos.claveAutorizarOperacionVentas.value = '';
    elementos.mensajeAutorizarOperacionVentas.textContent = '';

    elementos.modalAutorizarOperacionVentas.hidden = false;
    elementos.modalAutorizarOperacionVentas.setAttribute(
        'aria-hidden',
        'false'
    );

    window.setTimeout(() => {
        elementos.claveAutorizarOperacionVentas.focus();
    }, 40);
}

function cerrarModalAutorizacionVentas() {
    elementos.modalAutorizarOperacionVentas.hidden = true;
    elementos.modalAutorizarOperacionVentas.setAttribute(
        'aria-hidden',
        'true'
    );

    elementos.claveAutorizarOperacionVentas.value = '';
    elementos.mensajeAutorizarOperacionVentas.textContent = '';

    estado.operacionAutorizacionPendiente = null;
}

function abrirModalConfirmacionVentas(configuracion) {
    estado.confirmacionVentas = {
        ejecucion: configuracion.ejecutar || null,
        textoTitulo: configuracion.titulo || 'Confirmar acción',
        textoDescripcion: configuracion.descripcion || '',
        textoConfirmar: configuracion.confirmar || 'Confirmar'
    };

    elementos.tituloConfirmacionVentas.textContent =
        estado.confirmacionVentas.textoTitulo;
    elementos.descripcionConfirmacionVentas.textContent =
        estado.confirmacionVentas.textoDescripcion;
    elementos.subtextoConfirmacionVentas.textContent =
        configuracion.subtexto || '';

    elementos.botonConfirmarConfirmacionVentas.textContent =
        estado.confirmacionVentas.textoConfirmar;

    elementos.modalConfirmacionVentas.hidden = false;
    elementos.modalConfirmacionVentas.setAttribute(
        'aria-hidden',
        'false'
    );
}

function cerrarModalConfirmacionVentas() {
    elementos.modalConfirmacionVentas.hidden = true;
    elementos.modalConfirmacionVentas.setAttribute(
        'aria-hidden',
        'true'
    );

    estado.confirmacionVentas = {
        ejecucion: null,
        textoTitulo: '',
        textoDescripcion: '',
        textoConfirmar: ''
    };
}

async function procesarConfirmacionVentas(evento) {
    evento.preventDefault();

    if (typeof estado.confirmacionVentas.ejecucion !== 'function') {
        cerrarModalConfirmacionVentas();
        return;
    }

    try {
        elementos.botonConfirmarConfirmacionVentas.disabled = true;
        await Promise.resolve(estado.confirmacionVentas.ejecucion());
    } finally {
        elementos.botonConfirmarConfirmacionVentas.disabled = false;
        cerrarModalConfirmacionVentas();
    }
}

async function procesarAutorizacionOperacionVentas(evento) {
    evento.preventDefault();

    const configuracion =
        estado.operacionAutorizacionPendiente;

    if (!configuracion?.ejecutar) {
        cerrarModalAutorizacionVentas();

        return;
    }

    const clave =
        normalizarClaveOperacionVentas(
            elementos.claveAutorizarOperacionVentas.value
        );

    if (!clave) {
        elementos.mensajeAutorizarOperacionVentas.textContent =
            'Ingrese una clave válida de 4 a 12 números.';

        elementos.claveAutorizarOperacionVentas.focus();

        return;
    }

    const textoOriginal =
        elementos.botonConfirmarAutorizarOperacionVentas.textContent;

    try {
        elementos.botonConfirmarAutorizarOperacionVentas.disabled =
            true;

        elementos.botonConfirmarAutorizarOperacionVentas.textContent =
            'Verificando...';

        await configuracion.ejecutar(clave);

        cerrarModalAutorizacionVentas();
    } catch (error) {
        console.error(
            'Error autorizando operación:',
            error
        );

        elementos.mensajeAutorizarOperacionVentas.textContent =
            error.message ||
            'No fue posible autorizar la operación.';

        elementos.claveAutorizarOperacionVentas.select();
    } finally {
        elementos.botonConfirmarAutorizarOperacionVentas.disabled =
            false;

        elementos.botonConfirmarAutorizarOperacionVentas.textContent =
            textoOriginal;
    }
}

/* =========================================================
   HISTORIAL AUTORIZADO
   ========================================================= */

function mostrarEstadoHistorialVentas(mensaje) {
    elementos.estadoHistorialVentas.textContent =
        mensaje;
}

function limpiarDetalleHistorialVentas(mensaje = 'Seleccione una factura para ver su detalle.') {
    estado.ventaHistorialSeleccionada = null;

    elementos.detalleHistorialVentas.innerHTML = `
        <div class="historial-ventas__vacio">
            ${escaparHTMLVentas(mensaje)}
        </div>
    `;
}
function renderizarListadoHistorialVentas(ventas) {
    elementos.listadoHistorialVentas.replaceChildren();

    if (!Array.isArray(ventas) || ventas.length === 0) {
        elementos.listadoHistorialVentas.innerHTML = `
            <div class="historial-ventas__vacio">
                No hay facturas registradas.
            </div>
        `;

        limpiarDetalleHistorialVentas();

        return;
    }

    ventas.forEach((venta) => {
        const boton = document.createElement('button');

        boton.type = 'button';
        boton.className = 'item-historial-ventas';
        boton.dataset.ventaId = venta.id;

        boton.innerHTML = `
            <strong>${escaparHTMLVentas(venta.numeroFactura)}</strong>
            <span>${escaparHTMLVentas(venta.clienteNombre || 'Consumidor final')}</span>
            <small>
                ${escaparHTMLVentas(formatearBolivares(Number(venta.totalBs || 0)))}
                ·
                ${escaparHTMLVentas(formatearFechaHoraHistorialVentas(venta.creadoEn))}
            </small>
        `;

        boton.addEventListener('click', () => {
            document.querySelectorAll('.item-historial-ventas')
                .forEach((item) => {
                    item.classList.remove('item-historial-ventas--activo');
                });

            boton.classList.add('item-historial-ventas--activo');

            cargarDetalleHistorialVentasAutorizado({
                ventaId: venta.id
            });
        });

        elementos.listadoHistorialVentas.appendChild(boton);
    });
}

function construirTablaProductosFacturaVentas(detalles) {
    if (!Array.isArray(detalles) || detalles.length === 0) {
        return `
            <div class="historial-ventas__vacio">
                Esta factura no tiene productos registrados.
            </div>
        `;
    }

    const filas = detalles.map((detalle) => {
        return `
            <tr>
                <td>${escaparHTMLVentas(detalle.codigoProducto)}</td>
                <td>${escaparHTMLVentas(detalle.nombreProducto)}</td>
                <td>${escaparHTMLVentas(formatearCantidadHistorialVentas(detalle.cantidad, detalle.unidadMedida))}</td>
                <td>${escaparHTMLVentas(formatearUsd(Number(detalle.precioUnitarioUsd || 0)))}</td>
                <td>${escaparHTMLVentas(formatearBolivares(Number(detalle.totalBs || 0)))}</td>
            </tr>
        `;
    }).join('');

    return `
        <table class="tabla-detalle-factura-ventas">
            <thead>
                <tr>
                    <th>Código</th>
                    <th>Producto</th>
                    <th>Cant.</th>
                    <th>Precio</th>
                    <th>Total Bs.</th>
                </tr>
            </thead>

            <tbody>
                ${filas}
            </tbody>
        </table>
    `;
}

function construirTablaPagosFacturaVentas(pagos) {
    if (!Array.isArray(pagos) || pagos.length === 0) {
        return `
            <div class="historial-ventas__vacio">
                Esta factura no tiene pagos registrados.
            </div>
        `;
    }

    const filas = pagos.map((pago) => {
        const monto = pago.moneda === 'USD'
            ? formatearUsd(Number(pago.montoOriginal || 0))
            : formatearBolivares(Number(pago.montoOriginal || 0));

        return `
            <tr>
                <td>${escaparHTMLVentas(String(pago.linea))}</td>
                <td>${escaparHTMLVentas(pago.metodoPagoNombre)}</td>
                <td>${escaparHTMLVentas(pago.moneda)}</td>
                <td>${escaparHTMLVentas(monto)}</td>
                <td>${escaparHTMLVentas(pago.referencia || '—')}</td>
            </tr>
        `;
    }).join('');

    return `
        <table class="tabla-detalle-factura-ventas">
            <thead>
                <tr>
                    <th>N.º</th>
                    <th>Método</th>
                    <th>Moneda</th>
                    <th>Monto</th>
                    <th>Referencia</th>
                </tr>
            </thead>

            <tbody>
                ${filas}
            </tbody>
        </table>
    `;
}

function renderizarDetalleHistorialVentas(venta) {
    estado.ventaHistorialSeleccionada = venta;
    elementos.detalleHistorialVentas.innerHTML = `
        <div class="detalle-factura-ventas">
            <div class="detalle-factura-ventas__cabecera">
                <div class="detalle-factura-ventas__titulo">
                    <strong>${escaparHTMLVentas(venta.numeroFactura)}</strong>
                    <small>
                        ${escaparHTMLVentas(formatearFechaHoraHistorialVentas(venta.creadoEn))}
                    </small>
                </div>

                <span class="detalle-factura-ventas__estado">
                    ${escaparHTMLVentas(venta.estado)}
                </span>
            </div>

            <div class="detalle-factura-ventas__datos">
                <div class="detalle-factura-ventas__dato">
                    <span>Cliente</span>
                    <strong>${escaparHTMLVentas(venta.clienteNombre || 'Consumidor final')}</strong>
                </div>

                <div class="detalle-factura-ventas__dato">
                    <span>Documento</span>
                    <strong>${escaparHTMLVentas(venta.clienteIdentificacion || '—')}</strong>
                </div>

                <div class="detalle-factura-ventas__dato">
                    <span>Cajero</span>
                    <strong>${escaparHTMLVentas(venta.cajeroNombre || '—')}</strong>
                </div>

                <div class="detalle-factura-ventas__dato">
                    <span>Tasa</span>
                    <strong>Bs. ${escaparHTMLVentas(Number(venta.tasaUsdVes || 0).toLocaleString('es-VE', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }))}</strong>
                </div>
            </div>

            <div class="detalle-factura-ventas__totales">
                <div class="detalle-factura-ventas__dato">
                    <span>Subtotal</span>
                    <strong>${escaparHTMLVentas(formatearBolivares(Number(venta.subtotalBs || 0)))}</strong>
                </div>

                <div class="detalle-factura-ventas__dato">
                    <span>IVA</span>
                    <strong>${escaparHTMLVentas(formatearBolivares(Number(venta.ivaBs || 0)))}</strong>
                </div>

                <div class="detalle-factura-ventas__dato">
                    <span>Total</span>
                    <strong>${escaparHTMLVentas(formatearBolivares(Number(venta.totalBs || 0)))}</strong>
                </div>

                <div class="detalle-factura-ventas__dato">
                    <span>Vuelto</span>
                    <strong>${escaparHTMLVentas(formatearBolivares(Number(venta.vueltoBs || 0)))}</strong>
                </div>
            </div>

            <div class="detalle-factura-ventas__seccion">
                <h3>Productos vendidos</h3>
                ${construirTablaProductosFacturaVentas(venta.detalles)}
            </div>

            <div class="detalle-factura-ventas__seccion">
                <h3>Métodos de pago</h3>
                ${construirTablaPagosFacturaVentas(venta.pagos)}
            </div>

<div class="detalle-factura-ventas__acciones">
    <button class="boton-secundario-ventas boton-reimprimir-historial-ventas"
        type="button" data-accion-historial="reimprimir">
        Reimprimir
    </button>
</div>
        </div>
    `;
}

function abrirModalHistorialVentas() {
    elementos.modalHistorialVentas.hidden = false;
    elementos.modalHistorialVentas.setAttribute(
        'aria-hidden',
        'false'
    );

    window.setTimeout(() => {
        elementos.busquedaHistorialVentas.focus();
    }, 40);
}

function cerrarModalHistorialVentas() {
    elementos.modalHistorialVentas.hidden = true;
    elementos.modalHistorialVentas.setAttribute(
        'aria-hidden',
        'true'
    );

    estado.claveTemporalHistorialVentas = null;

    elementos.busquedaHistorialVentas.value = '';

    elementos.listadoHistorialVentas.innerHTML = `
        <div class="historial-ventas__vacio">
            Cargando historial...
        </div>
    `;

    limpiarDetalleHistorialVentas();

    mostrarEstadoHistorialVentas(
        'Consulte las facturas registradas.'
    );
}

async function cargarHistorialVentasAutorizado(clave) {
    const datos = await solicitarJSONVentas(
        '/api/ventas/historial-autorizado',
        {
            method: 'POST',

            headers: {
                'Content-Type':
                    'application/json'
            },

            body: JSON.stringify({
                clave,
                limite: 50
            })
        }
    );

    estado.claveTemporalHistorialVentas = clave;

    renderizarListadoHistorialVentas(
        datos.ventas || []
    );

    mostrarEstadoHistorialVentas(
        `${(datos.ventas || []).length} factura(s) encontradas.`
    );

    abrirModalHistorialVentas();
}

async function requiereClaveAutorizacionVentas() {
    if (estado.autorizarClaveVentasRequerida !== null) {
        return estado.autorizarClaveVentasRequerida;
    }

    try {
        const resultado = await solicitarJSONVentas(
            '/api/seguridad-operativa/clave-autorizacion'
        );

        const requiere =
            resultado.claveAutorizacion?.autorizacionHabilitada !== false;

        estado.autorizarClaveVentasRequerida = requiere;

        return requiere;
    } catch (error) {
        console.error('Error consultando estado de autorización:', error);

        estado.autorizarClaveVentasRequerida = true;

        return true; // por seguridad, requerir si hay error
    }
}

async function abrirHistorialVentasConAutorizacion() {
    const requiere = await requiereClaveAutorizacionVentas();

    if (!requiere) {
        // Si la autorización está deshabilitada, solicitar historial sin pedir clave
        await cargarHistorialVentasAutorizado(null);

        return;
    }

    abrirModalAutorizacionVentas({
        titulo: 'Abrir historial de ventas',

        descripcion:
            'Ingrese la clave de autorización del propietario para consultar facturas registradas.',

        ejecutar: async (clave) => {
            await cargarHistorialVentasAutorizado(
                clave
            );
        }
    });
}

async function cargarDetalleHistorialVentasAutorizado(
    parametros
) {
    let clave =
        estado.claveTemporalHistorialVentas;

    if (!clave) {
        const requiere = await requiereClaveAutorizacionVentas().catch(
            () => true
        );

        if (!requiere) {
            clave = null;
        } else {
            cerrarModalHistorialVentas();

            abrirHistorialVentasConAutorizacion();

            return;
        }
    }

    try {
        mostrarEstadoHistorialVentas(
            'Consultando detalle de factura...'
        );

        limpiarDetalleHistorialVentas(
            'Cargando detalle...'
        );

        const cuerpo = {
            clave
        };

        if (parametros.numeroFactura) {
            cuerpo.numeroFactura =
                parametros.numeroFactura;
        } else {
            cuerpo.ventaId =
                parametros.ventaId;
        }

        const datos = await solicitarJSONVentas(
            '/api/ventas/detalle-autorizado',
            {
                method: 'POST',

                headers: {
                    'Content-Type':
                        'application/json'
                },

                body: JSON.stringify(cuerpo)
            }
        );

        renderizarDetalleHistorialVentas(
            datos.venta
        );

        mostrarEstadoHistorialVentas(
            `Factura ${datos.venta.numeroFactura} cargada.`
        );
    } catch (error) {
        console.error(
            'Error consultando factura autorizada:',
            error
        );

        limpiarDetalleHistorialVentas(
            error.message ||
            'No fue posible consultar la factura.'
        );

        mostrarEstadoHistorialVentas(
            error.message ||
            'No fue posible consultar la factura.'
        );
    }
}

async function buscarFacturaHistorialVentas() {
    const numeroFactura =
        String(elementos.busquedaHistorialVentas.value || '')
            .trim()
            .toUpperCase();

    if (!numeroFactura) {
        await actualizarHistorialVentasAutorizado();

        return;
    }

    await cargarDetalleHistorialVentasAutorizado({
        numeroFactura
    });
}
async function reimprimirFacturaSeleccionadaConAutorizacion() {
    if (estado.reimprimiendoHistorialVentas) {
        return;
    }

    const venta =
        estado.ventaHistorialSeleccionada;

    if (!venta || !venta.id) {
        mostrarEstadoHistorialVentas(
            'Seleccione una factura antes de reimprimir.'
        );

        mostrarMensaje(
            'Seleccione una factura antes de reimprimir.'
        );

        return;
    }

    const clave =
        estado.claveTemporalHistorialVentas;

    if (!clave) {
        const requiere = await requiereClaveAutorizacionVentas().catch(
            () => true
        );

        if (!requiere) {
            // Autorización deshabilitada; continuar sin clave.
        } else {
            cerrarModalHistorialVentas();

            abrirHistorialVentasConAutorizacion();

            return;
        }
    }

    const boton =
        elementos.detalleHistorialVentas.querySelector(
            '[data-accion-historial="reimprimir"]'
        );

    const textoOriginal =
        boton?.textContent || 'Reimprimir';

    try {
        estado.reimprimiendoHistorialVentas = true;

        if (boton) {
            boton.disabled = true;
            boton.textContent = 'Imprimiendo...';
        }

        mostrarEstadoHistorialVentas(
            `Enviando ${venta.numeroFactura || 'factura'} a impresión.`
        );

        const datos = await solicitarJSONVentas(
            `/api/impresion/venta/${encodeURIComponent(venta.id)}`,
            {
                method: 'POST',

                headers: {
                    'Content-Type': 'application/json'
                },

                body: JSON.stringify({
                    tipoCopia: 'REIMPRESION',
                    clave
                })
            }
        );

        mostrarEstadoHistorialVentas(
            datos.mensaje ||
            `Factura ${venta.numeroFactura || ''} enviada a impresión.`
        );

        mostrarMensaje(
            datos.mensaje ||
            'Ticket enviado a impresión.'
        );
    } catch (error) {
        console.error(
            'Error reimprimiendo factura:',
            error
        );

        mostrarEstadoHistorialVentas(
            error.message ||
            'No fue posible reimprimir la factura.'
        );

        mostrarMensaje(
            error.message ||
            'No fue posible reimprimir la factura.'
        );
    } finally {
        estado.reimprimiendoHistorialVentas = false;

        if (boton) {
            boton.disabled = false;
            boton.textContent = textoOriginal;
        }
    }
}
async function actualizarHistorialVentasAutorizado() {
    const clave =
        estado.claveTemporalHistorialVentas;

    if (!clave) {
        const requiere = await requiereClaveAutorizacionVentas().catch(
            () => true
        );

        if (!requiere) {
            try {
                mostrarEstadoHistorialVentas(
                    'Actualizando historial...'
                );

                const datos = await solicitarJSONVentas(
                    '/api/ventas/historial-autorizado',
                    {
                        method: 'POST',

                        headers: {
                            'Content-Type':
                                'application/json'
                        },

                        body: JSON.stringify({
                            clave: null,
                            limite: 50
                        })
                    }
                );

                renderizarListadoHistorialVentas(
                    datos.ventas || []
                );

                limpiarDetalleHistorialVentas();

                mostrarEstadoHistorialVentas(
                    `${(datos.ventas || []).length} factura(s) encontradas.`
                );
            } catch (error) {
                console.error(
                    'Error actualizando historial: no fue posible cargar el historial deshabilitado',
                    error
                );

                mostrarEstadoHistorialVentas(
                    error.message ||
                    'No fue posible actualizar el historial.'
                );
            }

            return;
        }

        cerrarModalHistorialVentas();

        abrirHistorialVentasConAutorizacion();

        return;
    }

    try {
        mostrarEstadoHistorialVentas(
            'Actualizando historial...'
        );

        const datos = await solicitarJSONVentas(
            '/api/ventas/historial-autorizado',
            {
                method: 'POST',

                headers: {
                    'Content-Type':
                        'application/json'
                },

                body: JSON.stringify({
                    clave,
                    limite: 50
                })
            }
        );

        renderizarListadoHistorialVentas(
            datos.ventas || []
        );

        limpiarDetalleHistorialVentas();

        mostrarEstadoHistorialVentas(
            `${(datos.ventas || []).length} factura(s) encontradas.`
        );
    } catch (error) {
        console.error(
            'Error actualizando historial:',
            error
        );

        mostrarEstadoHistorialVentas(
            error.message ||
            'No fue posible actualizar el historial.'
        );
    }
}
/* =========================================================
   MODAL DE DEVOLUCIÓN
   ========================================================= */
async function validarClaveDevolucionVentas(clave) {
    const claveNormalizada =
        normalizarClaveOperacionVentas(clave);

    if (!claveNormalizada) {
        throw new Error(
            'Ingrese una clave de autorización válida.'
        );
    }

    await solicitarJSONVentas(
        '/api/seguridad-operativa/verificar',
        {
            method: 'POST',

            headers: {
                'Content-Type': 'application/json'
            },

            body: JSON.stringify({
                clave: claveNormalizada,
                accion: 'CREAR_DEVOLUCION',
                detalle: 'Apertura del módulo de devolución desde Punto de Venta.'
            })
        }
    );

    estado.claveTemporalDevolucionVentas =
        claveNormalizada;
}
function abrirDevolucionVentasConAutorizacion() {
    (async () => {
        const requiere = await requiereClaveAutorizacionVentas();

        if (!requiere) {
            abrirModalDevolucionVentas();
            return;
        }

        abrirModalAutorizacionVentas({
            titulo: 'Abrir devolución de venta',

            descripcion:
                'Ingrese la clave de autorización del propietario para registrar devoluciones de facturas.',

            ejecutar: async (clave) => {
                await validarClaveDevolucionVentas(
                    clave
                );

                abrirModalDevolucionVentas();
            }
        });
    })();
}
function asegurarModalDevolucionVentas() {
    let modal =
        document.getElementById('modalDevolucionVentas');

    if (modal) {
        return modal;
    }

    modal = document.createElement('div');
    modal.id = 'modalDevolucionVentas';
    modal.className = 'modal-devolucion-ventas oculto';

    modal.innerHTML = `
        <div class="modal-devolucion-ventas__fondo" data-cerrar-devolucion="1"></div>

        <section class="modal-devolucion-ventas__panel" role="dialog" aria-modal="true">
            <header class="modal-devolucion-ventas__cabecera">
                <div>
                    <p class="modal-devolucion-ventas__etiqueta">DEVOLUCIONES</p>
                    <h2>Devolución de venta</h2>
                    <span>Busque una factura para devolver productos parcial o totalmente.</span>
                </div>

                <button type="button"
                    class="modal-devolucion-ventas__cerrar"
                    data-cerrar-devolucion="1">
                    ×
                </button>
            </header>

            <div class="modal-devolucion-ventas__busqueda">
                <label for="inputFacturaDevolucionVentas">
                    Número de factura
                </label>

                <div class="modal-devolucion-ventas__fila-busqueda">
                    <input id="inputFacturaDevolucionVentas"
                        type="text"
                        autocomplete="off"
                        placeholder="Ejemplo: 000006 o FAC-000006">

                    <button id="botonBuscarFacturaDevolucionVentas"
                        type="button">
                        Buscar
                    </button>
                </div>

                <small>
                    También puede escribir solo el número: 6, 000006 o FAC-000006.
                </small>
            </div>

            <div id="estadoDevolucionVentas"
                class="modal-devolucion-ventas__estado">
                Esperando factura.
            </div>

            <div id="contenidoDevolucionVentas"
                class="modal-devolucion-ventas__contenido">
            </div>
        </section>
    `;

    document.body.appendChild(modal);

    modal.addEventListener('click', (evento) => {
        if (evento.target.dataset.cerrarDevolucion === '1') {
            cerrarModalDevolucionVentas();
        }
    });

    const inputFactura =
        modal.querySelector('#inputFacturaDevolucionVentas');

    const botonBuscar =
        modal.querySelector('#botonBuscarFacturaDevolucionVentas');

    botonBuscar.addEventListener('click', buscarFacturaParaDevolucionDesdeModal);

    inputFactura.addEventListener('keydown', (evento) => {
        if (evento.key === 'Enter') {
            evento.preventDefault();
            buscarFacturaParaDevolucionDesdeModal();
        }

        if (evento.key === 'Escape') {
            cerrarModalDevolucionVentas();
        }
    });
    modal.addEventListener('input', (evento) => {
        if (
            evento.target.matches('[data-cantidad-devolucion="1"]') ||
            evento.target.matches('[data-monto-metodo-devolucion="1"]') ||
            evento.target.matches('[data-referencia-metodo-devolucion="1"]')
        ) {
            recalcularResumenModalDevolucionVentas();
        }
    });

    modal.addEventListener('change', (evento) => {
        if (evento.target.matches('[data-seleccionar-devolucion="1"]')) {
            const fila =
                evento.target.closest('[data-fila-devolucion="1"]');

            const cantidadInput =
                fila?.querySelector('[data-cantidad-devolucion="1"]');

            const disponible =
                numeroDevolucionVentas(
                    fila?.dataset?.cantidadDisponible
                );

            const cantidadEntera =
                fila?.dataset?.cantidadEntera === '1';

            if (cantidadInput) {
                cantidadInput.disabled =
                    !evento.target.checked;

                if (evento.target.checked) {
                    cantidadInput.value =
                        cantidadEntera
                            ? '1'
                            : disponible.toFixed(3);

                    setTimeout(() => {
                        cantidadInput.focus();
                        cantidadInput.select();
                    }, 50);
                } else {
                    cantidadInput.value =
                        cantidadEntera
                            ? '0'
                            : '0.000';
                }
            }

            recalcularResumenModalDevolucionVentas();
        }

        if (evento.target.matches('[data-metodo-devolucion="1"]')) {
            const fila =
                evento.target.closest('[data-fila-metodo-devolucion="1"]');

            actualizarFilaMetodoDevolucionVentas(fila);
            recalcularResumenModalDevolucionVentas();
        }
    });

    modal.addEventListener('click', (evento) => {
        if (evento.target.id === 'botonAgregarMetodoDevolucionVentas') {
            agregarMetodoDevolucionVentas();
        }
        if (evento.target.id === 'botonContinuarMetodosDevolucionVentas') {
            const totalBs =
                redondearDevolucionVentas(
                    calcularTotalSeleccionadoDevolucionVentas(),
                    2
                );

            if (totalBs <= 0) {
                mostrarMensaje(
                    'Seleccione al menos un producto y una cantidad a devolver.'
                );

                return;
            }

            sugerirMontoPrimerMetodoDevolucionVentas();
            cambiarPasoDevolucionVentas('METODOS');
        }

        if (evento.target.id === 'botonVolverProductosDevolucionVentas') {
            cambiarPasoDevolucionVentas('PRODUCTOS');
        }

        if (evento.target.id === 'pasoProductosDevolucionVentas') {
            cambiarPasoDevolucionVentas('PRODUCTOS');
        }

        if (evento.target.id === 'pasoMetodosDevolucionVentas') {
            const totalBs =
                redondearDevolucionVentas(
                    calcularTotalSeleccionadoDevolucionVentas(),
                    2
                );

            if (totalBs <= 0) {
                mostrarMensaje(
                    'Seleccione productos antes de pasar a métodos.'
                );

                return;
            }

            sugerirMontoPrimerMetodoDevolucionVentas();
            cambiarPasoDevolucionVentas('METODOS');
        }
        if (evento.target.dataset.quitarMetodoDevolucion === '1') {
            const fila =
                evento.target.closest('[data-fila-metodo-devolucion="1"]');

            if (fila) {
                fila.remove();
                recalcularResumenModalDevolucionVentas();
            }
        }

        if (evento.target.id === 'botonConfirmarDevolucionVentas') {
            confirmarDevolucionDesdeModalVentas();
        }
    });
    modal.addEventListener('blur', (evento) => {
        if (
            evento.target.matches('[data-cantidad-devolucion="1"]')
        ) {
            normalizarCantidadCampoDevolucionVentas(
                evento.target
            );

            recalcularResumenModalDevolucionVentas();
        }
    }, true);
    return modal;
}

function abrirModalDevolucionVentas() {
    const modal =
        asegurarModalDevolucionVentas();

    modal.classList.remove('oculto');

    const inputFactura =
        modal.querySelector('#inputFacturaDevolucionVentas');

    const estadoModal =
        modal.querySelector('#estadoDevolucionVentas');

    const contenido =
        modal.querySelector('#contenidoDevolucionVentas');

    estadoModal.textContent =
        'Esperando factura.';

    contenido.innerHTML = '';

    inputFactura.value = '';
    inputFactura.focus();
}

function cerrarModalDevolucionVentas() {
    const modal =
        document.getElementById('modalDevolucionVentas');

    if (!modal) {
        return;
    }

    modal.classList.add('oculto');
    estado.claveTemporalDevolucionVentas = null;
    devolucionVentasPreparada = null;
    devolucionVentasConfirmando = false;
    pasoDevolucionVentas = 'PRODUCTOS';
}
function escaparHTMLDevolucionVentas(valor) {
    return String(valor ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function numeroDevolucionVentas(valor) {
    const numero = Number(
        String(valor ?? '0')
            .replace(/\s+/g, '')
            .replace(',', '.')
    );

    return Number.isFinite(numero)
        ? numero
        : 0;
}

function redondearDevolucionVentas(valor, decimales = 2) {
    const factor = 10 ** decimales;

    return Math.round(
        (numeroDevolucionVentas(valor) + Number.EPSILON) * factor
    ) / factor;
}
function esCantidadEnteraDevolucionVentas(detalle) {
    const textoUnidad =
        String(detalle?.unidadMedida || '')
            .trim()
            .toUpperCase();

    const textoTipo =
        String(detalle?.tipoVenta || '')
            .trim()
            .toUpperCase();

    const texto =
        `${textoUnidad} ${textoTipo}`;

    if (
        texto.includes('KG') ||
        texto.includes('KILO') ||
        texto.includes('GRAM') ||
        texto.includes('PESO') ||
        texto.includes('LB') ||
        texto.includes('LITRO') ||
        texto.includes('ML') ||
        texto.includes('METRO')
    ) {
        return false;
    }

    return true;
}

function formatearCantidadVisualDevolucionVentas(
    valor,
    detalle
) {
    const numero =
        numeroDevolucionVentas(valor);

    if (esCantidadEnteraDevolucionVentas(detalle)) {
        return String(
            Math.round(numero)
        );
    }

    return numero.toFixed(3);
}

function obtenerPasoCantidadDevolucionVentas(detalle) {
    return esCantidadEnteraDevolucionVentas(detalle)
        ? '1'
        : '0.001';
}

function obtenerCantidadInicialDevolucionVentas(detalle) {
    const disponible =
        numeroDevolucionVentas(
            detalle?.cantidadDisponible
        );

    if (disponible <= 0) {
        return esCantidadEnteraDevolucionVentas(detalle)
            ? '0'
            : '0.000';
    }

    if (esCantidadEnteraDevolucionVentas(detalle)) {
        return '1';
    }

    return disponible.toFixed(3);
}

function obtenerCantidadCeroDevolucionVentas(detalle) {
    return esCantidadEnteraDevolucionVentas(detalle)
        ? '0'
        : '0.000';
}
function obtenerFilasDevolucionVentas() {
    const modal =
        document.getElementById('modalDevolucionVentas');

    if (!modal) {
        return [];
    }

    return Array.from(
        modal.querySelectorAll('[data-fila-devolucion="1"]')
    );
}

function obtenerLineasSeleccionadasDevolucionVentas() {
    return obtenerFilasDevolucionVentas()
        .map((fila) => {
            const seleccionado =
                fila.querySelector('[data-seleccionar-devolucion="1"]');

            const cantidadInput =
                fila.querySelector('[data-cantidad-devolucion="1"]');

            if (!seleccionado?.checked) {
                return null;
            }

            const cantidadEntera =
                fila.dataset.cantidadEntera === '1';

            const cantidad =
                cantidadEntera
                    ? Math.round(
                        numeroDevolucionVentas(
                            cantidadInput?.value
                        )
                    )
                    : redondearDevolucionVentas(
                        cantidadInput?.value,
                        3
                    );

            return {
                ventaDetalleId:
                    Number(fila.dataset.ventaDetalleId),

                cantidad
            };
        })
        .filter((linea) => {
            return (
                linea &&
                Number.isFinite(linea.ventaDetalleId) &&
                linea.ventaDetalleId > 0 &&
                linea.cantidad > 0
            );
        });
}

function calcularTotalSeleccionadoDevolucionVentas() {
    return obtenerFilasDevolucionVentas()
        .reduce((total, fila) => {
            const seleccionado =
                fila.querySelector('[data-seleccionar-devolucion="1"]');

            const cantidadInput =
                fila.querySelector('[data-cantidad-devolucion="1"]');

            if (!seleccionado?.checked) {
                return total;
            }

            const cantidadDisponible =
                numeroDevolucionVentas(
                    fila.dataset.cantidadDisponible
                );

            const totalBsDisponible =
                numeroDevolucionVentas(
                    fila.dataset.totalBsDisponible
                );

            const cantidadEntera =
                fila.dataset.cantidadEntera === '1';

            const cantidadSeleccionada =
                cantidadEntera
                    ? Math.round(
                        numeroDevolucionVentas(
                            cantidadInput?.value
                        )
                    )
                    : redondearDevolucionVentas(
                        cantidadInput?.value,
                        3
                    );

            if (
                cantidadDisponible <= 0 ||
                cantidadSeleccionada <= 0
            ) {
                return total;
            }

            const cantidadValida =
                Math.min(
                    cantidadSeleccionada,
                    cantidadDisponible
                );

            const totalLinea =
                totalBsDisponible *
                (cantidadValida / cantidadDisponible);

            return total + totalLinea;
        }, 0);
}

function recalcularResumenModalDevolucionVentas() {
    const modal =
        document.getElementById('modalDevolucionVentas');

    if (!modal) {
        return;
    }

    const totalBs =
        redondearDevolucionVentas(
            calcularTotalSeleccionadoDevolucionVentas(),
            2
        );

    const resumenMetodos =
        calcularResumenMetodosDevolucionVentas();

    const pendienteBs =
        redondearDevolucionVentas(
            totalBs - resumenMetodos.totalBs,
            2
        );

    const totalProductos =
        modal.querySelector('#totalProductosDevolucionVentas');

    const textoTotal =
        modal.querySelector('#totalSeleccionadoDevolucionVentas');

    const textoAsignado =
        modal.querySelector('#totalAsignadoDevolucionVentas');

    const textoPendiente =
        modal.querySelector('#pendienteDevolucionVentas');

    const botonContinuar =
        modal.querySelector('#botonContinuarMetodosDevolucionVentas');

    const botonConfirmar =
        modal.querySelector('#botonConfirmarDevolucionVentas');

    if (totalProductos) {
        totalProductos.textContent =
            `Total devolución: Bs. ${totalBs.toFixed(2)}`;
    }

    if (textoTotal) {
        textoTotal.textContent =
            `Total: Bs. ${totalBs.toFixed(2)}`;
    }

    if (textoAsignado) {
        textoAsignado.textContent =
            `Asignado: Bs. ${resumenMetodos.totalBs.toFixed(2)}`;
    }

    if (textoPendiente) {
        textoPendiente.textContent =
            `Pendiente: Bs. ${pendienteBs.toFixed(2)}`;

        textoPendiente.classList.toggle(
            'modal-devolucion-ventas__pendiente--error',
            Math.abs(pendienteBs) > 0.01
        );
    }

    if (botonContinuar) {
        botonContinuar.disabled =
            totalBs <= 0;
    }

    if (botonConfirmar) {
        botonConfirmar.disabled =
            totalBs <= 0 ||
            resumenMetodos.pagos.length === 0 ||
            Math.abs(pendienteBs) > 0.01 ||
            !estado.claveTemporalDevolucionVentas ||
            devolucionVentasConfirmando;
    }
}
function normalizarCantidadCampoDevolucionVentas(inputCantidad) {
    const fila =
        inputCantidad.closest('[data-fila-devolucion="1"]');

    if (!fila) {
        return;
    }

    const cantidadEntera =
        fila.dataset.cantidadEntera === '1';

    const disponible =
        numeroDevolucionVentas(
            fila.dataset.cantidadDisponible
        );

    let cantidad =
        numeroDevolucionVentas(
            inputCantidad.value
        );

    if (cantidad < 0) {
        cantidad = 0;
    }

    if (disponible > 0 && cantidad > disponible) {
        cantidad = disponible;
    }

    if (cantidadEntera) {
        inputCantidad.value =
            String(Math.trunc(cantidad));
    } else {
        inputCantidad.value =
            redondearDevolucionVentas(
                cantidad,
                3
            ).toFixed(3);
    }
}

function manejarCambioFormularioDevolucionVentas(evento) {
    const objetivo =
        evento.target;

    if (
        objetivo.matches('[data-cantidad-devolucion="1"]')
    ) {
        /*
            No formateamos mientras el usuario escribe.
            Solo recalculamos el total.
        */
        recalcularResumenModalDevolucionVentas();

        return;
    }

    recalcularResumenModalDevolucionVentas();
}
function cambiarPasoDevolucionVentas(paso) {
    pasoDevolucionVentas =
        paso === 'METODOS'
            ? 'METODOS'
            : 'PRODUCTOS';

    const modal =
        document.getElementById('modalDevolucionVentas');

    if (!modal) {
        return;
    }

    const seccionProductos =
        modal.querySelector('#seccionProductosDevolucionVentas');

    const seccionMetodos =
        modal.querySelector('#seccionMetodosDevolucionVentas');

    const pasoProductos =
        modal.querySelector('#pasoProductosDevolucionVentas');

    const pasoMetodos =
        modal.querySelector('#pasoMetodosDevolucionVentas');

    if (seccionProductos) {
        seccionProductos.hidden =
            pasoDevolucionVentas !== 'PRODUCTOS';
    }

    if (seccionMetodos) {
        seccionMetodos.hidden =
            pasoDevolucionVentas !== 'METODOS';
    }

    if (pasoProductos) {
        pasoProductos.classList.toggle(
            'modal-devolucion-ventas__paso--activo',
            pasoDevolucionVentas === 'PRODUCTOS'
        );
    }

    if (pasoMetodos) {
        pasoMetodos.classList.toggle(
            'modal-devolucion-ventas__paso--activo',
            pasoDevolucionVentas === 'METODOS'
        );
    }

    recalcularResumenModalDevolucionVentas();

    if (pasoDevolucionVentas === 'METODOS') {
        setTimeout(() => {
            const primerMonto =
                modal.querySelector('[data-monto-metodo-devolucion="1"]');

            if (primerMonto) {
                primerMonto.focus();
                primerMonto.select();
            }
        }, 60);
    }
}

function sugerirMontoPrimerMetodoDevolucionVentas() {
    const modal =
        document.getElementById('modalDevolucionVentas');

    if (!modal) {
        return;
    }

    const totalBs =
        redondearDevolucionVentas(
            calcularTotalSeleccionadoDevolucionVentas(),
            2
        );

    const resumenMetodos =
        calcularResumenMetodosDevolucionVentas();

    if (
        totalBs <= 0 ||
        resumenMetodos.totalBs > 0
    ) {
        return;
    }

    const primeraFila =
        obtenerFilasMetodosDevolucionVentas()[0];

    if (!primeraFila) {
        return;
    }

    const metodoSelect =
        primeraFila.querySelector('[data-metodo-devolucion="1"]');

    const montoInput =
        primeraFila.querySelector('[data-monto-metodo-devolucion="1"]');

    const metodo =
        METODOS_DEVOLUCION_VENTAS[metodoSelect?.value];

    if (!metodo || !montoInput) {
        return;
    }

    montoInput.value =
        obtenerMontoSugeridoMetodoDevolucionVentas(
            metodo.moneda,
            totalBs
        );

    actualizarFilaMetodoDevolucionVentas(
        primeraFila
    );
}
function renderizarFacturaPreparadaParaDevolucion(devolucion) {
    const modal =
        asegurarModalDevolucionVentas();

    const estadoModal =
        modal.querySelector('#estadoDevolucionVentas');

    const contenido =
        modal.querySelector('#contenidoDevolucionVentas');

    devolucionVentasPreparada =
        devolucion;

    pasoDevolucionVentas =
        'PRODUCTOS';

    const venta =
        devolucion.venta;

    const resumen =
        devolucion.resumen;

    estadoModal.textContent =
        `Factura ${venta.numeroFactura} preparada para devolución.`;

    const filasProductos =
        devolucion.detalles.map((detalle) => {
            const disponible =
                numeroDevolucionVentas(
                    detalle.cantidadDisponible
                );

            const puedeDevolver =
                disponible > 0 &&
                detalle.puedeDevolver !== false;

            const cantidadEntera =
                esCantidadEnteraDevolucionVentas(detalle);

            return `
                <tr data-fila-devolucion="1"
                    data-total-bs-disponible="${escaparHTMLDevolucionVentas(detalle.totalBsDisponible)}"
                    data-cantidad-disponible="${escaparHTMLDevolucionVentas(detalle.cantidadDisponible)}"
                    data-cantidad-entera="${cantidadEntera ? '1' : '0'}"
                    data-venta-detalle-id="${escaparHTMLDevolucionVentas(detalle.ventaDetalleId)}">

                    <td>
                        <input type="checkbox"
                            data-seleccionar-devolucion="1"
                            ${puedeDevolver ? '' : 'disabled'}>
                    </td>

                    <td>
                        <strong>${escaparHTMLDevolucionVentas(detalle.nombreProducto)}</strong>
                        <span>
                            ${escaparHTMLDevolucionVentas(detalle.codigoProducto || 'Sin código')}
                            · ${escaparHTMLDevolucionVentas(detalle.unidadMedida || 'UND')}
                        </span>
                    </td>

                    <td>
                        ${escaparHTMLDevolucionVentas(
                formatearCantidadVisualDevolucionVentas(
                    detalle.cantidadVendida,
                    detalle
                )
            )}
                    </td>

                    <td>
                        ${escaparHTMLDevolucionVentas(
                formatearCantidadVisualDevolucionVentas(
                    detalle.cantidadDevuelta,
                    detalle
                )
            )}
                    </td>

                    <td>
                        ${escaparHTMLDevolucionVentas(
                formatearCantidadVisualDevolucionVentas(
                    detalle.cantidadDisponible,
                    detalle
                )
            )}
                    </td>

                    <td>
                        <input class="input-cantidad-devolucion-ventas"
                            type="text"
                            inputmode="${cantidadEntera ? 'numeric' : 'decimal'}"
                            value="${cantidadEntera ? '0' : '0.000'}"
                            data-cantidad-devolucion="1"
                            data-paso-cantidad="${obtenerPasoCantidadDevolucionVentas(detalle)}"
                            disabled>
                    </td>

                    <td>
                        Bs. ${escaparHTMLDevolucionVentas(detalle.totalBsDisponible)}
                    </td>
                </tr>
            `;
        }).join('');

    contenido.innerHTML = `
        <div class="modal-devolucion-ventas__pasos">
            <button type="button"
                id="pasoProductosDevolucionVentas"
                class="modal-devolucion-ventas__paso modal-devolucion-ventas__paso--activo">
                1. Productos
            </button>

            <button type="button"
                id="pasoMetodosDevolucionVentas"
                class="modal-devolucion-ventas__paso">
                2. Métodos de devolución
            </button>
        </div>

        <div class="modal-devolucion-ventas__factura">
            <div>
                <span>Factura</span>
                <strong>${escaparHTMLDevolucionVentas(venta.numeroFactura)}</strong>
            </div>

            <div>
                <span>Estado</span>
                <strong>${escaparHTMLDevolucionVentas(venta.estado)}</strong>
            </div>

            <div>
                <span>Cliente</span>
                <strong>${escaparHTMLDevolucionVentas(venta.clienteNombre || 'Consumidor final')}</strong>
            </div>

            <div>
                <span>Total disponible</span>
                <strong>Bs. ${escaparHTMLDevolucionVentas(resumen.totalBsDisponible)}</strong>
            </div>
        </div>

        <section id="seccionProductosDevolucionVentas">
            <div class="modal-devolucion-ventas__tabla">
                <table>
                    <thead>
                        <tr>
                            <th>Sel.</th>
                            <th>Producto</th>
                            <th>Vendido</th>
                            <th>Devuelto</th>
                            <th>Disponible</th>
                            <th>Cant.</th>
                            <th>Total disp.</th>
                        </tr>
                    </thead>

                    <tbody>
                        ${filasProductos}
                    </tbody>
                </table>
            </div>

            <div class="modal-devolucion-ventas__footer-paso">
                <strong id="totalProductosDevolucionVentas">
                    Total devolución: Bs. 0.00
                </strong>

                <button type="button"
                    id="botonContinuarMetodosDevolucionVentas"
                    disabled>
                    Continuar a métodos
                </button>
            </div>
        </section>

        <section id="seccionMetodosDevolucionVentas" hidden>
            <div class="modal-devolucion-ventas__metodos">
                <div class="modal-devolucion-ventas__metodos-cabecera">
                    <div>
                        <strong>Métodos de devolución</strong>
                        <span>
                            Divida el monto entre efectivo, divisas, pago móvil, transferencia o punto.
                        </span>
                    </div>

                    <button type="button"
                        id="botonAgregarMetodoDevolucionVentas">
                        + Agregar método
                    </button>
                </div>

                <div class="modal-devolucion-ventas__tabla-metodos">
                    <table>
                        <thead>
                            <tr>
                                <th>Método</th>
                                <th>Moneda</th>
                                <th>Monto</th>
                                <th>Referencia</th>
                                <th></th>
                            </tr>
                        </thead>

                        <tbody id="cuerpoMetodosDevolucionVentas">
                        </tbody>
                    </table>
                </div>

                <div class="modal-devolucion-ventas__resumen-metodos">
                    <strong id="totalSeleccionadoDevolucionVentas">
                        Total: Bs. 0.00
                    </strong>

                    <strong id="totalAsignadoDevolucionVentas">
                        Asignado: Bs. 0.00
                    </strong>

                    <strong id="pendienteDevolucionVentas">
                        Pendiente: Bs. 0.00
                    </strong>
                </div>
            </div>

            <div class="modal-devolucion-ventas__observacion">
                <input id="motivoDevolucionVentas"
                    type="text"
                    value="Devolución de venta"
                    placeholder="Motivo de devolución">

                <textarea id="observacionDevolucionVentas"
                    rows="2"
                    placeholder="Observación opcional"></textarea>
            </div>

            <div class="modal-devolucion-ventas__footer-paso modal-devolucion-ventas__footer-paso--metodos">
                <button type="button"
                    id="botonVolverProductosDevolucionVentas"
                    class="boton-secundario-devolucion">
                    Volver a productos
                </button>

                <div>
                    <span>
                        Autorizado por propietario
                    </span>

                    <button type="button"
                        id="botonConfirmarDevolucionVentas"
                        disabled>
                        Confirmar devolución
                    </button>
                </div>
            </div>
        </section>
    `;

    contadorMetodosDevolucionVentas = 0;

    agregarMetodoDevolucionVentas({
        metodoCodigo: 'EFECTIVO_BS',
        monto: '0.00'
    });

    cambiarPasoDevolucionVentas('PRODUCTOS');
    recalcularResumenModalDevolucionVentas();
}
function obtenerTasaDevolucionVentas() {
    return numeroDevolucionVentas(
        devolucionVentasPreparada?.venta?.tasaUsdVes
    );
}

function generarOpcionesMetodosDevolucionVentas() {
    return Object.entries(METODOS_DEVOLUCION_VENTAS)
        .map(([codigo, metodo]) => {
            return `
                <option value="${escaparHTMLDevolucionVentas(codigo)}">
                    ${escaparHTMLDevolucionVentas(metodo.nombre)}
                </option>
            `;
        })
        .join('');
}

function formatearMontoMetodoDevolucionVentas(
    monto,
    moneda
) {
    const numero =
        numeroDevolucionVentas(monto);

    if (moneda === 'USD') {
        return numero.toFixed(2);
    }

    return numero.toFixed(2);
}

function obtenerMontoSugeridoMetodoDevolucionVentas(
    moneda,
    pendienteBs
) {
    const tasa =
        obtenerTasaDevolucionVentas();

    if (moneda === 'USD') {
        if (tasa <= 0) {
            return '0.00';
        }

        return formatearMontoMetodoDevolucionVentas(
            pendienteBs / tasa,
            'USD'
        );
    }

    return formatearMontoMetodoDevolucionVentas(
        pendienteBs,
        'VES'
    );
}

function crearFilaMetodoDevolucionVentas({
    metodoCodigo = 'EFECTIVO_BS',
    monto = '',
    referencia = ''
} = {}) {
    contadorMetodosDevolucionVentas += 1;

    const id =
        contadorMetodosDevolucionVentas;

    const metodo =
        METODOS_DEVOLUCION_VENTAS[metodoCodigo] ||
        METODOS_DEVOLUCION_VENTAS.EFECTIVO_BS;

    return `
        <tr data-fila-metodo-devolucion="1">
            <td>
                <select data-metodo-devolucion="1">
                    ${generarOpcionesMetodosDevolucionVentas()}
                </select>
            </td>

            <td>
                <span data-moneda-metodo-devolucion="1">
                    ${escaparHTMLDevolucionVentas(metodo.moneda)}
                </span>
            </td>

            <td>
                <input type="number"
                    min="0"
                    step="${metodo.moneda === 'USD' ? '0.01' : '0.01'}"
                    value="${escaparHTMLDevolucionVentas(monto)}"
                    data-monto-metodo-devolucion="1"
                    placeholder="0.00">
            </td>

            <td>
                <input type="text"
                    value="${escaparHTMLDevolucionVentas(referencia)}"
                    data-referencia-metodo-devolucion="1"
                    placeholder="Referencia opcional">
            </td>

            <td>
                <button type="button"
                    class="boton-quitar-metodo-devolucion"
                    data-quitar-metodo-devolucion="1"
                    title="Quitar método">
                    ×
                </button>
            </td>
        </tr>
    `;
}

function obtenerCuerpoMetodosDevolucionVentas() {
    const modal =
        document.getElementById('modalDevolucionVentas');

    return modal
        ? modal.querySelector('#cuerpoMetodosDevolucionVentas')
        : null;
}

function obtenerFilasMetodosDevolucionVentas() {
    const cuerpo =
        obtenerCuerpoMetodosDevolucionVentas();

    if (!cuerpo) {
        return [];
    }

    return Array.from(
        cuerpo.querySelectorAll('[data-fila-metodo-devolucion="1"]')
    );
}

function agregarMetodoDevolucionVentas({
    metodoCodigo = 'EFECTIVO_BS',
    monto = ''
} = {}) {
    const cuerpo =
        obtenerCuerpoMetodosDevolucionVentas();

    if (!cuerpo) {
        return;
    }

    const totalSeleccionadoBs =
        redondearDevolucionVentas(
            calcularTotalSeleccionadoDevolucionVentas(),
            2
        );

    const resumenActual =
        calcularResumenMetodosDevolucionVentas();

    const pendienteBs =
        Math.max(
            0,
            totalSeleccionadoBs - resumenActual.totalBs
        );

    const metodo =
        METODOS_DEVOLUCION_VENTAS[metodoCodigo] ||
        METODOS_DEVOLUCION_VENTAS.EFECTIVO_BS;

    const montoFinal =
        monto !== ''
            ? monto
            : obtenerMontoSugeridoMetodoDevolucionVentas(
                metodo.moneda,
                pendienteBs
            );

    cuerpo.insertAdjacentHTML(
        'beforeend',
        crearFilaMetodoDevolucionVentas({
            metodoCodigo,
            monto: montoFinal
        })
    );

    const fila =
        cuerpo.lastElementChild;

    const select =
        fila.querySelector('[data-metodo-devolucion="1"]');

    if (select) {
        select.value = metodoCodigo;
    }

    actualizarFilaMetodoDevolucionVentas(fila);
    recalcularResumenModalDevolucionVentas();
}

function actualizarFilaMetodoDevolucionVentas(fila) {
    if (!fila) {
        return;
    }

    const select =
        fila.querySelector('[data-metodo-devolucion="1"]');

    const monedaTexto =
        fila.querySelector('[data-moneda-metodo-devolucion="1"]');

    const montoInput =
        fila.querySelector('[data-monto-metodo-devolucion="1"]');

    const referenciaInput =
        fila.querySelector('[data-referencia-metodo-devolucion="1"]');

    const metodo =
        METODOS_DEVOLUCION_VENTAS[select?.value];

    if (!metodo) {
        return;
    }

    if (monedaTexto) {
        monedaTexto.textContent = metodo.moneda;
    }

    if (montoInput) {
        montoInput.step =
            metodo.moneda === 'USD'
                ? '0.01'
                : '0.01';
    }

    if (referenciaInput) {
        referenciaInput.placeholder =
            metodo.requiereReferencia
                ? 'Referencia requerida'
                : 'Referencia opcional';
    }
}

function calcularResumenMetodosDevolucionVentas() {
    const tasa =
        obtenerTasaDevolucionVentas();

    const filas =
        obtenerFilasMetodosDevolucionVentas();

    const pagos = [];
    let totalBs = 0;
    let totalUsd = 0;

    for (const fila of filas) {
        const metodoSelect =
            fila.querySelector('[data-metodo-devolucion="1"]');

        const montoInput =
            fila.querySelector('[data-monto-metodo-devolucion="1"]');

        const referenciaInput =
            fila.querySelector('[data-referencia-metodo-devolucion="1"]');

        const metodo =
            METODOS_DEVOLUCION_VENTAS[metodoSelect?.value];

        if (!metodo) {
            continue;
        }

        const montoOriginal =
            numeroDevolucionVentas(montoInput?.value);

        if (montoOriginal <= 0) {
            continue;
        }

        const montoBsEquivalente =
            metodo.moneda === 'USD'
                ? redondearDevolucionVentas(montoOriginal * tasa, 2)
                : redondearDevolucionVentas(montoOriginal, 2);

        const montoUsdEquivalente =
            metodo.moneda === 'USD'
                ? redondearDevolucionVentas(montoOriginal, 6)
                : tasa > 0
                    ? redondearDevolucionVentas(montoOriginal / tasa, 6)
                    : 0;

        totalBs += montoBsEquivalente;
        totalUsd += montoUsdEquivalente;

        pagos.push({
            metodoCodigo:
                metodo.codigo,

            metodoNombre:
                metodo.nombre,

            moneda:
                metodo.moneda,

            montoOriginal:
                redondearDevolucionVentas(
                    montoOriginal,
                    metodo.moneda === 'USD'
                        ? 6
                        : 2
                ),

            referencia:
                referenciaInput?.value?.trim() || null
        });
    }

    return {
        pagos,

        totalBs:
            redondearDevolucionVentas(totalBs, 2),

        totalUsd:
            redondearDevolucionVentas(totalUsd, 6)
    };
}

function obtenerPagosDevolucionVentas() {
    return calcularResumenMetodosDevolucionVentas()
        .pagos;
}
async function imprimirComprobanteDevolucionAutomaticamente(
    devolucion
) {
    const devolucionId =
        Number(devolucion?.id);

    if (
        !Number.isInteger(devolucionId) ||
        devolucionId < 1
    ) {
        return;
    }

    try {
        await solicitarJSONVentas(
            `/api/impresion/devolucion/${devolucionId}`,
            {
                method: 'POST',

                headers: {
                    'Content-Type': 'application/json'
                },

                body: JSON.stringify({
                    tipoCopia: 'DEVOLUCION'
                })
            }
        );
    } catch (error) {
        console.error(
            'La devolución fue registrada, pero no se pudo imprimir:',
            error
        );

        mostrarMensaje(
            'La devolución fue registrada, pero no se pudo imprimir el comprobante.'
        );
    }
}
async function confirmarDevolucionDesdeModalVentas() {
    if (!devolucionVentasPreparada) {
        mostrarMensaje(
            'Primero busque una factura para devolución.'
        );

        return;
    }

    if (devolucionVentasConfirmando) {
        return;
    }

    const clave =
        estado.claveTemporalDevolucionVentas;

    if (!clave) {
        const requiere = await requiereClaveAutorizacionVentas().catch(
            () => true
        );

        if (requiere) {
            mostrarMensaje(
                'Debe autorizar la devolución con la clave del propietario.'
            );

            cerrarModalDevolucionVentas();
            abrirDevolucionVentasConAutorizacion();

            return;
        }

        // Autorización deshabilitada: continuar sin clave.
    }

    const modal =
        asegurarModalDevolucionVentas();

    const estadoModal =
        modal.querySelector('#estadoDevolucionVentas');

    const motivoInput =
        modal.querySelector('#motivoDevolucionVentas');

    const observacionInput =
        modal.querySelector('#observacionDevolucionVentas');

    const botonConfirmar =
        modal.querySelector('#botonConfirmarDevolucionVentas');

    const lineas =
        obtenerLineasSeleccionadasDevolucionVentas();

    const totalBs =
        redondearDevolucionVentas(
            calcularTotalSeleccionadoDevolucionVentas(),
            2
        );

    const resumenMetodos =
        calcularResumenMetodosDevolucionVentas();

    const diferencia =
        redondearDevolucionVentas(
            resumenMetodos.totalBs - totalBs,
            2
        );

    if (lineas.length === 0 || totalBs <= 0) {
        mostrarMensaje(
            'Seleccione al menos un producto y una cantidad a devolver.'
        );

        return;
    }

    if (resumenMetodos.pagos.length === 0) {
        mostrarMensaje(
            'Agregue al menos un método de devolución.'
        );

        return;
    }

    if (Math.abs(diferencia) > 0.01) {
        mostrarMensaje(
            `El total de métodos no coincide. Diferencia: Bs. ${diferencia.toFixed(2)}.`
        );

        return;
    }

    try {
        devolucionVentasConfirmando = true;

        if (botonConfirmar) {
            botonConfirmar.disabled = true;
            botonConfirmar.textContent = 'Confirmando...';
        }

        estadoModal.textContent =
            'Registrando devolución...';

        const respuesta =
            await solicitarJSONVentas(
                '/api/devoluciones/confirmar',
                {
                    method: 'POST',

                    headers: {
                        'Content-Type': 'application/json'
                    },

                    body: JSON.stringify({
                        clave,

                        numeroFactura:
                            devolucionVentasPreparada.venta.numeroFactura,

                        motivo:
                            motivoInput.value.trim() ||
                            'Devolución de venta',

                        observacion:
                            observacionInput.value.trim() ||
                            null,

                        lineas,

                        pagos:
                            resumenMetodos.pagos
                    })
                }
            );

        estadoModal.textContent =
            `${respuesta.devolucion.numeroDevolucion} registrada correctamente. Imprimiendo comprobante...`;

        await imprimirComprobanteDevolucionAutomaticamente(
            respuesta.devolucion
        );

        mostrarMensaje(
            `${respuesta.devolucion.numeroDevolucion} registrada e impresa correctamente.`
        );

        cerrarModalDevolucionVentas();

        enfocarCodigoProducto();
    } catch (error) {
        console.error(
            'Error confirmando devolución:',
            error
        );

        estadoModal.textContent =
            error.message ||
            'No fue posible registrar la devolución.';

        mostrarMensaje(
            error.message ||
            'No fue posible registrar la devolución.'
        );
    } finally {
        devolucionVentasConfirmando = false;

        const boton =
            modal.querySelector('#botonConfirmarDevolucionVentas');

        if (boton) {
            boton.textContent =
                'Confirmar devolución';
        }

        recalcularResumenModalDevolucionVentas();
    }
}
async function buscarFacturaParaDevolucionDesdeModal() {
    const modal =
        asegurarModalDevolucionVentas();

    const inputFactura =
        modal.querySelector('#inputFacturaDevolucionVentas');

    const estadoModal =
        modal.querySelector('#estadoDevolucionVentas');

    const contenido =
        modal.querySelector('#contenidoDevolucionVentas');

    const numeroFactura =
        inputFactura.value.trim();

    if (!numeroFactura) {
        estadoModal.textContent =
            'Ingrese un número de factura.';

        inputFactura.focus();

        return;
    }

    try {
        estadoModal.textContent =
            'Buscando factura para devolución...';

        contenido.innerHTML = '';

        const respuesta =
            await solicitarJSONVentas(
                `/api/devoluciones/factura/${encodeURIComponent(numeroFactura)}/preparar`
            );

        if (!respuesta.ok) {
            throw new Error(
                respuesta.mensaje ||
                'No fue posible preparar la devolución.'
            );
        }

        renderizarFacturaPreparadaParaDevolucion(
            respuesta.devolucion
        );
    } catch (error) {
        console.error(
            'Error buscando factura para devolución:',
            error
        );

        estadoModal.textContent =
            error.message ||
            'No fue posible preparar la devolución.';

        contenido.innerHTML = '';
    }
}
/* =========================================================
   EVENTOS
   ========================================================= */

function esAtajoOperacionVentas(evento, letra) {
    if (!evento.altKey || evento.ctrlKey || evento.shiftKey || evento.metaKey) {
        return false;
    }

    const tecla = String(evento.key || '').toLowerCase();
    const codigo = String(evento.code || '');

    return (
        tecla === letra.toLowerCase() ||
        codigo === `Key${letra.toUpperCase()}`
    );
}

function configurarEventos() {
    elementos.botonCerrarSesionVentas.addEventListener(
        'click',
        cerrarSesionVentas
    );

    elementos.botonMarcaVentas.addEventListener(
        'click',
        () => {
            const rol =
                estado.contexto?.usuario?.rol;

            if (rol === 'PROPIETARIO') {
                window.location.assign('/panel');

                return;
            }

            mostrarMensaje(
                'El Punto de Venta es el área operativa del Cajero.'
            );
        }
    );
    elementos.botonIrPanelVentas.addEventListener(
        'click',
        () => {
            window.location.assign('/panel');
        }
    );
    elementos.botonCobrarVentas.addEventListener(
        'click',
        abrirModalCobroVentas
    );
    elementos.documentoClienteVentas.addEventListener(
        'keydown',
        (evento) => {
            if (evento.key !== 'Enter') {
                return;
            }

            evento.preventDefault();

            buscarClientePorDocumento();
        }
    );
    elementos.documentoClienteVentas.addEventListener(
        'input',
        () => {
            estado.clienteSeleccionado = null;

            const documento =
                normalizarDocumentoCliente(
                    elementos.documentoClienteVentas.value
                );

            if (
                documento === '' ||
                esDocumentoConsumidorFinal(documento)
            ) {
                mostrarConsumidorFinal();
            } else {
                elementos.estadoClienteVentas.textContent =
                    'Pendiente de búsqueda';

                elementos.estadoClienteVentas.className =
                    'estado-cliente-ventas';

                elementos.detalleClienteVentas.textContent =
                    'Presione Enter para buscar el cliente.';
            }

            actualizarControlesSegunCaja();
        }
    );

    elementos.documentoClienteVentas.addEventListener(
        'blur',
        () => {
            const documento =
                normalizarDocumentoCliente(
                    elementos.documentoClienteVentas.value
                );

            elementos.documentoClienteVentas.value =
                documento || DOCUMENTO_CONSUMIDOR_FINAL;

            if (
                elementos.documentoClienteVentas.value ===
                DOCUMENTO_CONSUMIDOR_FINAL
            ) {
                mostrarConsumidorFinal();
            }

            actualizarControlesSegunCaja();
        }
    );

    elementos.botonLimpiarClienteVentas.addEventListener(
        'click',
        limpiarClienteSeleccionado
    );
    elementos.botonEditarClienteVentas.addEventListener(
        'click',
        editarClienteSeleccionado
    );
    elementos.codigoProductoVentas.addEventListener(
        'keydown',
        (evento) => {
            if (evento.key !== 'Enter') {
                return;
            }

            evento.preventDefault();

            buscarProductoPorCodigoVenta();
        }
    );

    elementos.cantidadProductoVentas.addEventListener(
        'keydown',
        (evento) => {
            if (evento.key !== 'Enter') {
                return;
            }

            evento.preventDefault();

            agregarProductoSeleccionadoAlCarrito();
        }
    );

    elementos.botonAgregarProductoVentas.addEventListener(
        'click',
        agregarProductoSeleccionadoAlCarrito
    );
    elementos.botonVaciarCarritoVentas.addEventListener(
        'click',
        vaciarCarritoVentas
    );
    elementos.botonBuscarProductoVentas.addEventListener(
        'click',
        () => {
            if (estado.productoEditandoCarritoId !== null) {
                cancelarEdicionProductoCarrito({
                    mostrarAviso: true
                });

                limpiarProductoSeleccionado({
                    enfocar: false
                });
            }

            abrirModalBuscarProducto({
                termino:
                    limpiarTexto(
                        elementos.codigoProductoVentas.value
                    )
            });
        }
    );

    elementos.botonLimpiarProductoSeleccionadoVentas.addEventListener(
        'click',
        () => {
            limpiarProductoSeleccionado({
                enfocar: true
            });
        }
    );

    elementos.botonCerrarBuscarProductoVentas.addEventListener(
        'click',
        cerrarModalBuscarProducto
    );

    elementos.botonCancelarBuscarProductoVentas.addEventListener(
        'click',
        cerrarModalBuscarProducto
    );

    elementos.modalBuscarProductoVentas.addEventListener(
        'click',
        (evento) => {
            const debeCerrar =
                evento.target.dataset.cerrarModal ===
                'buscar-producto';

            if (debeCerrar) {
                cerrarModalBuscarProducto();
            }
        }
    );

    elementos.busquedaProductoVentas.addEventListener(
        'input',
        () => {
            window.clearTimeout(
                estado.temporizadorBusquedaProducto
            );

            estado.temporizadorBusquedaProducto =
                window.setTimeout(() => {
                    ejecutarBusquedaModalProducto();
                }, 280);
        }
    );

    elementos.busquedaProductoVentas.addEventListener(
        'keydown',
        (evento) => {
            if (evento.key !== 'Enter') {
                return;
            }

            evento.preventDefault();

            ejecutarBusquedaModalProducto();
        }
    );

    elementos.resultadosBusquedaProductoVentas.addEventListener(
        'click',
        (evento) => {
            const boton =
                evento.target.closest(
                    '[data-producto-id]'
                );

            if (!boton) {
                return;
            }

            const productoId =
                Number(boton.dataset.productoId);

            const producto =
                estado.resultadosBusquedaProductos.find(
                    (item) => Number(item.id) === productoId
                );

            if (!producto) {
                return;
            }

            const codigoSeleccionado =
                limpiarTexto(
                    elementos.busquedaProductoVentas.value
                ) || null;

            seleccionarProductoVenta(
                producto,
                codigoSeleccionado
            );
            cerrarModalBuscarProducto();
        }
    );

    elementos.cuerpoTablaVentas.addEventListener(
        'click',
        (evento) => {
            const botonEditar =
                evento.target.closest(
                    '[data-editar-producto-id]'
                );

            if (botonEditar) {
                iniciarEdicionProductoCarrito(
                    botonEditar.dataset.editarProductoId
                );

                return;
            }

            const botonQuitar =
                evento.target.closest(
                    '[data-quitar-producto-id]'
                );

            if (!botonQuitar) {
                return;
            }

            quitarProductoCarrito(
                botonQuitar.dataset.quitarProductoId
            );
        }
    );
    elementos.tipoPersonaClienteRapidoVentas.addEventListener(
        'change',
        actualizarEtiquetaNombreClienteRapido
    );

    elementos.formularioRegistroRapidoClienteVentas.addEventListener(
        'submit',
        guardarClienteRapido
    );

    elementos.botonCerrarRegistroRapidoClienteVentas.addEventListener(
        'click',
        () => {
            cerrarModalRegistroRapidoCliente();
        }
    );

    elementos.botonCancelarRegistroRapidoClienteVentas.addEventListener(
        'click',
        () => {
            cerrarModalRegistroRapidoCliente();
        }
    );

    elementos.botonConsumidorFinalRegistroVentas.addEventListener(
        'click',
        continuarComoConsumidorFinal
    );

    elementos.modalRegistroRapidoClienteVentas.addEventListener(
        'click',
        (evento) => {
            const debeCerrar =
                evento.target.dataset.cerrarModal ===
                'registro-cliente';

            if (debeCerrar) {
                cerrarModalRegistroRapidoCliente();
            }
        }
    );
    elementos.botonCerrarCobroVentas.addEventListener(
        'click',
        cerrarModalCobroVentas
    );

    elementos.botonCancelarCobroVentas.addEventListener(
        'click',
        cerrarModalCobroVentas
    );

    elementos.botonConfirmarCobroVentas.addEventListener(
        'click',
        prepararConfirmarVentaDesdeModal
    );
    elementos.formularioAutorizarOperacionVentas.addEventListener(
        'submit',
        procesarAutorizacionOperacionVentas
    );

    elementos.botonCerrarConfirmacionVentas.addEventListener(
        'click',
        cerrarModalConfirmacionVentas
    );

    elementos.botonCancelarConfirmacionVentas.addEventListener(
        'click',
        cerrarModalConfirmacionVentas
    );

    elementos.fondoConfirmacionVentas.addEventListener(
        'click',
        cerrarModalConfirmacionVentas
    );

    elementos.formularioConfirmacionVentas.addEventListener(
        'submit',
        procesarConfirmacionVentas
    );

    elementos.botonCerrarAutorizarOperacionVentas.addEventListener(
        'click',
        cerrarModalAutorizacionVentas
    );

    elementos.botonCancelarAutorizarOperacionVentas.addEventListener(
        'click',
        cerrarModalAutorizacionVentas
    );

    elementos.fondoAutorizarOperacionVentas.addEventListener(
        'click',
        cerrarModalAutorizacionVentas
    );

    elementos.botonCerrarZelleVentas.addEventListener(
        'click',
        cerrarModalZelleVentas
    );

    elementos.botonCancelarZelleVentas.addEventListener(
        'click',
        cerrarModalZelleVentas
    );

    elementos.formularioZelleVentas.addEventListener(
        'submit',
        (evento) => {
            evento.preventDefault();
            const filaPago = obtenerFilaPagoVentasPorNumero(estado.zelleAutorizacionFilaNumero);
            if (!filaPago) {
                return;
            }

            const monto = elementos.zelleMontoVentas.value.trim();
            const remitente = elementos.zelleRemitenteVentas.value.trim();
            const referencia = elementos.zelleReferenciaVentas.value.trim();

            if (!validarMontoZelle(monto)) {
                elementos.zelleMensajeVentas.textContent =
                    'Ingrese un monto Zelle válido mayor a 0.';
                elementos.zelleMontoVentas.focus();
                return;
            }
            if (!remitente) {
                elementos.zelleMensajeVentas.textContent =
                    'Ingrese el nombre del remitente.';
                elementos.zelleRemitenteVentas.focus();
                return;
            }
            if (!referencia) {
                elementos.zelleMensajeVentas.textContent =
                    'Ingrese la referencia de Zelle.';
                elementos.zelleReferenciaVentas.focus();
                return;
            }

            guardarZelleDetalleFila(filaPago.numero, {
                remitente,
                referencia
            });
            filaPago.monto.value = monto;
            actualizarZelleFilaPago(filaPago);
            filaPago.monto.disabled = false;
            filaPago.referencia.disabled = false;
            actualizarFilasPagoVentas();
            actualizarModalCobroVentas();
            cerrarModalZelleVentas();
        }
    );

    elementos.modalCobroVentas.addEventListener('input', (evento) => {
        if (evento.target.matches('.metodo-pago-ventas-input')) {
            const numero = evento.target.id.replace('metodoPagoVentas', '');
            const filaPago = obtenerFilasPagoVentas().find(f => f.numero == numero);
            if (filaPago) actualizarFilaPagoDesdeCodigo(filaPago);
        }
    });
    elementos.botonCerrarHistorialVentas.addEventListener(
        'click',
        cerrarModalHistorialVentas
    );

    elementos.botonCancelarHistorialVentas.addEventListener(
        'click',
        cerrarModalHistorialVentas
    );

    elementos.fondoHistorialVentas.addEventListener(
        'click',
        cerrarModalHistorialVentas
    );

    elementos.botonActualizarHistorialVentas.addEventListener(
        'click',
        actualizarHistorialVentasAutorizado
    );

    elementos.botonBuscarFacturaHistorialVentas.addEventListener(
        'click',
        buscarFacturaHistorialVentas
    );

    elementos.busquedaHistorialVentas.addEventListener(
        'keydown',
        (evento) => {
            if (evento.key !== 'Enter') {
                return;
            }

            evento.preventDefault();

            buscarFacturaHistorialVentas();
        }
    );
    elementos.detalleHistorialVentas.addEventListener(
        'click',
        (evento) => {
            const boton = evento.target.closest(
                '[data-accion-historial]'
            );

            if (!boton) {
                return;
            }

            const accion = boton.dataset.accionHistorial;

            if (accion === 'reimprimir') {
                reimprimirFacturaSeleccionadaConAutorizacion();
            }
        }
    );
    obtenerFilasPagoVentas().forEach((filaPago) => {
        filaPago.metodo.addEventListener(
            'change',
            actualizarFilasPagoVentas
        );

        filaPago.metodo.addEventListener(
            'blur',
            () => {
                actualizarFilaPagoDesdeCodigo(filaPago);
            }
        );

        filaPago.monto.addEventListener(
            'input',
            () => {
                actualizarModalCobroVentas();
            }
        );

        const procesarEnterMonto = (evento) => {
            if (evento.key !== 'Enter') {
                return;
            }

            evento.preventDefault();
            procesarEnterPagoVenta(evento.target, filaPago, evento);
        };

        filaPago.monto.addEventListener(
            'keydown',
            procesarEnterMonto
        );

        filaPago.monto.addEventListener(
            'keypress',
            procesarEnterMonto
        );

        filaPago.monto.addEventListener(
            'keyup',
            procesarEnterMonto
        );

        filaPago.monto.addEventListener(
            'blur',
            (evento) => {
                formatearMontoPagoInput(evento.target);
                actualizarFilasPagoVentas();
            }
        );

        const procesarEnterReferencia = (evento) => {
            if (evento.key !== 'Enter') {
                return;
            }

            evento.preventDefault();
            procesarEnterPagoVenta(evento.target, filaPago, evento);
        };

        filaPago.referencia.addEventListener(
            'keydown',
            procesarEnterReferencia
        );

        filaPago.referencia.addEventListener(
            'keypress',
            procesarEnterReferencia
        );

        filaPago.referencia.addEventListener(
            'keyup',
            procesarEnterReferencia
        );

        filaPago.referencia.addEventListener(
            'input',
            actualizarModalCobroVentas
        );
    });
    window.addEventListener(
        'keydown',
        (evento) => {
            if (evento.repeat) {
                return;
            }

            if (esAtajoOperacionVentas(evento, 'd')) {
                evento.preventDefault();
                evento.stopPropagation();
                evento.stopImmediatePropagation();

                if (!elementos.modalAutorizarOperacionVentas.hidden) {
                    return;
                }

                const modalDevolucion =
                    document.getElementById('modalDevolucionVentas');

                if (
                    modalDevolucion &&
                    !modalDevolucion.classList.contains('oculto')
                ) {
                    return;
                }

                abrirDevolucionVentasConAutorizacion();

                return;
            }
            if (esAtajoOperacionVentas(evento, 'h')) {
                evento.preventDefault();
                evento.stopPropagation();
                evento.stopImmediatePropagation();

                if (!elementos.modalAutorizarOperacionVentas.hidden) {
                    return;
                }

                if (!elementos.modalHistorialVentas.hidden) {
                    return;
                }

                abrirHistorialVentasConAutorizacion();

                return;
            }
            if (evento.key === 'F2') {
                evento.preventDefault();

                if (estado.productoEditandoCarritoId !== null) {
                    cancelarEdicionProductoCarrito({
                        mostrarAviso: true
                    });

                    limpiarProductoSeleccionado({
                        enfocar: false
                    });
                }

                abrirModalBuscarProducto({
                    termino:
                        limpiarTexto(
                            elementos.codigoProductoVentas.value
                        )
                });

                return;
            }
            if (
                evento.key === 'F3' &&
                !estado.modalClienteRapidoAbierto &&
                !estado.modalBuscarProductoAbierto
            ) {
                evento.preventDefault();

                editarClienteSeleccionado();

                return;
            }
            if (evento.key === 'F8') {
                evento.preventDefault();

                if (estado.carrito.length === 0) {
                    mostrarMensaje(
                        'El carrito ya está vacío.'
                    );

                    return;
                }

                vaciarCarritoVentas();

                return;
            }
            if (evento.key === 'F10') {
                evento.preventDefault();

                abrirModalCobroVentas();

                return;
            }

            if (evento.key === 'Escape') {
                if (!elementos.modalAutorizarOperacionVentas.hidden) {
                    cerrarModalAutorizacionVentas();

                    return;
                }

                if (!elementos.modalHistorialVentas.hidden) {
                    cerrarModalHistorialVentas();

                    return;
                }
                if (!elementos.modalCobroVentas.hidden) {
                    cerrarModalCobroVentas();

                    return;
                }
                if (!elementos.modalConfirmacionVentas.hidden) {
                    cerrarModalConfirmacionVentas();

                    return;
                }
                if (estado.modalBuscarProductoAbierto) {
                    cerrarModalBuscarProducto();

                    return;
                }

                if (estado.modalClienteRapidoAbierto) {
                    cerrarModalRegistroRapidoCliente();

                    return;
                }

                if (
                    estado.productoSeleccionado ||
                    estado.productoEditandoCarritoId !== null
                ) {
                    limpiarProductoSeleccionado({
                        enfocar: true
                    });
                }
            }
        }
    );
}

/* =========================================================
   INICIO
   ========================================================= */

document.addEventListener(
    'DOMContentLoaded',
    () => {
        configurarEventos();

        renderizarCarritoVentas();

        limpiarProductoSeleccionado({
            enfocar: false
        });

        cargarContextoOperacionVentas();
    }
);