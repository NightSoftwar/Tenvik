'use strict';

/*
    Ajusta la columna codigo_interno en productos para permitir
    valores nulos, de modo que los productos con codigo de barras
    puedan no requerir un codigo interno.
*/
async function up(db) {
    await db.query(`
        ALTER TABLE productos
        MODIFY COLUMN codigo_interno VARCHAR(60) NULL
    `);
}

module.exports = {
    up
};
