'use strict';

const crypto = require('node:crypto');

const { db } = require('../../config/database');

const ESTADOS_PRODUCTO = Object.freeze({
    ACTIVO: 'ACTIVO',
    INACTIVO: 'INACTIVO'
});
const TIPOS_VENTA = Object.freeze({
    UNIDAD: 'UNIDAD',
    FRACCIONABLE: 'FRACCIONABLE'
});

const UNIDADES_MEDIDA = Object.freeze({
    UND: 'UND',
    KG: 'KG'
});
const TIPOS_MOVIMIENTO_INVENTARIO = Object.freeze({
    INICIAL: 'INICIAL',
    ENTRADA: 'ENTRADA',
    SALIDA: 'SALIDA',
    AJUSTE_POSITIVO: 'AJUSTE_POSITIVO',
    AJUSTE_NEGATIVO: 'AJUSTE_NEGATIVO'
});

const MODOS_AJUSTE_INVENTARIO = Object.freeze({
    ENTRADA: 'ENTRADA',
    SALIDA: 'SALIDA',
    RECONTEO: 'RECONTEO'
});
class ErrorInventario extends Error {
    constructor(
        mensaje,
        codigo = 'INVENTARIO_INVALIDO'
    ) {
        super(mensaje);

        this.name = 'ErrorInventario';
        this.codigo = codigo;
    }
}

/* =========================================================
   UTILIDADES GENERALES
   ========================================================= */

function textoSeguro(valor) {
    return String(valor ?? '').trim();
}

function validarIdProducto(valor) {
    const id = Number(valor);

    if (
        !Number.isInteger(id) ||
        id < 1
    ) {
        throw new ErrorInventario(
            'El producto indicado no es válido.',
            'PRODUCTO_ID_INVALIDO'
        );
    }

    return id;
}

function validarIdUsuario(valor) {
    const id = Number(valor);

    if (
        !Number.isInteger(id) ||
        id < 1
    ) {
        throw new ErrorInventario(
            'El usuario responsable no es válido.',
            'USUARIO_RESPONSABLE_INVALIDO'
        );
    }

    return id;
}

function validarNombreProducto(valor) {
    const nombre = textoSeguro(valor);

    if (
        nombre.length < 2 ||
        nombre.length > 180
    ) {
        throw new ErrorInventario(
            'El nombre del producto debe tener entre 2 y 180 caracteres.',
            'NOMBRE_PRODUCTO_INVALIDO'
        );
    }

    return nombre;
}

function normalizarCodigoInterno(valor) {
    const codigo = textoSeguro(valor)
        .toUpperCase();

    if (!codigo) {
        return null;
    }

    if (
        codigo.length < 1 ||
        codigo.length > 60
    ) {
        throw new ErrorInventario(
            'El código interno debe tener entre 1 y 60 caracteres.',
            'CODIGO_INTERNO_INVALIDO'
        );
    }

    if (
        !/^[A-Z0-9._-]+$/.test(codigo)
    ) {
        throw new ErrorInventario(
            'El código interno solo puede usar letras, números, punto, guion o guion bajo.',
            'CODIGO_INTERNO_INVALIDO'
        );
    }

    return codigo;
}

function generarCodigoInternoAutomatico() {
    const parteUnica = crypto
        .randomUUID()
        .replace(/-/g, '')
        .slice(0, 12)
        .toUpperCase();

    return `PRD-${parteUnica}`;
}

function normalizarCodigoBarras(valor) {
    const codigo = textoSeguro(valor)
        .toUpperCase();

    if (!codigo) {
        return null;
    }

    if (codigo.length > 80) {
        throw new ErrorInventario(
            'El código de barras no puede superar 80 caracteres.',
            'CODIGO_BARRAS_INVALIDO'
        );
    }

    return codigo;
}

function normalizarMontoPositivo(
    valor,
    etiqueta = 'El monto'
) {
    const texto = textoSeguro(valor)
        .replace(/\s+/g, '')
        .replace(',', '.');

    if (
        !/^(?:0|[1-9]\d{0,11})(?:\.\d{1,6})?$/
            .test(texto)
    ) {
        throw new ErrorInventario(
            `${etiqueta} debe ser un número válido con hasta 6 decimales.`,
            'MONTO_INVALIDO'
        );
    }

    const numero = Number(texto);

    if (
        !Number.isFinite(numero) ||
        numero <= 0
    ) {
        throw new ErrorInventario(
            `${etiqueta} debe ser mayor que cero.`,
            'MONTO_INVALIDO'
        );
    }

    return texto;
}

function normalizarCantidadNoNegativa(
    valor,
    etiqueta = 'La cantidad'
) {
    const textoOriginal = textoSeguro(valor);

    if (!textoOriginal) {
        return '0.000';
    }

    const texto = textoOriginal
        .replace(/\s+/g, '')
        .replace(',', '.');

    if (
        !/^(?:0|[1-9]\d{0,14})(?:\.\d{1,3})?$/
            .test(texto)
    ) {
        throw new ErrorInventario(
            `${etiqueta} debe ser un número válido con hasta 3 decimales.`,
            'CANTIDAD_INVALIDA'
        );
    }

    const numero = Number(texto);

    if (
        !Number.isFinite(numero) ||
        numero < 0
    ) {
        throw new ErrorInventario(
            `${etiqueta} no puede ser negativa.`,
            'CANTIDAD_INVALIDA'
        );
    }

    return texto;
}
function normalizarCantidadPositiva(
    valor,
    etiqueta = 'La cantidad'
) {
    const cantidad = normalizarCantidadNoNegativa(
        valor,
        etiqueta
    );

    if (Number(cantidad) <= 0) {
        throw new ErrorInventario(
            `${etiqueta} debe ser mayor que cero.`,
            'CANTIDAD_INVALIDA'
        );
    }

    return cantidad;
}

function normalizarModoAjusteInventario(valor) {
    const modo = textoSeguro(valor)
        .toUpperCase();

    if (
        modo !== MODOS_AJUSTE_INVENTARIO.ENTRADA &&
        modo !== MODOS_AJUSTE_INVENTARIO.SALIDA &&
        modo !== MODOS_AJUSTE_INVENTARIO.RECONTEO
    ) {
        throw new ErrorInventario(
            'La operación de inventario no es válida.',
            'MODO_AJUSTE_INVALIDO'
        );
    }

    return modo;
}

function normalizarNotaMovimiento(valor) {
    const nota = textoSeguro(valor);

    if (nota.length > 250) {
        throw new ErrorInventario(
            'La nota del movimiento no puede superar 250 caracteres.',
            'NOTA_MOVIMIENTO_INVALIDA'
        );
    }

    return nota || null;
}

function normalizarTipoVenta(
    valor,
    valorPorDefecto = null
) {
    const tipoVenta = textoSeguro(valor)
        .toUpperCase();

    if (!tipoVenta && valorPorDefecto) {
        return valorPorDefecto;
    }

    if (
        tipoVenta !== TIPOS_VENTA.UNIDAD &&
        tipoVenta !== TIPOS_VENTA.FRACCIONABLE
    ) {
        throw new ErrorInventario(
            'La forma de venta del producto no es válida.',
            'TIPO_VENTA_INVALIDO'
        );
    }

    return tipoVenta;
}

function obtenerUnidadMedidaSegunTipoVenta(
    tipoVenta
) {
    const tipoSeguro = normalizarTipoVenta(
        tipoVenta
    );

    return tipoSeguro === TIPOS_VENTA.FRACCIONABLE
        ? UNIDADES_MEDIDA.KG
        : UNIDADES_MEDIDA.UND;
}

function normalizarCantidadSegunTipoVenta(
    valor,
    tipoVenta,
    etiqueta = 'La cantidad',
    permiteCero = true
) {
    const tipoSeguro = normalizarTipoVenta(
        tipoVenta
    );

    const cantidad = normalizarCantidadNoNegativa(
        valor,
        etiqueta
    );

    /*
        Los productos por unidad solo aceptan enteros.
        Ejemplos válidos: 0, 1, 20, 300.
        Ejemplos no válidos: 0.500, 1.250.
    */
    if (
        tipoSeguro === TIPOS_VENTA.UNIDAD &&
        !/^(?:0|[1-9]\d{0,14})$/.test(cantidad)
    ) {
        throw new ErrorInventario(
            `${etiqueta} debe ser un número entero porque el producto se vende por unidad.`,
            'CANTIDAD_UNIDAD_INVALIDA'
        );
    }

    if (
        !permiteCero &&
        Number(cantidad) <= 0
    ) {
        throw new ErrorInventario(
            `${etiqueta} debe ser mayor que cero.`,
            'CANTIDAD_INVALIDA'
        );
    }

    return cantidad;
}

function validarDatosAjusteExistencia(
    datos,
    tipoVenta
) {
    const modo = normalizarModoAjusteInventario(
        datos.modo
    );

    const cantidad = normalizarCantidadSegunTipoVenta(
        datos.cantidad,
        tipoVenta,
        modo === MODOS_AJUSTE_INVENTARIO.RECONTEO
            ? 'La existencia real'
            : 'La cantidad del movimiento',
        modo === MODOS_AJUSTE_INVENTARIO.RECONTEO
    );

    const nota = normalizarNotaMovimiento(
        datos.nota
    );

    return {
        modo,
        cantidad,
        nota
    };
}
function normalizarBooleano(
    valor,
    etiqueta,
    valorPorDefecto = null
) {
    if (
        valor === undefined ||
        valor === null ||
        valor === ''
    ) {
        if (valorPorDefecto !== null) {
            return valorPorDefecto;
        }

        throw new ErrorInventario(
            `${etiqueta} no es válido.`,
            'VALOR_BOOLEANO_INVALIDO'
        );
    }

    if (
        valor === true ||
        valor === 1 ||
        valor === '1' ||
        valor === 'true'
    ) {
        return true;
    }

    if (
        valor === false ||
        valor === 0 ||
        valor === '0' ||
        valor === 'false'
    ) {
        return false;
    }

    throw new ErrorInventario(
        `${etiqueta} no es válido.`,
        'VALOR_BOOLEANO_INVALIDO'
    );
}

function normalizarEstadoProducto(valor) {
    const estado = textoSeguro(valor)
        .toUpperCase();

    if (
        estado !== ESTADOS_PRODUCTO.ACTIVO &&
        estado !== ESTADOS_PRODUCTO.INACTIVO
    ) {
        throw new ErrorInventario(
            'El estado del producto no es válido.',
            'ESTADO_PRODUCTO_INVALIDO'
        );
    }

    return estado;
}

function normalizarBusqueda(valor) {
    const busqueda = textoSeguro(valor);

    if (busqueda.length > 120) {
        throw new ErrorInventario(
            'La búsqueda no puede superar 120 caracteres.',
            'BUSQUEDA_PRODUCTOS_INVALIDA'
        );
    }

    return busqueda;
}

function normalizarFiltroEstado(valor) {
    const estado = textoSeguro(valor)
        .toUpperCase();

    if (!estado || estado === 'TODOS') {
        return 'TODOS';
    }

    if (
        estado !== ESTADOS_PRODUCTO.ACTIVO &&
        estado !== ESTADOS_PRODUCTO.INACTIVO
    ) {
        throw new ErrorInventario(
            'El filtro de estado no es válido.',
            'FILTRO_ESTADO_INVALIDO'
        );
    }

    return estado;
}

function normalizarPaginacion(
    paginaValor,
    limiteValor
) {
    const pagina = Number(paginaValor || 1);
    const limite = Number(limiteValor || 20);

    if (
        !Number.isInteger(pagina) ||
        pagina < 1
    ) {
        throw new ErrorInventario(
            'La página indicada no es válida.',
            'PAGINACION_INVALIDA'
        );
    }

    if (
        !Number.isInteger(limite) ||
        limite < 1 ||
        limite > 100
    ) {
        throw new ErrorInventario(
            'El límite de productos no es válido.',
            'PAGINACION_INVALIDA'
        );
    }

    return {
        pagina,
        limite,
        desplazamiento: (pagina - 1) * limite
    };
}

/* =========================================================
   VALIDACIÓN DE PRODUCTOS
   ========================================================= */

function validarDatosNuevoProducto(datos) {
    const nombre = validarNombreProducto(
        datos.nombre
    );

    const codigoInterno =
        normalizarCodigoInterno(
            datos.codigoInterno
        ) || null;

    const codigoBarras = normalizarCodigoBarras(
        datos.codigoBarras
    );

    const tipoVenta = normalizarTipoVenta(
        datos.tipoVenta,
        TIPOS_VENTA.UNIDAD
    );

    const unidadMedida =
        obtenerUnidadMedidaSegunTipoVenta(
            tipoVenta
        );

    const precioVentaUsd = normalizarMontoPositivo(
        datos.precioVentaUsd,
        tipoVenta === TIPOS_VENTA.FRACCIONABLE
            ? 'El precio de venta por kg en USD'
            : 'El precio de venta por unidad en USD'
    );

    const existenciaInicial =
        normalizarCantidadSegunTipoVenta(
            datos.existenciaInicial,
            tipoVenta,
            tipoVenta === TIPOS_VENTA.FRACCIONABLE
                ? 'La existencia inicial en kg'
                : 'La existencia inicial en unidades'
        );

    const stockMinimo =
        normalizarCantidadSegunTipoVenta(
            datos.stockMinimo,
            tipoVenta,
            tipoVenta === TIPOS_VENTA.FRACCIONABLE
                ? 'El stock mínimo en kg'
                : 'El stock mínimo en unidades'
        );

    const aplicaIva = normalizarBooleano(
        datos.aplicaIva,
        'La opción de IVA',
        true
    );

    return {
        nombre,
        codigoInterno,
        codigoBarras,
        tipoVenta,
        unidadMedida,
        precioVentaUsd,
        existenciaInicial,
        stockMinimo,
        aplicaIva
    };
}

function validarDatosActualizarProducto(
    datos,
    productoActual
) {
    const nombre = validarNombreProducto(
        datos.nombre
    );

    const codigoInterno =
        normalizarCodigoInterno(
            datos.codigoInterno
        );

    const codigoBarras = normalizarCodigoBarras(
        datos.codigoBarras
    );

    const tipoVentaActual = normalizarTipoVenta(
        productoActual.tipo_venta,
        TIPOS_VENTA.UNIDAD
    );

    /*
        La forma de venta no se puede cambiar después de crear
        un producto. UND y KG representan existencias distintas.
    */
    const tipoVentaRecibido = textoSeguro(
        datos.tipoVenta
    );

    if (
        tipoVentaRecibido &&
        normalizarTipoVenta(tipoVentaRecibido) !==
        tipoVentaActual
    ) {
        throw new ErrorInventario(
            'No se puede cambiar la forma de venta de un producto ya registrado.',
            'TIPO_VENTA_NO_MODIFICABLE'
        );
    }

    const unidadMedida =
        obtenerUnidadMedidaSegunTipoVenta(
            tipoVentaActual
        );

    const precioVentaUsd = normalizarMontoPositivo(
        datos.precioVentaUsd,
        tipoVentaActual === TIPOS_VENTA.FRACCIONABLE
            ? 'El precio de venta por kg en USD'
            : 'El precio de venta por unidad en USD'
    );

    const stockMinimo =
        normalizarCantidadSegunTipoVenta(
            datos.stockMinimo,
            tipoVentaActual,
            tipoVentaActual === TIPOS_VENTA.FRACCIONABLE
                ? 'El stock mínimo en kg'
                : 'El stock mínimo en unidades'
        );

    const aplicaIva = normalizarBooleano(
        datos.aplicaIva,
        'La opción de IVA',
        Boolean(productoActual.aplica_iva)
    );

    return {
        nombre,
        codigoInterno,
        codigoBarras,
        tipoVenta: tipoVentaActual,
        unidadMedida,
        precioVentaUsd,
        stockMinimo,
        aplicaIva
    };
}

/* =========================================================
   ALMACÉN PRINCIPAL
   ========================================================= */

async function obtenerAlmacenPrincipal(
    conexion = db
) {
    const [filas] = await conexion.execute(`
        SELECT
            id,
            codigo,
            nombre,
            estado
        FROM almacenes
        WHERE
            codigo = 'ALMACEN-01'
            AND estado = 'ACTIVO'
        LIMIT 1
    `);

    const almacen = filas[0];

    if (!almacen) {
        throw new ErrorInventario(
            'No se encontró el Almacén principal activo.',
            'ALMACEN_PRINCIPAL_NO_ENCONTRADO'
        );
    }

    return {
        id: Number(almacen.id),
        codigo: almacen.codigo,
        nombre: almacen.nombre
    };
}

/* =========================================================
   MAPEO
   ========================================================= */

function mapearProducto(fila) {
    if (!fila) {
        return null;
    }

    return {
        id: Number(fila.id),

        codigoInterno: fila.codigo_interno,
        codigoBarras: fila.codigo_barras || null,

        nombre: fila.nombre,
        descripcion: fila.descripcion || null,

        tipoVenta: fila.tipo_venta,
        unidadMedida: fila.unidad_medida,

        controlaInventario:
            Boolean(fila.controla_inventario),

        aplicaIva: Boolean(fila.aplica_iva),

        costoReferenciaUsd: String(
            fila.costo_referencia_usd
        ),

        precioVentaUsd: String(
            fila.precio_venta_usd
        ),

        stockMinimo: String(fila.stock_minimo),

        existenciaDisponible: String(
            fila.existencia_disponible || '0.000'
        ),

        estado: fila.estado,

        creadoPorUsuarioId:
            fila.creado_por_usuario_id
                ? Number(fila.creado_por_usuario_id)
                : null,

        creadoPorNombre:
            fila.creado_por_nombre || null,

        actualizadoPorUsuarioId:
            fila.actualizado_por_usuario_id
                ? Number(fila.actualizado_por_usuario_id)
                : null,

        actualizadoPorNombre:
            fila.actualizado_por_nombre || null,

        creadoEn: fila.creado_en,
        actualizadoEn: fila.actualizado_en
    };
}

/* =========================================================
   CONSULTAS
   ========================================================= */

async function obtenerFilaProductoPorId(
    productoId,
    conexion = db
) {
    const id = validarIdProducto(productoId);

    const almacen = await obtenerAlmacenPrincipal(
        conexion
    );

    const [filas] = await conexion.execute(`
        SELECT
            producto.id,
            producto.codigo_interno,
            producto.codigo_barras,
            producto.nombre,
            producto.descripcion,
            producto.tipo_venta,
            producto.unidad_medida,
            producto.controla_inventario,
            producto.aplica_iva,
            producto.costo_referencia_usd,
            producto.precio_venta_usd,
            producto.stock_minimo,
            producto.estado,
            producto.creado_por_usuario_id,
            producto.actualizado_por_usuario_id,
            producto.creado_en,
            producto.actualizado_en,

            COALESCE(
                existencia.disponible,
                0.000
            ) AS existencia_disponible,

            creador.nombre_completo
                AS creado_por_nombre,

            actualizador.nombre_completo
                AS actualizado_por_nombre

        FROM productos AS producto

        LEFT JOIN existencias_producto AS existencia
            ON existencia.producto_id = producto.id
            AND existencia.almacen_id = ?

        LEFT JOIN usuarios_locales AS creador
            ON creador.id =
                producto.creado_por_usuario_id

        LEFT JOIN usuarios_locales AS actualizador
            ON actualizador.id =
                producto.actualizado_por_usuario_id

        WHERE producto.id = ?
        LIMIT 1
    `, [
        almacen.id,
        id
    ]);

    return filas[0] || null;
}

async function obtenerProductoPorId(
    productoId,
    conexion = db
) {
    const fila = await obtenerFilaProductoPorId(
        productoId,
        conexion
    );

    if (!fila) {
        throw new ErrorInventario(
            'El producto indicado no existe.',
            'PRODUCTO_NO_ENCONTRADO'
        );
    }

    return mapearProducto(fila);
}

async function listarProductos(
    filtros = {},
    conexion = db
) {
    const almacen = await obtenerAlmacenPrincipal(
        conexion
    );

    const busqueda = normalizarBusqueda(
        filtros.busqueda
    );

    const estado = normalizarFiltroEstado(
        filtros.estado
    );

    const paginacion = normalizarPaginacion(
        filtros.pagina,
        filtros.limite
    );

    const condiciones = [];
    const parametros = [almacen.id];

    if (estado !== 'TODOS') {
        condiciones.push(
            'producto.estado = ?'
        );

        parametros.push(estado);
    }

    if (busqueda) {
        condiciones.push(`
            (
                producto.nombre LIKE ?
                OR producto.codigo_interno LIKE ?
                OR producto.codigo_barras LIKE ?
            )
        `);

        const criterio = `%${busqueda}%`;

        parametros.push(
            criterio,
            criterio,
            criterio
        );
    }

    const condicionSql = condiciones.length > 0
        ? `WHERE ${condiciones.join(' AND ')}`
        : '';

    const [filas] = await conexion.execute(`
        SELECT
            producto.id,
            producto.codigo_interno,
            producto.codigo_barras,
            producto.nombre,
            producto.descripcion,
            producto.tipo_venta,
            producto.unidad_medida,
            producto.controla_inventario,
            producto.aplica_iva,
            producto.costo_referencia_usd,
            producto.precio_venta_usd,
            producto.stock_minimo,
            producto.estado,
            producto.creado_por_usuario_id,
            producto.actualizado_por_usuario_id,
            producto.creado_en,
            producto.actualizado_en,

            COALESCE(
                existencia.disponible,
                0.000
            ) AS existencia_disponible,

            creador.nombre_completo
                AS creado_por_nombre,

            actualizador.nombre_completo
                AS actualizado_por_nombre

        FROM productos AS producto

        LEFT JOIN existencias_producto AS existencia
            ON existencia.producto_id = producto.id
            AND existencia.almacen_id = ?

        LEFT JOIN usuarios_locales AS creador
            ON creador.id =
                producto.creado_por_usuario_id

        LEFT JOIN usuarios_locales AS actualizador
            ON actualizador.id =
                producto.actualizado_por_usuario_id

        ${condicionSql}

        ORDER BY
            producto.estado = 'ACTIVO' DESC,
            producto.nombre ASC,
            producto.id DESC

        LIMIT ?
        OFFSET ?
    `, [
        ...parametros,
        paginacion.limite,
        paginacion.desplazamiento
    ]);

    const parametrosTotal = [];

    if (estado !== 'TODOS') {
        parametrosTotal.push(estado);
    }

    if (busqueda) {
        const criterio = `%${busqueda}%`;

        parametrosTotal.push(
            criterio,
            criterio,
            criterio
        );
    }

    const [filasTotal] = await conexion.execute(`
        SELECT COUNT(*) AS total
        FROM productos AS producto
        ${condicionSql}
    `, parametrosTotal);

    const total = Number(
        filasTotal[0]?.total || 0
    );

    return {
        productos: filas.map(mapearProducto),

        paginacion: {
            pagina: paginacion.pagina,
            limite: paginacion.limite,
            total,
            totalPaginas: Math.max(
                1,
                Math.ceil(total / paginacion.limite)
            )
        }
    };
}

/* =========================================================
   CREAR PRODUCTO Y EXISTENCIA INICIAL
   ========================================================= */

async function crearProducto(
    datos,
    usuarioResponsableId,
    conexion = db
) {
    const usuarioId = validarIdUsuario(
        usuarioResponsableId
    );

    const producto = validarDatosNuevoProducto(
        datos
    );

    const usaPool =
        typeof conexion.getConnection === 'function';

    const conexionTrabajo = usaPool
        ? await conexion.getConnection()
        : conexion;

    let transaccionIniciada = false;

    try {
        if (usaPool) {
            await conexionTrabajo.beginTransaction();

            transaccionIniciada = true;
        }

        const almacen = await obtenerAlmacenPrincipal(
            conexionTrabajo
        );

        const [resultadoProducto] =
            await conexionTrabajo.execute(`
        INSERT INTO productos (
            codigo_interno,
            codigo_barras,
            nombre,
            tipo_venta,
            unidad_medida,
            controla_inventario,
            aplica_iva,
            costo_referencia_usd,
            precio_venta_usd,
            stock_minimo,
            estado,
            creado_por_usuario_id,
            actualizado_por_usuario_id
        )
        VALUES (
            ?,
            ?,
            ?,
            ?,
            ?,
            1,
            ?,
            0.000000,
            ?,
            ?,
            'ACTIVO',
            ?,
            ?
        )
    `, [
                producto.codigoInterno,
                producto.codigoBarras,
                producto.nombre,
                producto.tipoVenta,
                producto.unidadMedida,
                producto.aplicaIva ? 1 : 0,
                producto.precioVentaUsd,
                producto.stockMinimo,
                usuarioId,
                usuarioId
            ]);

        const productoId = resultadoProducto.insertId;

        await conexionTrabajo.execute(`
            INSERT INTO existencias_producto (
                producto_id,
                almacen_id,
                disponible,
                reservado,
                actualizado_por_usuario_id
            )
            VALUES (
                ?,
                ?,
                ?,
                0.000,
                ?
            )
        `, [
            productoId,
            almacen.id,
            producto.existenciaInicial,
            usuarioId
        ]);

        /*
            La existencia inicial solo genera movimiento
            cuando el valor es mayor que cero.
        */
        if (Number(producto.existenciaInicial) > 0) {
            await conexionTrabajo.execute(`
                INSERT INTO movimientos_inventario (
                    producto_id,
                    almacen_id,
                    tipo,
                    cantidad_movimiento,
                    existencia_anterior,
                    existencia_nueva,
                    nota,
                    creado_por_usuario_id
                )
                VALUES (
                    ?,
                    ?,
                    ?,
                    ?,
                    0.000,
                    ?,
                    'Existencia inicial al registrar el producto.',
                    ?
                )
            `, [
                productoId,
                almacen.id,
                TIPOS_MOVIMIENTO_INVENTARIO.INICIAL,
                producto.existenciaInicial,
                producto.existenciaInicial,
                usuarioId
            ]);
        }

        const productoCreado =
            await obtenerProductoPorId(
                productoId,
                conexionTrabajo
            );

        if (transaccionIniciada) {
            await conexionTrabajo.commit();
        }

        return productoCreado;
    } catch (error) {
        if (transaccionIniciada) {
            try {
                await conexionTrabajo.rollback();
            } catch (errorRollback) {
                /*
                    El error original conserva prioridad.
                */
            }
        }

        if (error.code === 'ER_DUP_ENTRY') {
            throw new ErrorInventario(
                'El código interno o código de barras ya está registrado en otro producto.',
                'PRODUCTO_DUPLICADO'
            );
        }

        throw error;
    } finally {
        if (usaPool) {
            conexionTrabajo.release();
        }
    }
}

/* =========================================================
   EDITAR PRODUCTO
   ========================================================= */

async function actualizarProducto(
    productoId,
    datos,
    usuarioResponsableId,
    conexion = db
) {
    const id = validarIdProducto(productoId);

    const usuarioId = validarIdUsuario(
        usuarioResponsableId
    );

    const productoActual =
        await obtenerFilaProductoPorId(
            id,
            conexion
        );

    if (!productoActual) {
        throw new ErrorInventario(
            'El producto indicado no existe.',
            'PRODUCTO_NO_ENCONTRADO'
        );
    }

    const producto = validarDatosActualizarProducto(
        datos,
        productoActual
    );

    try {
        await conexion.execute(`
            UPDATE productos
            SET
                codigo_interno = ?,
                codigo_barras = ?,
                nombre = ?,
                aplica_iva = ?,
                precio_venta_usd = ?,
                stock_minimo = ?,
                actualizado_por_usuario_id = ?
            WHERE id = ?
        `, [
            producto.codigoInterno,
            producto.codigoBarras,
            producto.nombre,
            producto.aplicaIva ? 1 : 0,
            producto.precioVentaUsd,
            producto.stockMinimo,
            usuarioId,
            id
        ]);
    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') {
            throw new ErrorInventario(
                'El código interno o código de barras ya está registrado en otro producto.',
                'PRODUCTO_DUPLICADO'
            );
        }

        throw error;
    }

    return obtenerProductoPorId(id, conexion);
}
/* =========================================================
   AJUSTE BÁSICO DE EXISTENCIA
   ========================================================= */

/*
    Este flujo controla la existencia real del producto.

    ENTRADA:
    Suma unidades al stock actual.

    SALIDA:
    Resta unidades del stock actual.
    Nunca permite dejar una existencia negativa.

    RECONTEO:
    Coloca la existencia exacta que se encontró al contar
    físicamente el producto.
*/
async function ajustarExistenciaProducto(
    productoId,
    datos,
    usuarioResponsableId,
    conexion = db
) {
    const id = validarIdProducto(productoId);

    const usuarioId = validarIdUsuario(
        usuarioResponsableId
    );

    const usaPool =
        typeof conexion.getConnection === 'function';

    const conexionTrabajo = usaPool
        ? await conexion.getConnection()
        : conexion;

    let transaccionIniciada = false;

    try {
        if (usaPool) {
            await conexionTrabajo.beginTransaction();

            transaccionIniciada = true;
        }

        const productoActual =
            await obtenerFilaProductoPorId(
                id,
                conexionTrabajo
            );

        if (!productoActual) {
            throw new ErrorInventario(
                'El producto indicado no existe.',
                'PRODUCTO_NO_ENCONTRADO'
            );
        }
        const ajuste = validarDatosAjusteExistencia(
            datos,
            productoActual.tipo_venta
        );
        const almacen = await obtenerAlmacenPrincipal(
            conexionTrabajo
        );

        const [filasExistencia] =
            await conexionTrabajo.execute(`
                SELECT
                    id,
                    disponible
                FROM existencias_producto
                WHERE
                    producto_id = ?
                    AND almacen_id = ?
                LIMIT 1
                FOR UPDATE
            `, [
                id,
                almacen.id
            ]);

        let existencia = filasExistencia[0];

        /*
            Por seguridad, si un producto antiguo no tuviera
            todavía una fila de existencia, la creamos en cero.
        */
        if (!existencia) {
            await conexionTrabajo.execute(`
                INSERT INTO existencias_producto (
                    producto_id,
                    almacen_id,
                    disponible,
                    reservado,
                    actualizado_por_usuario_id
                )
                VALUES (
                    ?,
                    ?,
                    0.000,
                    0.000,
                    ?
                )
            `, [
                id,
                almacen.id,
                usuarioId
            ]);

            const [filasNuevaExistencia] =
                await conexionTrabajo.execute(`
                    SELECT
                        id,
                        disponible
                    FROM existencias_producto
                    WHERE
                        producto_id = ?
                        AND almacen_id = ?
                    LIMIT 1
                    FOR UPDATE
                `, [
                    id,
                    almacen.id
                ]);

            existencia = filasNuevaExistencia[0];
        }

        const existenciaAnterior = Number(
            existencia.disponible
        );

        const cantidadSolicitada = Number(
            ajuste.cantidad
        );

        let existenciaNueva = existenciaAnterior;
        let cantidadMovimiento = 0;
        let tipoMovimiento = null;
        let notaMovimiento = ajuste.nota;

        if (ajuste.modo === MODOS_AJUSTE_INVENTARIO.ENTRADA) {
            existenciaNueva =
                existenciaAnterior + cantidadSolicitada;

            cantidadMovimiento = cantidadSolicitada;

            tipoMovimiento =
                TIPOS_MOVIMIENTO_INVENTARIO.ENTRADA;

            notaMovimiento = notaMovimiento ||
                'Entrada manual de inventario.';
        }

        if (ajuste.modo === MODOS_AJUSTE_INVENTARIO.SALIDA) {
            existenciaNueva =
                existenciaAnterior - cantidadSolicitada;

            if (existenciaNueva < 0) {
                throw new ErrorInventario(
                    `No es posible restar ${cantidadSolicitada}. La existencia disponible es ${existenciaAnterior}.`,
                    'EXISTENCIA_INSUFICIENTE'
                );
            }

            cantidadMovimiento = -cantidadSolicitada;

            tipoMovimiento =
                TIPOS_MOVIMIENTO_INVENTARIO.SALIDA;

            notaMovimiento = notaMovimiento ||
                'Salida manual de inventario.';
        }

        if (ajuste.modo === MODOS_AJUSTE_INVENTARIO.RECONTEO) {
            existenciaNueva = cantidadSolicitada;

            const diferencia =
                existenciaNueva - existenciaAnterior;

            if (diferencia === 0) {
                throw new ErrorInventario(
                    'La existencia indicada coincide con la existencia actual. No hay cambios que guardar.',
                    'AJUSTE_SIN_CAMBIOS'
                );
            }

            cantidadMovimiento = diferencia;

            tipoMovimiento = diferencia > 0
                ? TIPOS_MOVIMIENTO_INVENTARIO.AJUSTE_POSITIVO
                : TIPOS_MOVIMIENTO_INVENTARIO.AJUSTE_NEGATIVO;

            notaMovimiento = notaMovimiento ||
                'Ajuste por reconteo físico de inventario.';
        }

        await conexionTrabajo.execute(`
            UPDATE existencias_producto
            SET
                disponible = ?,
                actualizado_por_usuario_id = ?
            WHERE id = ?
        `, [
            existenciaNueva,
            usuarioId,
            existencia.id
        ]);

        await conexionTrabajo.execute(`
            INSERT INTO movimientos_inventario (
                producto_id,
                almacen_id,
                tipo,
                cantidad_movimiento,
                existencia_anterior,
                existencia_nueva,
                nota,
                creado_por_usuario_id
            )
            VALUES (
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?
            )
        `, [
            id,
            almacen.id,
            tipoMovimiento,
            cantidadMovimiento,
            existenciaAnterior,
            existenciaNueva,
            notaMovimiento,
            usuarioId
        ]);

        const productoActualizado =
            await obtenerProductoPorId(
                id,
                conexionTrabajo
            );

        if (transaccionIniciada) {
            await conexionTrabajo.commit();
        }

        return {
            producto: productoActualizado,

            movimiento: {
                tipo: tipoMovimiento,
                cantidadMovimiento: String(
                    cantidadMovimiento
                ),

                existenciaAnterior: String(
                    existenciaAnterior
                ),

                existenciaNueva: String(
                    existenciaNueva
                ),

                nota: notaMovimiento
            }
        };
    } catch (error) {
        if (transaccionIniciada) {
            try {
                await conexionTrabajo.rollback();
            } catch (errorRollback) {
                /*
                    El error original conserva prioridad.
                */
            }
        }

        throw error;
    } finally {
        if (usaPool) {
            conexionTrabajo.release();
        }
    }
}
/* =========================================================
   ACTIVAR / INACTIVAR PRODUCTO
   ========================================================= */

async function cambiarEstadoProducto(
    productoId,
    estado,
    usuarioResponsableId,
    conexion = db
) {
    const id = validarIdProducto(productoId);

    const usuarioId = validarIdUsuario(
        usuarioResponsableId
    );

    const estadoSeguro = normalizarEstadoProducto(
        estado
    );

    const productoActual =
        await obtenerFilaProductoPorId(
            id,
            conexion
        );

    if (!productoActual) {
        throw new ErrorInventario(
            'El producto indicado no existe.',
            'PRODUCTO_NO_ENCONTRADO'
        );
    }

    await conexion.execute(`
        UPDATE productos
        SET
            estado = ?,
            actualizado_por_usuario_id = ?
        WHERE id = ?
    `, [
        estadoSeguro,
        usuarioId,
        id
    ]);

    return obtenerProductoPorId(id, conexion);
}

/* =========================================================
   BÚSQUEDA OPERATIVA PARA PUNTO DE VENTA
   ========================================================= */

/*
    Esta función está pensada únicamente para el Punto de Venta.

    Nunca devuelve:
    - costo de referencia;
    - datos de creación;
    - datos de actualización;
    - información administrativa interna.

    Solo devuelve lo necesario para agregar un producto
    temporalmente al carrito.
*/
function normalizarLimiteBusquedaVentas(valor) {
    const limite = Number(valor || 12);

    if (
        !Number.isInteger(limite) ||
        limite < 1 ||
        limite > 30
    ) {
        throw new ErrorInventario(
            'El límite de búsqueda para Ventas no es válido.',
            'LIMITE_BUSQUEDA_VENTAS_INVALIDO'
        );
    }

    return limite;
}

function mapearProductoParaVenta(fila) {
    if (!fila) {
        return null;
    }

    return {
        id: Number(fila.id),

        codigoInterno: fila.codigo_interno,

        codigoBarras:
            fila.codigo_barras || null,

        nombre: fila.nombre,

        tipoVenta: fila.tipo_venta,

        unidadMedida: fila.unidad_medida,

        controlaInventario:
            Boolean(fila.controla_inventario),

        aplicaIva:
            Boolean(fila.aplica_iva),

        precioVentaUsd: String(
            fila.precio_venta_usd
        ),

        existenciaDisponible: String(
            fila.existencia_disponible || '0.000'
        )
    };
}

async function buscarProductosParaVenta(
    terminoBusqueda,
    opciones = {},
    conexion = db
) {
    const busqueda = normalizarBusqueda(
        terminoBusqueda
    );

    const limite = normalizarLimiteBusquedaVentas(
        opciones.limite
    );

    /*
        No devolvemos automáticamente todos los productos
        al abrir F2. El cajero debe escribir una búsqueda.
    */
    if (!busqueda) {
        return [];
    }

    const almacen = await obtenerAlmacenPrincipal(
        conexion
    );

    const criterio = `%${busqueda}%`;

    const busquedaExacta = busqueda
        .toUpperCase()
        .replace(/\s+/g, '');

    const [filas] = await conexion.execute(`
        SELECT
            producto.id,
            producto.codigo_interno,
            producto.codigo_barras,
            producto.nombre,
            producto.tipo_venta,
            producto.unidad_medida,
            producto.controla_inventario,
            producto.aplica_iva,
            producto.precio_venta_usd,

            COALESCE(
                existencia.disponible,
                0.000
            ) AS existencia_disponible

        FROM productos AS producto

        LEFT JOIN existencias_producto AS existencia
            ON existencia.producto_id = producto.id
            AND existencia.almacen_id = ?

        WHERE
            producto.estado = 'ACTIVO'
            AND (
                producto.nombre LIKE ?
                OR producto.codigo_interno LIKE ?
                OR producto.codigo_barras LIKE ?
            )

        ORDER BY
            CASE
                WHEN REPLACE(
                    UPPER(producto.codigo_interno),
                    ' ',
                    ''
                ) = ? THEN 0

                WHEN REPLACE(
                    UPPER(
                        COALESCE(
                            producto.codigo_barras,
                            ''
                        )
                    ),
                    ' ',
                    ''
                ) = ? THEN 1

                WHEN UPPER(producto.nombre) =
                    UPPER(?) THEN 2

                ELSE 3
            END,

            producto.nombre ASC,
            producto.id DESC

        LIMIT ?
    `, [
        almacen.id,

        criterio,
        criterio,
        criterio,

        busquedaExacta,
        busquedaExacta,
        busqueda,

        limite
    ]);

    return filas.map(mapearProductoParaVenta);
}

/* =========================================================
   EXPORTACIONES
   ========================================================= */

module.exports = {
    ErrorInventario,

    ESTADOS_PRODUCTO,
    TIPOS_VENTA,

    obtenerAlmacenPrincipal,

    listarProductos,
    obtenerProductoPorId,
    buscarProductosParaVenta,

    crearProducto,
    actualizarProducto,
    cambiarEstadoProducto,
    ajustarExistenciaProducto
};