'use strict';

const { db } = require('../../config/database');

class ErrorCliente extends Error {
    constructor(
        mensaje,
        codigo = 'CLIENTE_INVALIDO'
    ) {
        super(mensaje);

        this.name = 'ErrorCliente';
        this.codigo = codigo;
    }
}

function textoSeguro(valor) {
    return String(valor ?? '')
        .trim()
        .replace(/\s+/g, ' ');
}

function textoOpcional(
    valor,
    etiqueta,
    maximo
) {
    const texto = textoSeguro(valor);

    if (texto.length > maximo) {
        throw new ErrorCliente(
            `${etiqueta} no puede superar ${maximo} caracteres.`
        );
    }

    return texto || null;
}

function textoRequerido(
    valor,
    etiqueta,
    minimo,
    maximo
) {
    const texto = textoSeguro(valor);

    if (
        texto.length < minimo ||
        texto.length > maximo
    ) {
        throw new ErrorCliente(
            `${etiqueta} debe tener entre ${minimo} y ${maximo} caracteres.`
        );
    }

    return texto;
}

function normalizarTipoPersona(valor) {
    const tipoPersona = textoSeguro(valor)
        .toUpperCase() || 'NATURAL';

    const tiposPermitidos = [
        'NATURAL',
        'JURIDICA'
    ];

    if (!tiposPermitidos.includes(tipoPersona)) {
        throw new ErrorCliente(
            'El tipo de persona seleccionado no es válido.',
            'TIPO_PERSONA_INVALIDO'
        );
    }

    return tipoPersona;
}

function normalizarIdentificacion(valor) {
    const identificacion = textoSeguro(valor)
        .toUpperCase();

    if (!identificacion) {
        return {
            identificacion: null,
            identificacionNormalizada: null
        };
    }

    if (identificacion.length > 50) {
        throw new ErrorCliente(
            'La identificación no puede superar 50 caracteres.',
            'IDENTIFICACION_INVALIDA'
        );
    }

    /*
        Ejemplos que se convierten en la misma identificación:

        V-12345678
        V 12345678
        v12345678
        → V12345678
    */
    const identificacionNormalizada = identificacion
        .replace(/[^A-Z0-9]/g, '');

    if (
        identificacionNormalizada.length < 3 ||
        identificacionNormalizada.length > 50
    ) {
        throw new ErrorCliente(
            'La identificación ingresada no tiene un formato válido.',
            'IDENTIFICACION_INVALIDA'
        );
    }

    return {
        identificacion,
        identificacionNormalizada
    };
}

function normalizarCorreo(valor) {
    const correo = textoSeguro(valor)
        .toLowerCase();

    if (!correo) {
        return null;
    }

    if (
        correo.length > 160 ||
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo)
    ) {
        throw new ErrorCliente(
            'El correo del cliente no tiene un formato válido.',
            'CORREO_CLIENTE_INVALIDO'
        );
    }

    return correo;
}

function normalizarEstado(valor) {
    const estado = textoSeguro(valor)
        .toUpperCase() || 'ACTIVO';

    const estadosPermitidos = [
        'ACTIVO',
        'INACTIVO'
    ];

    if (!estadosPermitidos.includes(estado)) {
        throw new ErrorCliente(
            'El estado del cliente no es válido.',
            'ESTADO_CLIENTE_INVALIDO'
        );
    }

    return estado;
}

function validarUsuarioId(usuarioId) {
    const idSeguro = Number(usuarioId);

    if (
        !Number.isInteger(idSeguro) ||
        idSeguro < 1
    ) {
        throw new ErrorCliente(
            'No fue posible identificar al usuario que realiza esta acción.',
            'USUARIO_NO_VALIDO'
        );
    }

    return idSeguro;
}

function validarIdCliente(clienteId) {
    const idSeguro = Number(clienteId);

    if (
        !Number.isInteger(idSeguro) ||
        idSeguro < 1
    ) {
        throw new ErrorCliente(
            'El identificador del cliente no es válido.',
            'CLIENTE_ID_INVALIDO'
        );
    }

    return idSeguro;
}

function validarDatosCliente(datos) {
    const tipoPersona = normalizarTipoPersona(
        datos.tipoPersona
    );

    const nombreORazonSocial = textoRequerido(
        datos.nombreORazonSocial,
        tipoPersona === 'JURIDICA'
            ? 'La razón social'
            : 'El nombre del cliente',
        2,
        180
    );

    const datosIdentificacion =
        normalizarIdentificacion(
            datos.identificacion
        );

    const telefono = textoOpcional(
        datos.telefono,
        'El teléfono',
        50
    );

    const correo = normalizarCorreo(
        datos.correo
    );

    const direccion = textoOpcional(
        datos.direccion,
        'La dirección',
        2000
    );

    const notas = textoOpcional(
        datos.notas,
        'Las notas',
        2000
    );

    return {
        tipoPersona,
        nombreORazonSocial,

        identificacion:
            datosIdentificacion.identificacion,

        identificacionNormalizada:
            datosIdentificacion.identificacionNormalizada,

        telefono,
        correo,
        direccion,
        notas
    };
}

function normalizarBusqueda(valor) {
    const busqueda = textoSeguro(valor);

    if (busqueda.length > 120) {
        throw new ErrorCliente(
            'La búsqueda no puede superar 120 caracteres.',
            'BUSQUEDA_INVALIDA'
        );
    }

    return busqueda;
}

function normalizarLimite(valor) {
    const limite = Number(valor ?? 20);

    if (!Number.isInteger(limite)) {
        return 20;
    }

    return Math.min(
        Math.max(limite, 1),
        100
    );
}

function normalizarPagina(valor) {
    const pagina = Number(valor ?? 1);

    if (!Number.isInteger(pagina)) {
        return 1;
    }

    return Math.max(pagina, 1);
}

function construirFiltroBusqueda(busqueda) {
    if (!busqueda) {
        return {
            sql: '',
            valores: []
        };
    }

    const termino = `%${busqueda}%`;

    return {
        sql: `
            AND (
                cliente.nombre_o_razon_social LIKE ?
                OR cliente.identificacion LIKE ?
                OR cliente.telefono LIKE ?
                OR cliente.correo LIKE ?
            )
        `,
        valores: [
            termino,
            termino,
            termino,
            termino
        ]
    };
}

async function obtenerClientePorId(
    clienteId,
    conexion = db
) {
    const idSeguro = validarIdCliente(clienteId);

    const [filas] = await conexion.execute(`
        SELECT
            cliente.id,
            cliente.tipo_persona,
            cliente.nombre_o_razon_social,
            cliente.identificacion,
            cliente.telefono,
            cliente.correo,
            cliente.direccion,
            cliente.notas,
            cliente.estado,
            cliente.creado_en,
            cliente.actualizado_en,

            creador.nombre_completo
                AS creado_por_nombre,

            actualizador.nombre_completo
                AS actualizado_por_nombre

        FROM clientes_locales AS cliente

        INNER JOIN usuarios_locales AS creador
            ON creador.id =
                cliente.creado_por_usuario_id

        INNER JOIN usuarios_locales AS actualizador
            ON actualizador.id =
                cliente.actualizado_por_usuario_id

        WHERE cliente.id = ?
        LIMIT 1
    `, [
        idSeguro
    ]);

    return filas[0] || null;
}

async function crearCliente(
    datos,
    usuarioId,
    conexion = db
) {
    const cliente = validarDatosCliente(datos);

    const usuarioIdSeguro = validarUsuarioId(
        usuarioId
    );

    try {
        const [resultado] = await conexion.execute(`
            INSERT INTO clientes_locales (
                tipo_persona,
                nombre_o_razon_social,
                identificacion,
                identificacion_normalizada,
                telefono,
                correo,
                direccion,
                notas,
                estado,
                creado_por_usuario_id,
                actualizado_por_usuario_id
            )
            VALUES (
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                'ACTIVO',
                ?,
                ?
            )
        `, [
            cliente.tipoPersona,
            cliente.nombreORazonSocial,
            cliente.identificacion,
            cliente.identificacionNormalizada,
            cliente.telefono,
            cliente.correo,
            cliente.direccion,
            cliente.notas,
            usuarioIdSeguro,
            usuarioIdSeguro
        ]);

        return obtenerClientePorId(
            resultado.insertId,
            conexion
        );
    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') {
            throw new ErrorCliente(
                'Ya existe un cliente registrado con esta identificación.',
                'CLIENTE_IDENTIFICACION_DUPLICADA'
            );
        }

        throw error;
    }
}

async function actualizarCliente(
    clienteId,
    datos,
    usuarioId,
    conexion = db
) {
    const idSeguro = validarIdCliente(clienteId);

    const usuarioIdSeguro = validarUsuarioId(
        usuarioId
    );

    const cliente = validarDatosCliente(datos);

    const clienteActual =
        await obtenerClientePorId(
            idSeguro,
            conexion
        );

    if (!clienteActual) {
        throw new ErrorCliente(
            'El cliente indicado no existe.',
            'CLIENTE_NO_ENCONTRADO'
        );
    }

    try {
        await conexion.execute(`
            UPDATE clientes_locales
            SET
                tipo_persona = ?,
                nombre_o_razon_social = ?,
                identificacion = ?,
                identificacion_normalizada = ?,
                telefono = ?,
                correo = ?,
                direccion = ?,
                notas = ?,
                actualizado_por_usuario_id = ?
            WHERE id = ?
        `, [
            cliente.tipoPersona,
            cliente.nombreORazonSocial,
            cliente.identificacion,
            cliente.identificacionNormalizada,
            cliente.telefono,
            cliente.correo,
            cliente.direccion,
            cliente.notas,
            usuarioIdSeguro,
            idSeguro
        ]);
    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') {
            throw new ErrorCliente(
                'Ya existe otro cliente registrado con esta identificación.',
                'CLIENTE_IDENTIFICACION_DUPLICADA'
            );
        }

        throw error;
    }

    return obtenerClientePorId(
        idSeguro,
        conexion
    );
}

async function cambiarEstadoCliente(
    clienteId,
    nuevoEstado,
    usuarioId,
    conexion = db
) {
    const idSeguro = validarIdCliente(clienteId);

    const usuarioIdSeguro = validarUsuarioId(
        usuarioId
    );

    const estadoSeguro = normalizarEstado(
        nuevoEstado
    );

    const clienteActual =
        await obtenerClientePorId(
            idSeguro,
            conexion
        );

    if (!clienteActual) {
        throw new ErrorCliente(
            'El cliente indicado no existe.',
            'CLIENTE_NO_ENCONTRADO'
        );
    }

    await conexion.execute(`
        UPDATE clientes_locales
        SET
            estado = ?,
            actualizado_por_usuario_id = ?
        WHERE id = ?
    `, [
        estadoSeguro,
        usuarioIdSeguro,
        idSeguro
    ]);

    return obtenerClientePorId(
        idSeguro,
        conexion
    );
}

async function listarClientes(
    {
        busqueda = '',
        estado = 'ACTIVO',
        pagina = 1,
        limite = 20,
        soloSemana = false
    } = {},
    conexion = db
) {
    const busquedaSegura = normalizarBusqueda(
        busqueda
    );

    const estadoSeguro =
        textoSeguro(estado).toUpperCase() || 'ACTIVO';

    const estadosPermitidos = [
        'ACTIVO',
        'INACTIVO',
        'TODOS'
    ];

    if (!estadosPermitidos.includes(estadoSeguro)) {
        throw new ErrorCliente(
            'El filtro de estado no es válido.',
            'FILTRO_ESTADO_INVALIDO'
        );
    }

    const semanaActiva =
        String(soloSemana).toLowerCase() === 'true' ||
        soloSemana === true ||
        Number(soloSemana) === 1;

    const limiteSeguro = normalizarLimite(limite);

    const paginaSegura = normalizarPagina(pagina);

    const desplazamiento =
        (paginaSegura - 1) * limiteSeguro;

    const filtroBusqueda =
        construirFiltroBusqueda(
            busquedaSegura
        );

    const filtroEstado =
        estadoSeguro === 'TODOS'
            ? {
                sql: '',
                valores: []
            }
            : {
                sql: `
                    AND cliente.estado = ?
                `,
                valores: [estadoSeguro]
            };

    const filtroSemana = semanaActiva
        ? {
            sql: `
                AND DATE(cliente.creado_en) >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
            `,
            valores: []
        }
        : {
            sql: '',
            valores: []
        };

    const filtroSql = `
        WHERE 1 = 1
        ${filtroEstado.sql}
        ${filtroSemana.sql}
        ${filtroBusqueda.sql}
    `;

    const valoresFiltro = [
        ...filtroEstado.valores,
        ...filtroSemana.valores,
        ...filtroBusqueda.valores
    ];

    const [filas] = await conexion.execute(`
        SELECT
            cliente.id,
            cliente.tipo_persona,
            cliente.nombre_o_razon_social,
            cliente.identificacion,
            cliente.telefono,
            cliente.correo,
            cliente.estado,
            cliente.creado_en,
            cliente.actualizado_en,

            creador.nombre_completo
                AS creado_por_nombre,

            actualizador.nombre_completo
                AS actualizado_por_nombre

        FROM clientes_locales AS cliente

        INNER JOIN usuarios_locales AS creador
            ON creador.id =
                cliente.creado_por_usuario_id

        INNER JOIN usuarios_locales AS actualizador
            ON actualizador.id =
                cliente.actualizado_por_usuario_id

        ${filtroSql}

        ORDER BY
            cliente.nombre_o_razon_social ASC,
            cliente.id DESC

        LIMIT ?
        OFFSET ?
    `, [
        ...valoresFiltro,
        limiteSeguro,
        desplazamiento
    ]);

    const [conteoFilas] = await conexion.execute(`
        SELECT COUNT(*) AS total
        FROM clientes_locales AS cliente
        ${filtroSql}
    `, valoresFiltro);

    const total = Number(
        conteoFilas[0]?.total || 0
    );

    return {
        clientes: filas,
        paginacion: {
            pagina: paginaSegura,
            limite: limiteSeguro,
            total,
            totalPaginas: Math.max(
                1,
                Math.ceil(total / limiteSeguro)
            )
        }
    };
}

/*
    Búsqueda pensada para Caja.

    Primero intenta una coincidencia exacta por cédula/RIF.
    Luego busca por nombre, teléfono, correo o identificación.

    Esta función devolverá como máximo ocho resultados para
    que el cajero pueda seleccionar rápidamente sin abrir
    el módulo administrativo completo.
*/
function normalizarConsultaRapida(valor) {
    const consulta = textoSeguro(valor);

    if (consulta.length > 120) {
        throw new ErrorCliente(
            'La búsqueda rápida no puede superar 120 caracteres.',
            'BUSQUEDA_RAPIDA_INVALIDA'
        );
    }

    return {
        consulta,

        identificacionNormalizada: consulta
            .toUpperCase()
            .replace(/[^A-Z0-9]/g, '')
    };
}

async function buscarClientesRapido(
    consulta,
    {
        limite = 8
    } = {},
    conexion = db
) {
    const datosBusqueda =
        normalizarConsultaRapida(consulta);

    if (!datosBusqueda.consulta) {
        return {
            coincidenciaExacta: false,
            clientes: []
        };
    }

    const limiteSeguro = Math.min(
        normalizarLimite(limite),
        8
    );

    /*
        Coincidencia directa por cédula o RIF.
    */
    if (
        datosBusqueda.identificacionNormalizada
            .length >= 3
    ) {
        const [coincidenciasExactas] =
            await conexion.execute(`
                SELECT
                    cliente.id,
                    cliente.tipo_persona,
                    cliente.nombre_o_razon_social,
                    cliente.identificacion,
                    cliente.telefono,
                    cliente.correo,
                    cliente.estado
                FROM clientes_locales AS cliente
                WHERE
                    cliente.estado = 'ACTIVO'
                    AND cliente.identificacion_normalizada = ?
                LIMIT 1
            `, [
                datosBusqueda.identificacionNormalizada
            ]);

        if (coincidenciasExactas.length > 0) {
            return {
                coincidenciaExacta: true,
                clientes: coincidenciasExactas
            };
        }
    }

    /*
        Coincidencias parciales para nombre, teléfono,
        correo o identificación.
    */
    const termino = `%${datosBusqueda.consulta}%`;

    const terminoIdentificacion =
        `%${datosBusqueda.identificacionNormalizada}%`;

    const [clientes] = await conexion.execute(`
        SELECT
            cliente.id,
            cliente.tipo_persona,
            cliente.nombre_o_razon_social,
            cliente.identificacion,
            cliente.telefono,
            cliente.correo,
            cliente.estado
        FROM clientes_locales AS cliente
        WHERE
            cliente.estado = 'ACTIVO'
            AND (
                cliente.nombre_o_razon_social LIKE ?
                OR cliente.identificacion LIKE ?
                OR cliente.identificacion_normalizada LIKE ?
                OR cliente.telefono LIKE ?
                OR cliente.correo LIKE ?
            )
        ORDER BY
            cliente.nombre_o_razon_social ASC,
            cliente.id DESC
        LIMIT ?
    `, [
        termino,
        termino,
        terminoIdentificacion,
        termino,
        termino,
        limiteSeguro
    ]);

    return {
        coincidenciaExacta: false,
        clientes
    };
}

module.exports = {
    ErrorCliente,
    obtenerClientePorId,
    crearCliente,
    actualizarCliente,
    cambiarEstadoCliente,
    listarClientes,
    buscarClientesRapido
};