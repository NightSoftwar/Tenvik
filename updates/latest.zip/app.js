'use strict';

/*
    dotenv debe cargar antes de usar process.env.
*/
require('dotenv').config();

const fs = require('node:fs');
const path = require('node:path');
const express = require('express');

const {
    db,
    verificarConexionBaseDeDatos,
    cerrarConexionesBaseDeDatos
} = require('./src/config/database');

const {
    aplicarMigraciones
} = require('./src/services/migraciones.service');

const {
    obtenerEstadoActualizacion,
    buscarActualizacion,
    aplicarActualizacion,
    iniciarRevisionAutomaticaActualizaciones
} = require('./src/services/actualizacion.service');

/* =========================================================
   LICENCIAS
   ========================================================= */

const {
    asegurarIdentidadInstalacion
} = require('./src/modules/licencias/identidad_instalacion.service');

const {
    asegurarRespaldoLicenciaFirmada
} = require('./src/modules/licencias/licencia_persistente.service');

const {
    asegurarHistorialLicenciasPersistente
} = require('./src/modules/licencias/historial_persistente.service');

const {
    obtenerEstadoActivacion,
    actualizarUltimoInicio,
    crearSolicitudActivacion,
    validarLicenciaLocal
} = require('./src/modules/licencias/licencias.service');

const {
    verificarAccesoPorLicencia
} = require('./src/middleware/licencia.middleware');

const {
    importarLicenciaFirmada,
    ErrorLicencia
} = require('./src/modules/licencias/importar_licencia.service');

/* =========================================================
   NEGOCIO
   ========================================================= */

const {
    ErrorNegocio,
    obtenerConfiguracionNegocio,
    guardarConfiguracionInicialNegocio
} = require('./src/modules/negocio/negocio.service');

/* =========================================================
   AUTENTICACIÓN
   ========================================================= */

const {
    ErrorContrasena
} = require('./src/modules/autenticacion/contrasenas.service');

const {
    ErrorUsuario,

    crearPropietarioInicial,
    autenticarUsuario,

    obtenerDestinoInicialSegunRol,

    listarUsuarios,
    obtenerUsuarioPorId,

    crearCajero,
    actualizarCajero,

    restablecerContrasenaCajero,

    bloquearCajero,
    reactivarCajero
} = require('./src/modules/autenticacion/usuarios.service');

const {
    obtenerTokenSesionDesdeSolicitud,
    establecerCookieSesion,
    limpiarCookieSesion,
    crearSesion,
    obtenerSesionActivaPorToken,
    cerrarSesionPorToken,
    cerrarSesionesVencidas,
    cerrarSesionesAbiertas
} = require('./src/modules/autenticacion/sesiones.service');
const {
    requerirSesion,
    requerirRoles
} = require('./src/modules/autenticacion/autenticacion.middleware');
const {
    ErrorImpresion,
    obtenerConfiguracionImpresion,
    actualizarConfiguracionImpresion,
    imprimirPruebaConfiguracion,
    imprimirTicketVentaPorId,
    imprimirTicketDevolucionPorId
} = require('./src/modules/impresion/impresion.service');
const {
    generarPdfArqueo
} = require('./src/services/pdf/arqueoCajaPdf');
const permitirGestionUsuarios = requerirRoles(
    'PROPIETARIO'
);

const permitirGestionCaja = requerirRoles(
    'PROPIETARIO'
);
const permitirGestionSeguridadOperativa = requerirRoles(
    'PROPIETARIO'
);

function obtenerNombreUsuario(usuario = {}) {
    return String(
        usuario?.nombreCompleto ||
        usuario?.nombre_completo ||
        usuario?.nombre ||
        usuario?.usuario ||
        usuario?.username ||
        'Usuario local'
    );
}

const permitirAccesoVentas = requerirRoles(
    'PROPIETARIO',
    'CAJERO'
);
const permitirGestionAdministrativaClientes = requerirRoles(
    'PROPIETARIO'
);
const permitirConfiguracionFinanciera = requerirRoles(
    'PROPIETARIO'
);
const permitirGestionAdministrativaInventario = requerirRoles(
    'PROPIETARIO'
);
const permitirConsultaAdministrativaVentas = requerirRoles(
    'PROPIETARIO'
);
const {
    ErrorCliente,
    obtenerClientePorId,
    crearCliente,
    actualizarCliente,
    cambiarEstadoCliente,
    listarClientes,
    buscarClientesRapido
} = require('./src/modules/clientes/clientes.service');
const {
    ErrorFinanzas,

    obtenerResumenFinanciero,
    listarTasasCambiarias,
    registrarTasaCambiaria,
    actualizarConfiguracionFinanciera
} = require('./src/modules/finanzas/finanzas.service');
const {
    ErrorInventario,

    listarProductos,
    obtenerProductoPorId,
    buscarProductosParaVenta,

    crearProducto,
    actualizarProducto,
    cambiarEstadoProducto,
    ajustarExistenciaProducto
} = require('./src/modules/inventario/inventario.service');
const {
    ErrorCaja,

    obtenerEstadoCajaPrincipal,
    obtenerResumenArqueoCajaPrincipal,
    abrirCajaPrincipal,
    cerrarCajaPrincipal,
    finalizarArqueoCajaPrincipal,
    obtenerArqueoCajaPorId
} = require('./src/modules/caja/caja.service');
const {
    ErrorVentas,
    confirmarVenta,
    listarVentas,
    obtenerVentaPorId,
    obtenerVentaPorNumeroFactura
} = require('./src/modules/ventas/ventas.service');
const {
    ErrorSeguridadOperativa,
    obtenerEstadoClaveAutorizacion,
    guardarClaveAutorizacion,
    verificarClaveAutorizacion
} = require('./src/modules/seguridad/seguridad-operativa.service');
const {
    ErrorDevoluciones,
    obtenerVentaParaDevolucion,
    obtenerVentaParaDevolucionPorNumeroFactura,
    confirmarDevolucion
} = require('./src/modules/devoluciones/devoluciones.service');
const app = express();

function generarNombrePdfArqueo(turno, fechaHora) {
    let fecha = new Date();

    if (fechaHora) {
        const fechaIso = new Date(fechaHora);

        if (!Number.isNaN(fechaIso.valueOf())) {
            fecha = fechaIso;
        } else {
            const coincidencia = String(fechaHora).match(/(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})/);
            if (coincidencia) {
                const [_, dia, mes, anio] = coincidencia;
                fecha = new Date(`${anio}-${mes.padStart(2, '0')}-${dia.padStart(2, '0')}`);
            }
        }
    }

    const fechaStr = fecha.toISOString().slice(0, 10);
    const etiquetaTurno = String(turno || 'cuadre').replace(/[^a-z0-9_-]/gi, '_');
    return `cuadre_${fechaStr}_${etiquetaTurno}`.slice(0, 120);
}

async function guardarPdfArqueoEnDisco(pdfBuffer, { arqueoId, turno, fechaHora } = {}) {
    const directorio = path.join(__dirname, 'data', 'pdfs', 'arqueos');
    await fs.promises.mkdir(directorio, { recursive: true });

    const nombreArchivo = `${generarNombrePdfArqueo(turno, fechaHora)}.pdf`;
    const rutaCompleta = path.join(directorio, nombreArchivo);

    await fs.promises.writeFile(rutaCompleta, pdfBuffer);

    if (arqueoId) {
        try {
            await db.execute(
                'UPDATE arqueos_caja_locales SET pdf_ruta = ? WHERE id = ?',
                [rutaCompleta, arqueoId]
            );
        } catch (error) {
            console.error('No se pudo actualizar la ruta del PDF del arqueo:', error);
        }
    }

    return {
        rutaCompleta,
        nombreArchivo
    };
}

const APP_NAME = process.env.APP_NAME || 'Tenvik';

const APP_PORT =
    Number.parseInt(process.env.APP_PORT, 10) || 3000;

const APP_HOST =
    process.env.APP_HOST || '0.0.0.0';

const carpetaPublica = path.join(
    __dirname,
    'public'
);

const archivoConfiguracionInicial = path.join(
    carpetaPublica,
    'configuracion-inicial.html'
);

const archivoInicioSesion = path.join(
    carpetaPublica,
    'iniciar-sesion.html'
);

const archivoPanel = path.join(
    carpetaPublica,
    'panel.html'
);
const archivoCaja = path.join(
    carpetaPublica,
    'caja.html'
);

const archivoVentas = path.join(
    carpetaPublica,
    'ventas.html'
);

const archivoUsuarios = path.join(
    carpetaPublica,
    'usuarios.html'
);
const archivoConfiguracionSistema = path.join(
    carpetaPublica,
    'configuracion.html'
);
const archivoInventario = path.join(
    carpetaPublica,
    'inventario.html'
);
const archivoReportes = path.join(
    carpetaPublica,
    'reportes.html'
);
let estadoMigraciones = {
    habilitado: false,
    total: 0,
    aplicadasAhora: []
};

app.disable('x-powered-by');

app.use(express.json({
    limit: '1mb'
}));

app.use(express.urlencoded({
    extended: true,
    limit: '1mb'
}));

/* =========================================================
   FUNCIONES GENERALES DE ACCESO
   ========================================================= */

function obtenerDestinoSegunContexto(contexto) {
    if (!contexto.licenciaActiva) {
        return '/activacion';
    }

    if (!contexto.negocioConfigurado) {
        return '/configuracion-inicial';
    }

    if (!contexto.sesion) {
        return '/iniciar-sesion';
    }

    return obtenerDestinoInicialSegunRol(
        contexto.sesion.usuario.rol
    );
}
async function obtenerContextoAcceso(req) {
    const resultadoLicencia =
        await validarLicenciaLocal();

    const licencia =
        resultadoLicencia.licencia;

    const licenciaActiva = Boolean(
        resultadoLicencia.permiteAcceso &&
        licencia?.estado === 'ACTIVA'
    );

    /*
        Si la licencia no permite acceso, no consultamos negocio
        ni sesión. La instalación debe ir a /activacion.
    */
    if (!licenciaActiva) {
        return {
            licenciaActiva: false,
            licencia,
            fechaActual:
                resultadoLicencia.fechaActual,
            negocioConfigurado: false,
            negocio: null,
            sesion: null
        };
    }

    const negocio =
        await obtenerConfiguracionNegocio();

    const negocioConfigurado =
        negocio.estado_configuracion === 'COMPLETADA';

    /*
        Durante la configuración inicial todavía no existe un
        propietario ni debe existir una sesión válida.
    */
    if (!negocioConfigurado) {
        return {
            licenciaActiva: true,
            licencia,
            fechaActual:
                resultadoLicencia.fechaActual,
            negocioConfigurado: false,
            negocio,
            sesion: null
        };
    }

    const tokenSesion =
        obtenerTokenSesionDesdeSolicitud(req);

    const sesion = tokenSesion
        ? await obtenerSesionActivaPorToken(
            tokenSesion
        )
        : null;

    return {
        licenciaActiva: true,
        licencia,
        fechaActual:
            resultadoLicencia.fechaActual,
        negocioConfigurado: true,
        negocio,
        sesion
    };
}

function responderLicenciaNoActiva(
    res,
    contexto
) {
    return res.status(403).json({
        ok: false,
        codigo: 'LICENCIA_NO_ACTIVA',
        mensaje:
            'La licencia de Tenvik no está activa. Revise la pantalla de activación.',
        licencia: contexto.licencia
    });
}

function responderErrorControlado(
    res,
    error,
    mensajeGenerico
) {
    const esErrorControlado =
        error instanceof ErrorNegocio ||
        error instanceof ErrorUsuario ||
        error instanceof ErrorContrasena ||
        error instanceof ErrorLicencia ||
        error instanceof ErrorCliente ||
        error instanceof ErrorFinanzas ||
        error instanceof ErrorInventario ||
        error instanceof ErrorCaja ||
        error instanceof ErrorVentas ||
        error instanceof ErrorSeguridadOperativa ||
        error instanceof ErrorImpresion ||
        error instanceof ErrorDevoluciones;

    if (error?.codigo === 'CREDENCIALES_INVALIDAS') {
        return res.status(401).json({
            ok: false,
            codigo: error.codigo,
            mensaje: error.message
        });
    }

    if (
        error?.codigo === 'USUARIO_SIN_PERMISO' ||
        error?.codigo === 'USUARIO_NO_PROPIETARIO' ||
        error?.codigo === 'CLAVE_AUTORIZACION_INVALIDA'
    ) {
        return res.status(403).json({
            ok: false,
            codigo: error.codigo,
            mensaje: error.message
        });
    }

    if (
        error?.codigo === 'CLIENTE_NO_ENCONTRADO' ||
        error?.codigo === 'USUARIO_NO_ENCONTRADO' ||
        error?.codigo === 'PRODUCTO_NO_ENCONTRADO'
    ) {
        return res.status(404).json({
            ok: false,
            codigo: error.codigo,
            mensaje: error.message
        });
    }

    if (
        error?.codigo === 'NEGOCIO_YA_CONFIGURADO' ||
        error?.codigo === 'USUARIOS_YA_EXISTEN' ||
        error?.codigo === 'CLIENTE_IDENTIFICACION_DUPLICADA' ||
        error?.codigo === 'USUARIO_DUPLICADO' ||
        error?.codigo === 'PRODUCTO_DUPLICADO' ||
        error?.codigo === 'CAJA_YA_ABIERTA' ||
        error?.codigo === 'CAJA_SIN_TURNO_ABIERTO' ||
        error?.codigo === 'CAJA_ABIERTO_OTRO_DIA' ||
        error?.codigo === 'CAJA_CERRADA_PENDIENTE_ARQUEO' ||
        error?.codigo === 'AJUSTE_SIN_CAMBIOS' ||
        error?.codigo === 'VENTA_CAJA_CERRADA' ||
        error?.codigo === 'VENTA_STOCK_INSUFICIENTE' ||
        error?.codigo === 'VENTA_PAGO_INSUFICIENTE' ||
        error?.codigo === 'VENTA_SECUENCIA_NO_CONFIGURADA' ||
        error?.codigo === 'CLAVE_AUTORIZACION_NO_CONFIGURADA' ||
        error?.codigo === 'DEVOLUCION_CAJA_CERRADA'
    ) {
        return res.status(409).json({
            ok: false,
            codigo: error.codigo,
            mensaje: error.message
        });
    }

    if (esErrorControlado) {
        return res.status(400).json({
            ok: false,
            codigo: error.codigo || 'DATOS_INVALIDOS',
            mensaje: error.message
        });
    }

    console.error(
        mensajeGenerico,
        error.message
    );

    return res.status(500).json({
        ok: false,
        codigo: 'ERROR_INTERNO',
        mensaje:
            'No fue posible completar la operación. Intenta nuevamente.'
    });
}

async function enviarVistaProtegida(
    req,
    res,
    destinoEsperado,
    archivoVista
) {
    try {
        const contexto =
            await obtenerContextoAcceso(req);

        const destino =
            obtenerDestinoSegunContexto(contexto);

        if (destino !== destinoEsperado) {
            return res.redirect(destino);
        }

        return res.sendFile(archivoVista);
    } catch (error) {
        console.error(
            'Error preparando vista protegida:',
            error.message
        );

        return res.status(500).send(
            'No fue posible preparar esta pantalla de Tenvik.'
        );
    }
}

/* =========================================================
   RUTAS PÚBLICAS DE LICENCIA
   ========================================================= */

/*
    Esta ruta debe seguir pública porque la pantalla de
    activación necesita conocer instalación y licencia.
*/
app.get('/api/licencia/estado', async (_req, res) => {
    try {
        const estadoActivacion =
            await obtenerEstadoActivacion();

        return res.status(200).json({
            ok: true,
            instalacion:
                estadoActivacion.instalacion,
            licencia:
                estadoActivacion.licencia,
            fechaActual:
                estadoActivacion.fechaActual
        });
    } catch (error) {
        console.error(
            'Error consultando estado de licencia:',
            error.message
        );

        return res.status(500).json({
            ok: false,
            mensaje:
                'No fue posible consultar el estado de licencia.'
        });
    }
});

/*
    Importa una licencia emitida por Ryze Corporation.

    La licencia se valida antes de guardarse:
    - firma Ed25519;
    - UUID de instalación;
    - código TVK;
    - huella de equipo;
    - historial de créditos;
    - vigencia.
*/
app.post('/api/licencia/importar', async (req, res) => {
    try {
        const resultado =
            await importarLicenciaFirmada(req.body);

        return res.status(201).json({
            ok: true,
            permiteAcceso:
                resultado.permiteAcceso,
            licencia: resultado.licencia,
            mensaje:
                resultado.permiteAcceso
                    ? 'Licencia importada y activada correctamente.'
                    : 'La licencia fue importada, pero no está activa según su vigencia actual.'
        });
    } catch (error) {
        if (error instanceof ErrorLicencia) {
            return res.status(400).json({
                ok: false,
                codigo: error.codigo,
                mensaje: error.message
            });
        }

        console.error(
            'Error importando licencia:',
            error.message
        );

        return res.status(500).json({
            ok: false,
            codigo: 'ERROR_IMPORTACION',
            mensaje:
                'No fue posible importar la licencia. Intenta nuevamente.'
        });
    }
});

/*
    Descarga una solicitud de activación.

    Esta ruta está disponible cuando:
    - no hay licencia;
    - la licencia venció;
    - la licencia está inválida y requiere revisión.

    Si existe una licencia activa, la renovación futura se
    gestionará desde Configuración → Licencia.
*/
app.get('/api/licencia/solicitud', async (_req, res) => {
    try {
        const estadoActivacion =
            await obtenerEstadoActivacion();

        const estadoLicencia =
            estadoActivacion.licencia.estado;

        const estadosPermitidos = [
            'SIN_LICENCIA',
            'VENCIDA',
            'INVALIDA'
        ];

        if (!estadosPermitidos.includes(estadoLicencia)) {
            const licenciaActiva =
                estadoLicencia === 'ACTIVA';

            return res.status(
                licenciaActiva ? 409 : 403
            ).json({
                ok: false,
                codigo: licenciaActiva
                    ? 'LICENCIA_ACTIVA'
                    : 'SOLICITUD_NO_DISPONIBLE',
                mensaje: licenciaActiva
                    ? 'Esta instalación ya tiene una licencia activa. Las renovaciones se gestionarán desde Configuración → Licencia.'
                    : 'No es posible generar una solicitud de activación con el estado actual de la licencia.'
            });
        }

        const solicitud =
            await crearSolicitudActivacion();

        const codigoSeguro = solicitud.instalacion
            .codigo_instalacion
            .replace(/[^A-Z0-9-]/g, '');

        const nombreArchivo =
            `solicitud-activacion-${codigoSeguro}.tenvikreq`;

        res.setHeader(
            'Cache-Control',
            'no-store'
        );

        return res
            .status(200)
            .attachment(nombreArchivo)
            .type('application/json')
            .send(
                `${JSON.stringify(
                    solicitud,
                    null,
                    2
                )}\n`
            );
    } catch (error) {
        console.error(
            'Error generando solicitud de activación:',
            error.message
        );

        return res.status(500).json({
            ok: false,
            mensaje:
                'No fue posible generar la solicitud de activación.'
        });
    }
});

/*
    Pantalla pública de activación.
*/
app.get('/activacion', (_req, res) => {
    return res.sendFile(
        path.join(
            carpetaPublica,
            'activacion.html'
        )
    );
});

/* =========================================================
   ENTRADA INTELIGENTE DE TENVIK
   ========================================================= */

/*
    La raíz nunca muestra directamente el panel.

    Decide automáticamente:
    licencia → configuración de negocio → sesión → panel.
*/
app.get('/', async (req, res) => {
    try {
        const contexto =
            await obtenerContextoAcceso(req);

        return res.redirect(
            obtenerDestinoSegunContexto(contexto)
        );
    } catch (error) {
        console.error(
            'Error resolviendo la entrada principal:',
            error.message
        );

        return res.status(500).send(
            'No fue posible iniciar Tenvik correctamente.'
        );
    }
});
/* =========================================================
   IMPRESIÓN LOCAL
   ========================================================= */
app.post(
    '/api/impresion/venta/:id',
    requerirSesion,
    permitirGestionSeguridadOperativa,
    async (req, res) => {
        try {
            const resultado =
                await imprimirTicketVentaPorId(
                    req.params.id,
                    {
                        tipoCopia:
                            req.body?.tipoCopia || 'REIMPRESION'
                    }
                );

            return res.json({
                ok: true,
                mensaje:
                    'Ticket de venta enviado correctamente.',
                impresion: resultado
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error imprimiendo ticket de venta:'
            );
        }
    }
);
app.post(
    '/api/impresion/devolucion/:id',
    requerirSesion,
    permitirAccesoVentas,
    async (req, res) => {
        try {
            const resultado =
                await imprimirTicketDevolucionPorId(
                    req.params.id,
                    {
                        tipoCopia:
                            req.body?.tipoCopia || 'DEVOLUCION'
                    }
                );

            return res.json({
                ok: true,
                mensaje:
                    'Comprobante de devolución enviado correctamente.',
                impresion: resultado
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error imprimiendo comprobante de devolución:'
            );
        }
    }
);
app.post(
    '/api/impresion/prueba',
    requerirSesion,
    permitirGestionSeguridadOperativa,
    async (req, res) => {
        try {
            const resultado =
                await imprimirPruebaConfiguracion();

            return res.json({
                ok: true,
                mensaje:
                    'Prueba de impresión enviada correctamente.',
                impresion: resultado
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error imprimiendo prueba:'
            );
        }
    }
);
/* =========================================================
   IMPRESIÓN LOCAL
   ========================================================= */

app.get(
    '/api/impresion/configuracion',
    requerirSesion,
    permitirGestionSeguridadOperativa,
    async (req, res) => {
        try {
            const configuracion =
                await obtenerConfiguracionImpresion();

            return res.json({
                ok: true,
                configuracion
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error cargando configuración de impresión:'
            );
        }
    }
);

app.put(
    '/api/impresion/configuracion',
    requerirSesion,
    permitirGestionSeguridadOperativa,
    async (req, res) => {
        try {
            const usuarioResponsableId =
                req.usuario?.id || null;

            const configuracion =
                await actualizarConfiguracionImpresion(
                    req.body || {},
                    usuarioResponsableId
                );

            return res.json({
                ok: true,
                mensaje:
                    'Configuración de impresión actualizada correctamente.',
                configuracion
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error guardando configuración de impresión:'
            );
        }
    }
);

app.post(
    '/api/impresion/prueba',
    requerirSesion,
    permitirGestionSeguridadOperativa,
    async (req, res) => {
        try {
            const resultado =
                await imprimirPruebaConfiguracion();

            return res.json({
                ok: true,
                mensaje:
                    'Prueba de impresión enviada correctamente.',
                impresion: resultado
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error imprimiendo prueba:'
            );
        }
    }
);
/*
    Solo se permite si:
    - La licencia está activa.
    - El negocio todavía no fue configurado.
*/
app.get('/configuracion-inicial', async (req, res) => {
    return enviarVistaProtegida(
        req,
        res,
        '/configuracion-inicial',
        archivoConfiguracionInicial
    );
});

/*
    Solo se permite si:
    - La licencia está activa.
    - El negocio está configurado.
    - No existe una sesión válida.
*/
app.get('/iniciar-sesion', async (req, res) => {
    return enviarVistaProtegida(
        req,
        res,
        '/iniciar-sesion',
        archivoInicioSesion
    );
});

/*
    Solo se permite si:
    - La licencia está activa.
    - El negocio está configurado.
    - Existe una sesión válida.
*/
app.get('/panel', async (req, res) => {
    return enviarVistaProtegida(
        req,
        res,
        '/panel',
        archivoPanel
    );
});

/* =========================================================
   API DE CONTEXTO GENERAL
   ========================================================= */

app.get('/api/aplicacion/estado', async (req, res) => {
    try {
        const contexto =
            await obtenerContextoAcceso(req);

        const estadoActualizacion = await obtenerEstadoActualizacion();

        return res.status(200).json({
            ok: true,

            destino:
                obtenerDestinoSegunContexto(contexto),

            licencia: {
                activa:
                    contexto.licenciaActiva,
                estado:
                    contexto.licencia?.estado ||
                    'NO_DISPONIBLE',
                fechaVencimiento:
                    contexto.licencia?.fecha_vencimiento ||
                    null
            },

            actualizacion: {
                disponible:
                    Boolean(estadoActualizacion?.available),
                ultimaVersion:
                    estadoActualizacion?.remoteVersion || null,
                versionInstalada:
                    estadoActualizacion?.currentVersion || null,
                notas:
                    estadoActualizacion?.notes || null,
                ultimaRevision:
                    estadoActualizacion?.lastCheckedAt || null
            },

            negocio: {
                configurado:
                    contexto.negocioConfigurado,
                nombreComercial:
                    contexto.negocio?.nombre_comercial ||
                    null
            },

            sesion: contexto.sesion
                ? {
                    usuario:
                        contexto.sesion.usuario,
                    venceEn:
                        contexto.sesion.venceEn
                }
                : null
        });
    } catch (error) {
        console.error(
            'Error consultando estado de aplicación:',
            error.message
        );

        return res.status(500).json({
            ok: false,
            mensaje:
                'No fue posible consultar el estado de Tenvik.'
        });
    }
});

/* =========================================================
   CONFIGURACIÓN INICIAL
   ========================================================= */

/*
    Body esperado:

    {
        negocio: {
            nombreComercial,
            razonSocial,
            identificacionFiscal,
            telefono,
            correo,
            direccion,
            monedaPrincipal,
            ivaPorcentaje
        },
        propietario: {
            nombreCompleto,
            usuario,
            correo,
            contrasena,
            confirmarContrasena
        }
    }
*/
app.post(
    '/api/configuracion-inicial',
    async (req, res) => {
        let conexion = null;

        try {
            const contexto =
                await obtenerContextoAcceso(req);

            if (!contexto.licenciaActiva) {
                return responderLicenciaNoActiva(
                    res,
                    contexto
                );
            }

            if (contexto.negocioConfigurado) {
                return res.status(409).json({
                    ok: false,
                    codigo:
                        'NEGOCIO_YA_CONFIGURADO',
                    mensaje:
                        'Esta instalación ya completó la configuración inicial.'
                });
            }

            const datosNegocio =
                req.body?.negocio || {};

            const datosPropietario =
                req.body?.propietario || {};

            conexion =
                await db.getConnection();

            await conexion.beginTransaction();

            /*
                Bloqueamos la única fila de configuración durante
                este proceso para evitar dos configuraciones iniciales
                simultáneas desde navegadores diferentes.
            */
            const [filasConfiguracion] =
                await conexion.execute(`
                    SELECT
                        estado_configuracion
                    FROM configuracion_negocio_local
                    WHERE id = 1
                    FOR UPDATE
                `);

            if (
                filasConfiguracion.length === 0 ||
                filasConfiguracion[0]
                    .estado_configuracion !==
                'PENDIENTE'
            ) {
                throw new ErrorNegocio(
                    'El negocio ya fue configurado previamente.',
                    'NEGOCIO_YA_CONFIGURADO'
                );
            }

            const negocio =
                await guardarConfiguracionInicialNegocio(
                    datosNegocio,
                    conexion
                );

            const propietario =
                await crearPropietarioInicial(
                    datosPropietario,
                    conexion
                );

            const sesion =
                await crearSesion(
                    propietario.id,
                    conexion
                );

            await conexion.commit();

            establecerCookieSesion(
                res,
                sesion.token,
                sesion.venceEn
            );

            return res.status(201).json({
                ok: true,
                mensaje:
                    'Tenvik fue configurado correctamente. Bienvenido.',
                negocio: {
                    nombreComercial:
                        negocio.nombre_comercial,
                    monedaPrincipal:
                        negocio.moneda_principal,
                    ivaPorcentaje:
                        Number(
                            negocio.iva_porcentaje
                        )
                },
                usuario: propietario,
                redireccion: obtenerDestinoInicialSegunRol(
                    propietario.rol
                )
            });
        } catch (error) {
            if (conexion) {
                try {
                    await conexion.rollback();
                } catch (errorRollback) {
                    /*
                        El error principal es el importante.
                    */
                }
            }

            return responderErrorControlado(
                res,
                error,
                'Error durante la configuración inicial:'
            );
        } finally {
            if (conexion) {
                conexion.release();
            }
        }
    }
);

/* =========================================================
   AUTENTICACIÓN
   ========================================================= */

app.post(
    '/api/autenticacion/iniciar-sesion',
    async (req, res) => {
        try {
            const contexto =
                await obtenerContextoAcceso(req);

            if (!contexto.licenciaActiva) {
                return responderLicenciaNoActiva(
                    res,
                    contexto
                );
            }

            if (!contexto.negocioConfigurado) {
                return res.status(409).json({
                    ok: false,
                    codigo:
                        'CONFIGURACION_INICIAL_PENDIENTE',
                    mensaje:
                        'Primero debe completar la configuración inicial del negocio.'
                });
            }

            const identificador =
                req.body?.identificador;

            const contrasena =
                req.body?.contrasena;

            const usuario =
                await autenticarUsuario(
                    identificador,
                    contrasena
                );

            if (
                String(usuario.rol).toUpperCase() === 'CAJERO'
            ) {
                const estadoCaja =
                    await obtenerEstadoCajaPrincipal();

                const turnoActivo =
                    estadoCaja.turnoActivo || null;

                if (!turnoActivo) {
                    return res.status(409).json({
                        ok: false,
                        codigo:
                            'CAJA_PRINCIPAL_CERRADA',
                        mensaje:
                            'La Caja Principal aún está cerrada. No es posible iniciar sesión como cajero hasta que se abra.'
                    });
                }
            }

            const sesion =
                await crearSesion(usuario.id);

            establecerCookieSesion(
                res,
                sesion.token,
                sesion.venceEn
            );

            return res.status(200).json({
                ok: true,
                mensaje:
                    'Inicio de sesión correcto.',
                usuario,
                redireccion: usuario.destinoInicial
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error iniciando sesión:'
            );
        }
    }
);

app.get(
    '/api/autenticacion/sesion',
    async (req, res) => {
        try {
            const contexto =
                await obtenerContextoAcceso(req);

            if (!contexto.licenciaActiva) {
                return responderLicenciaNoActiva(
                    res,
                    contexto
                );
            }

            if (!contexto.negocioConfigurado) {
                return res.status(409).json({
                    ok: false,
                    codigo:
                        'CONFIGURACION_INICIAL_PENDIENTE',
                    mensaje:
                        'La instalación aún no ha sido configurada.'
                });
            }

            if (!contexto.sesion) {
                return res.status(401).json({
                    ok: false,
                    codigo: 'SESION_NO_ACTIVA',
                    mensaje:
                        'No existe una sesión activa.'
                });
            }

            return res.status(200).json({
                ok: true,
                usuario:
                    contexto.sesion.usuario,
                venceEn:
                    contexto.sesion.venceEn
            });
        } catch (error) {
            console.error(
                'Error consultando sesión:',
                error.message
            );

            return res.status(500).json({
                ok: false,
                mensaje:
                    'No fue posible consultar la sesión.'
            });
        }
    }
);

app.post(
    '/api/autenticacion/cerrar-sesion',
    async (req, res) => {
        try {
            const tokenSesion =
                obtenerTokenSesionDesdeSolicitud(req);

            if (tokenSesion) {
                await cerrarSesionPorToken(
                    tokenSesion
                );
            }

            limpiarCookieSesion(res);

            return res.status(200).json({
                ok: true,
                mensaje:
                    'Sesión cerrada correctamente.',
                redireccion: '/iniciar-sesion'
            });
        } catch (error) {
            console.error(
                'Error cerrando sesión:',
                error.message
            );

            limpiarCookieSesion(res);

            return res.status(200).json({
                ok: true,
                mensaje:
                    'Sesión cerrada.'
            });
        }
    }
);

/* =========================================================
   RUTAS YA PROTEGIDAS POR LICENCIA
   ========================================================= */

/*
    A partir de aquí, todo queda protegido cuando:
    LICENSE_ENFORCED=true
*/
app.use(verificarAccesoPorLicencia);
/* =========================================================
   INVENTARIO BÁSICO
   ========================================================= */

/*
    Inventario administrativo v1.

    En esta fase solo manejamos:
    - productos;
    - precio de venta en USD;
    - código interno;
    - código de barras;
    - existencia inicial;
    - stock mínimo;
    - IVA por producto;
    - activar / inactivar.
*/
app.get(
    '/inventario',
    requerirSesion,
    permitirGestionAdministrativaInventario,
    (_req, res) => {
        return res.sendFile(archivoInventario);
    }
);

/* =========================================================
   REPORTES
   ========================================================= */

app.get(
    '/reportes',
    requerirSesion,
    permitirGestionUsuarios,
    (_req, res) => {
        return res.sendFile(archivoReportes);
    }
);

// Servir SPA para rutas anidadas bajo /reportes (p. ej. /reportes/ventas-productos)
/* (se eliminó la ruta comodín /reportes/* para restaurar comportamiento previo) */

/*
    Lista productos con búsqueda, estado y paginación.

    Ejemplo:
    /api/inventario/productos?busqueda=harina&estado=ACTIVO&pagina=1&limite=20
*/
app.get(
    '/api/inventario/productos',
    requerirSesion,
    permitirGestionAdministrativaInventario,
    async (req, res) => {
        try {
            const resultado = await listarProductos({
                busqueda: req.query.busqueda || '',
                estado: req.query.estado || 'ACTIVO',
                pagina: req.query.pagina || 1,
                limite: req.query.limite || 20
            });

            return res.status(200).json({
                ok: true,
                ...resultado
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error listando productos:'
            );
        }
    }
);

/*
    Consulta un producto específico para editarlo.
*/
app.get(
    '/api/inventario/productos/:id',
    requerirSesion,
    permitirGestionAdministrativaInventario,
    async (req, res) => {
        try {
            const producto = await obtenerProductoPorId(
                req.params.id
            );

            return res.status(200).json({
                ok: true,
                producto
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error consultando producto:'
            );
        }
    }
);

/*
    Crear producto con su existencia inicial en el
    Almacén principal.
*/
app.post(
    '/api/inventario/productos',
    requerirSesion,
    permitirGestionAdministrativaInventario,
    async (req, res) => {
        try {
            const producto = await crearProducto(
                req.body || {},
                req.usuario.id
            );

            return res.status(201).json({
                ok: true,
                mensaje:
                    'Producto registrado correctamente.',
                producto
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error registrando producto:'
            );
        }
    }
);

/*
    Editar información básica del producto.

    La existencia no se edita aquí.
    Más adelante habrá una opción simple de ajuste de stock
    para que todo cambio quede registrado como movimiento.
*/
app.put(
    '/api/inventario/productos/:id',
    requerirSesion,
    permitirGestionAdministrativaInventario,
    async (req, res) => {
        try {
            const producto = await actualizarProducto(
                req.params.id,
                req.body || {},
                req.usuario.id
            );

            return res.status(200).json({
                ok: true,
                mensaje:
                    'Producto actualizado correctamente.',
                producto
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error actualizando producto:'
            );
        }
    }
);

/*
    Activar o inactivar un producto.

    Inactivar no elimina el producto ni su historial:
    solamente evita que se ofrezca para venta futura.
*/
app.patch(
    '/api/inventario/productos/:id/estado',
    requerirSesion,
    permitirGestionAdministrativaInventario,
    async (req, res) => {
        try {
            const producto = await cambiarEstadoProducto(
                req.params.id,
                req.body?.estado,
                req.usuario.id
            );

            return res.status(200).json({
                ok: true,
                mensaje:
                    producto.estado === 'ACTIVO'
                        ? 'Producto activado correctamente.'
                        : 'Producto inactivado correctamente.',
                producto
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error cambiando estado del producto:'
            );
        }
    }
);
/* =========================================================
   AJUSTE BÁSICO DE EXISTENCIA
   ========================================================= */

/*
    Ajusta el stock disponible de un producto dentro del
    Almacén principal.

    Modos permitidos:

    ENTRADA:
    Suma mercancía al stock actual.

    SALIDA:
    Resta mercancía al stock actual.
    No permite dejar existencia negativa.

    RECONTEO:
    Establece la cantidad real encontrada físicamente.
*/
app.post(
    '/api/inventario/productos/:id/existencia',
    requerirSesion,
    permitirGestionAdministrativaInventario,
    async (req, res) => {
        try {
            const resultado =
                await ajustarExistenciaProducto(
                    req.params.id,
                    req.body || {},
                    req.usuario.id
                );

            return res.status(200).json({
                ok: true,

                mensaje:
                    'Existencia actualizada correctamente.',

                producto: resultado.producto,
                movimiento: resultado.movimiento
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error ajustando la existencia del producto:'
            );
        }
    }
);
/* =========================================================
   CONFIGURACIÓN FINANCIERA
   ========================================================= */

/*
    Pantalla administrativa exclusiva del Propietario.

    Aquí se configurarán:
    - tasa USD → VES;
    - IVA incluido o no incluido;
    - decimales;
    - métodos de pago;
    - cajas físicas.
*/
app.get(
    '/configuracion',
    requerirSesion,
    permitirConfiguracionFinanciera,
    (_req, res) => {
        return res.sendFile(
            archivoConfiguracionSistema
        );
    }
);

/*
    Resumen que consumirá la pantalla de Configuración.

    Incluye:
    - configuración financiera;
    - tasa vigente;
    - métodos de pago;
    - cajas físicas.
*/
app.get(
    '/api/finanzas/resumen',
    requerirSesion,
    permitirConfiguracionFinanciera,
    async (_req, res) => {
        try {
            const resumen =
                await obtenerResumenFinanciero();

            return res.status(200).json({
                ok: true,
                ...resumen
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error consultando configuración financiera:'
            );
        }
    }
);

/*
    Historial de tasas USD → VES.
*/
app.get(
    '/api/finanzas/tasas',
    requerirSesion,
    permitirConfiguracionFinanciera,
    async (_req, res) => {
        try {
            const tasas =
                await listarTasasCambiarias();

            return res.status(200).json({
                ok: true,
                tasas
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error consultando historial de tasas:'
            );
        }
    }
);

/*
    Registrar una tasa nueva.

    La anterior queda HISTORICA.
    Nunca se borra ni se modifica una tasa usada por ventas.
*/
app.post(
    '/api/finanzas/tasas',
    requerirSesion,
    permitirConfiguracionFinanciera,
    async (req, res) => {
        try {
            const tasa =
                await registrarTasaCambiaria(
                    req.body || {},
                    req.usuario.id
                );

            return res.status(201).json({
                ok: true,
                mensaje:
                    'La tasa referencial fue actualizada correctamente.',
                tasa
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error registrando tasa cambiaria:'
            );
        }
    }
);

/*
    Actualizar cómo Tenvik calcula y presenta los montos.

    Body esperado:

    {
        preciosIncluyenIva: true,
        decimalesUsd: 2,
        decimalesVes: 2
    }
*/
app.put(
    '/api/finanzas/configuracion',
    requerirSesion,
    permitirConfiguracionFinanciera,
    async (req, res) => {
        try {
            const configuracion =
                await actualizarConfiguracionFinanciera(
                    req.body || {}
                );

            return res.status(200).json({
                ok: true,
                mensaje:
                    'La configuración financiera fue actualizada correctamente.',
                configuracion
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error actualizando configuración financiera:'
            );
        }
    }
);
/* =========================================================
   SEGURIDAD OPERATIVA / CLAVE DE AUTORIZACIÓN
   ========================================================= */

/*
    Consulta si ya existe una clave de autorización configurada.

    Solo el propietario puede ver este estado porque forma parte
    de la configuración del sistema.
*/
app.get(
    '/api/seguridad-operativa/clave-autorizacion',
    requerirSesion,
    permitirGestionSeguridadOperativa,
    async (req, res) => {
        try {
            const estadoClave =
                await obtenerEstadoClaveAutorizacion();

            return res.status(200).json({
                ok: true,
                claveAutorizacion: estadoClave
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error consultando clave de autorización:'
            );
        }
    }
);

/*
    Configura o cambia la clave de autorización.

    Primera vez:
    {
        "claveNueva": "1234",
        "confirmarClaveNueva": "1234"
    }

    Cambio posterior:
    {
        "claveActual": "1234",
        "claveNueva": "5678",
        "confirmarClaveNueva": "5678"
    }
*/
app.put(
    '/api/seguridad-operativa/clave-autorizacion',
    requerirSesion,
    permitirGestionSeguridadOperativa,
    async (req, res) => {
        try {
            const resultado =
                await guardarClaveAutorizacion(
                    req.body || {},
                    req.usuario.id
                );

            return res.status(200).json({
                ok: true,
                mensaje: resultado.mensaje,
                claveAutorizacion: {
                    configurada: resultado.configurada,
                    autorizacionHabilitada: resultado.autorizacionHabilitada
                }
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error guardando clave de autorización:'
            );
        }
    }
);

/*
    Verifica la clave de autorización para una acción crítica.

    La puede solicitar un cajero o propietario, pero debe conocer
    la clave configurada por el propietario.

    Ejemplo:
    {
        "clave": "1234",
        "accion": "VER_HISTORIAL_VENTAS",
        "detalle": "Apertura de historial desde POS"
    }
*/
app.post(
    '/api/seguridad-operativa/verificar',
    requerirSesion,
    async (req, res) => {
        try {
            const resultado =
                await verificarClaveAutorizacion(
                    req.body?.clave,
                    req.usuario.id,
                    req.body?.accion,
                    req.body?.detalle
                );

            return res.status(200).json({
                ok: true,
                autorizado: resultado.autorizado,
                accion: resultado.accion,
                mensaje: 'Autorización aprobada.'
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error verificando clave de autorización:'
            );
        }
    }
);/* =========================================================
   DEVOLUCIONES DE VENTAS
   ========================================================= */

app.get(
    '/api/devoluciones/ventas/:id/preparar',
    requerirSesion,
    async (req, res) => {
        try {
            const devolucion =
                await obtenerVentaParaDevolucion(
                    req.params.id
                );

            return res.json({
                ok: true,
                devolucion
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error preparando devolución por venta:'
            );
        }
    }
);
app.post(
    '/api/devoluciones/confirmar',
    requerirSesion,
    permitirAccesoVentas,
    async (req, res) => {
        try {
            await verificarClaveAutorizacion(
                req.body?.clave,
                req.usuario.id,
                'CREAR_DEVOLUCION',
                'Confirmación de devolución de venta desde Punto de Venta.'
            );

            const devolucion =
                await confirmarDevolucion(
                    req.body || {},
                    req.usuario.id
                );

            return res.status(201).json({
                ok: true,
                mensaje:
                    'Devolución registrada correctamente.',
                devolucion
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error confirmando devolución:'
            );
        }
    }
);
app.get(
    '/api/devoluciones/factura/:numeroFactura/preparar',
    requerirSesion,
    async (req, res) => {
        try {
            const devolucion =
                await obtenerVentaParaDevolucionPorNumeroFactura(
                    req.params.numeroFactura
                );

            return res.json({
                ok: true,
                devolucion
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error preparando devolución por factura:'
            );
        }
    }
);
/* =========================================================
   VENTAS / PUNTO DE VENTA
   ========================================================= */

/*
    Pantalla operativa de ventas.

    Acceso permitido:
    - PROPIETARIO
    - CAJERO

    El CAJERO entra aquí al iniciar sesión.
    No tiene acceso a Caja administrativa, Inventario,
    Clientes administrativos, Usuarios ni Configuración.
*/
app.get(
    '/ventas',
    requerirSesion,
    permitirAccesoVentas,
    async (req, res) => {
        try {
            const estadoCaja =
                await obtenerEstadoCajaPrincipal();

            const turnoActivo =
                estadoCaja.turnoActivo || null;

            if (
                !turnoActivo ||
                estadoCaja.turnoAbiertoEnOtroDia
            ) {
                const mensaje = encodeURIComponent(
                    estadoCaja.turnoAbiertoEnOtroDia
                        ? 'La Caja Principal está abierta desde otro día. Debe cerrar y cuadrar la caja para continuar con ventas.'
                        : 'Debe abrir la Caja Principal antes de entrar a Ventas.'
                );

                return res.redirect(
                    `/caja?mensaje=${mensaje}`
                );
            }

            return res.sendFile(archivoVentas);
        } catch (error) {
            console.error(
                'Error preparando pantalla de Ventas:',
                error.message
            );

            return responderErrorControlado(
                res,
                error,
                'Error preparando pantalla de Ventas:'
            );
        }
    }
);
/* =========================================================
   CONTEXTO OPERATIVO DEL PUNTO DE VENTA
   ========================================================= */

/*
    Esta API solo entrega la información necesaria para
    trabajar desde el Punto de Venta.

    No permite:
    - abrir Caja;
    - cerrar Caja;
    - cambiar tasas;
    - modificar inventario;
    - administrar clientes.

    Acceso permitido:
    - PROPIETARIO
    - CAJERO
*/
app.get(
    '/api/ventas/contexto-operacion',
    requerirSesion,
    permitirAccesoVentas,
    async (req, res) => {
        try {
            const [
                estadoCaja,
                resumenFinanciero
            ] = await Promise.all([
                obtenerEstadoCajaPrincipal(),
                obtenerResumenFinanciero()
            ]);

            const turnoActivo =
                estadoCaja.turnoActivo || null;

            const puedeVender = Boolean(
                turnoActivo && !estadoCaja.turnoAbiertoEnOtroDia
            );

            const configuracionFinanciera =
                resumenFinanciero.configuracion || {};

            const preciosIncluyenIva =
                configuracionFinanciera.preciosIncluyenIva === true ||
                configuracionFinanciera.preciosIncluyenIva === 1 ||
                configuracionFinanciera.preciosIncluyenIva === '1' ||
                configuracionFinanciera.preciosIncluyenIva === 'true';

            return res.status(200).json({
                ok: true,

                usuario: {
                    id: req.usuario.id,

                    nombreCompleto:
                        req.usuario.nombreCompleto ||
                        req.usuario.nombre_completo ||
                        req.usuario.nombre ||
                        null,

                    usuario:
                        req.usuario.usuario || null,

                    rol:
                        req.usuario.rol
                },

                caja:
                    estadoCaja.caja || null,

                turnoActivo,

                tasaVigente:
                    estadoCaja.tasaVigente ||
                    resumenFinanciero.tasaVigente ||
                    null,

                configuracionFinanciera: {
                    ivaPorcentaje: Number(
                        configuracionFinanciera.ivaPorcentaje || 0
                    ),

                    preciosIncluyenIva,

                    decimalesUsd: Number(
                        configuracionFinanciera.decimalesUsd || 2
                    ),

                    decimalesVes: Number(
                        configuracionFinanciera.decimalesVes || 2
                    )
                },

                puedeVender,

                redireccion:
                    estadoCaja.turnoAbiertoEnOtroDia
                        ? '/caja'
                        : null,

                codigo:
                    estadoCaja.turnoAbiertoEnOtroDia
                        ? 'CAJA_ABIERTO_OTRO_DIA'
                        : null,

                mensaje: puedeVender
                    ? 'Caja disponible para registrar ventas.'
                    : estadoCaja.turnoAbiertoEnOtroDia
                        ? 'La caja está abierta desde otro día. Debe cerrar y cuadrar la caja antes de abrir el módulo de ventas.'
                        : 'No existe un turno abierto. Debe abrir Caja desde el módulo administrativo.'
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error consultando el contexto operativo de Ventas:'
            );
        }
    }
);
/* =========================================================
   PRODUCTOS DISPONIBLES PARA PUNTO DE VENTA
   ========================================================= */

/*
    Búsqueda exclusiva para el Punto de Venta.

    Permitida para:
    - PROPIETARIO
    - CAJERO

    No entrega datos administrativos sensibles como:
    - costo de referencia;
    - movimientos;
    - responsables;
    - historial interno.
*/
app.get(
    '/api/ventas/productos/buscar',
    requerirSesion,
    permitirAccesoVentas,
    async (req, res) => {
        try {
            const consulta = String(
                req.query.q || ''
            ).trim();

            /*
                F2 abre vacío y luego busca cuando el cajero
                escriba. Por eso una consulta vacía devuelve
                una lista vacía, no todo el inventario.
            */
            if (!consulta) {
                return res.status(200).json({
                    ok: true,
                    productos: [],
                    productoExacto: null
                });
            }

            const productos =
                await buscarProductosParaVenta(
                    consulta,
                    {
                        limite:
                            req.query.limite || 12
                    }
                );

            const codigoBuscado = consulta
                .toUpperCase()
                .replace(/\s+/g, '');

            /*
                Sirve para el flujo rápido:

                Código + Enter
                → si existe una coincidencia exacta,
                  se agrega directamente al carrito.

                F2
                → usa la lista completa de productos.
            */
            const productoExacto =
                productos.find((producto) => {
                    const codigoInterno = String(
                        producto.codigoInterno || ''
                    )
                        .toUpperCase()
                        .replace(/\s+/g, '');

                    const codigoBarras = String(
                        producto.codigoBarras || ''
                    )
                        .toUpperCase()
                        .replace(/\s+/g, '');

                    return (
                        codigoInterno === codigoBuscado ||
                        codigoBarras === codigoBuscado
                    );
                }) || null;

            return res.status(200).json({
                ok: true,
                productos,
                productoExacto
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error buscando productos para Ventas:'
            );
        }
    }
);
/*
    Confirma una venta real.

    Este endpoint:
    - genera número de factura;
    - guarda encabezado;
    - guarda productos vendidos;
    - guarda métodos de pago;
    - descuenta inventario;
    - registra movimientos tipo VENTA.

    La factura queda registrada aunque luego no se imprima.
*/
/*
    Lista ventas registradas.

    Sirve para historial, reimpresión, consulta de pagos
    y futuras devoluciones.
*/
app.get(
    '/api/ventas',
    requerirSesion,
    permitirConsultaAdministrativaVentas,
    async (req, res) => {
        try {
            const ventas =
                await listarVentas({
                    limite: req.query.limite
                });

            return res.json({
                ok: true,
                ventas
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error listando ventas:'
            );
        }
    }
);

/*
    Reportes: ventas por producto (agregación desde ventas_detalles)
    Query params: desde=YYYY-MM-DD, hasta=YYYY-MM-DD, search=texto, orden=asc|desc, limite=n
*/
app.get(
    '/api/reportes/ventas-productos',
    requerirSesion,
    permitirAccesoVentas,
    async (req, res) => {
        try {
            const desde = req.query.desde ? String(req.query.desde).trim() : null;
            const hasta = req.query.hasta ? String(req.query.hasta).trim() : null;
            const search = req.query.search ? String(req.query.search).trim() : null;
            const orden = req.query.orden === 'asc' ? 'ASC' : 'DESC';
            const limite = Number.isInteger(Number(req.query.limite)) && Number(req.query.limite) > 0 ? Math.min(1000, Number(req.query.limite)) : 200;

            const where = [];
            const params = [];

            if (desde) {
                where.push('detalle.creado_en >= ?');
                params.push(`${desde} 00:00:00`);
            }

            if (hasta) {
                where.push('detalle.creado_en <= ?');
                params.push(`${hasta} 23:59:59`);
            }

            if (search) {
                where.push('(detalle.nombre_producto LIKE ? OR detalle.codigo_producto LIKE ?)');
                params.push(`%${search}%`, `%${search}%`);
            }

            const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';

            const sql = `
                SELECT
                    detalle.producto_id AS productoId,
                    detalle.codigo_producto AS codigoProducto,
                    detalle.nombre_producto AS nombreProducto,
                    p.codigo_interno AS codigoInternoActual,
                    p.nombre AS nombreActual,
                    SUM(COALESCE(detalle.cantidad,0) - COALESCE(detalle.cantidad_devuelta,0)) AS unidades,
                    SUM(COALESCE(detalle.total_bs,0)) AS ingresoBs,
                    SUM(COALESCE(detalle.total_usd,0)) AS ingresoUsd
                FROM ventas_detalles AS detalle
                LEFT JOIN productos AS p ON p.id = detalle.producto_id
                ${whereSql}
                GROUP BY detalle.producto_id, detalle.codigo_producto, detalle.nombre_producto, p.codigo_interno, p.nombre
                ORDER BY unidades ${orden}
                LIMIT ${limite}
            `;

            const [rows] = await db.execute(sql, params);

            return res.json({ ok: true, rows });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error consultando reportes de ventas por producto:'
            );
        }
    }
);

app.get(
    '/api/panel/resumen',
    requerirSesion,
    async (_req, res) => {
        try {
            const calcularCambioPorcentaje = (actual, previo) => {
                if (previo === 0) {
                    return actual > 0 ? 100 : 0;
                }

                return Number((((actual - previo) / previo) * 100).toFixed(0));
            };

            const [ventasDia] = await db.execute(`
                SELECT
                    COUNT(*) AS transacciones,
                    COALESCE(SUM(total_usd), 0) AS total_usd
                FROM ventas
                WHERE estado = 'CONFIRMADA'
                    AND DATE(creado_en) = CURDATE()
            `);

            const [ventasAyer] = await db.execute(`
                SELECT COALESCE(SUM(total_usd), 0) AS total_usd
                FROM ventas
                WHERE estado = 'CONFIRMADA'
                    AND DATE(creado_en) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)
            `);

            const [ultimasVentas] = await db.execute(`
                SELECT
                    id,
                    numero_factura AS numeroFactura,
                    cliente_nombre AS clienteNombre,
                    total_usd AS totalUsd,
                    creado_en AS creadoEn
                FROM ventas
                WHERE estado = 'CONFIRMADA'
                ORDER BY id DESC
                LIMIT 4
            `);

            const [clientesSemana] = await db.execute(`
                SELECT COUNT(*) AS total
                FROM clientes_locales
                WHERE DATE(creado_en) >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
            `);

            const [clientesSemanaAnterior] = await db.execute(`
                SELECT COUNT(*) AS total
                FROM clientes_locales
                WHERE DATE(creado_en)
                    BETWEEN DATE_SUB(DATE_SUB(CURDATE(), INTERVAL 6 DAY), INTERVAL 7 DAY)
                    AND DATE_SUB(CURDATE(), INTERVAL 7 DAY)
            `);

            const [stockCritico] = await db.execute(`
                SELECT COUNT(*) AS total
                FROM (
                    SELECT p.id AS producto_id
                    FROM productos AS p
                    LEFT JOIN existencias_producto AS ep
                        ON ep.producto_id = p.id
                    WHERE p.estado = 'ACTIVO'
                    GROUP BY p.id, p.stock_minimo
                    HAVING COALESCE(SUM(ep.disponible), 0) <= p.stock_minimo
                ) AS criticos
            `);

            const [alertasProductos] = await db.execute(`
                SELECT
                    p.nombre AS nombre,
                    COALESCE(SUM(ep.disponible), 0) AS disponible,
                    p.stock_minimo AS stock_minimo
                FROM productos AS p
                LEFT JOIN existencias_producto AS ep
                    ON ep.producto_id = p.id
                WHERE p.estado = 'ACTIVO'
                GROUP BY p.id, p.nombre, p.stock_minimo
                HAVING COALESCE(SUM(ep.disponible), 0) <= p.stock_minimo
                ORDER BY COALESCE(SUM(ep.disponible), 0) ASC, p.nombre ASC
                LIMIT 3
            `);

            const fechaInicioSemana = new Date();
            const diaSemana = (fechaInicioSemana.getDay() + 6) % 7;
            fechaInicioSemana.setDate(fechaInicioSemana.getDate() - diaSemana);
            fechaInicioSemana.setHours(0, 0, 0, 0);

            const fechaFinSemana = new Date(fechaInicioSemana);
            fechaFinSemana.setDate(fechaInicioSemana.getDate() + 6);
            fechaFinSemana.setHours(23, 59, 59, 999);

            const formatearFechaISO = (fecha) => {
                const offset = fecha.getTimezoneOffset();
                const local = new Date(fecha.getTime() - (offset * 60000));
                return local.toISOString().slice(0, 10);
            };

            const [ventasSemanaRows] = await db.execute(`
                SELECT
                    DATE(creado_en) AS fecha,
                    COALESCE(SUM(total_usd), 0) AS total
                FROM ventas
                WHERE estado = 'CONFIRMADA'
                    AND DATE(creado_en) BETWEEN ? AND ?
                GROUP BY DATE(creado_en)
            `, [
                formatearFechaISO(fechaInicioSemana),
                formatearFechaISO(fechaFinSemana)
            ]);

            const ventasPorFecha = new Map(
                ventasSemanaRows.map((fila) => [fila.fecha, Number(fila.total || 0)])
            );

            const diasSemana = [
                { clave: 'L', label: 'Lun' },
                { clave: 'M', label: 'Mar' },
                { clave: 'X', label: 'Mié' },
                { clave: 'J', label: 'Jue' },
                { clave: 'V', label: 'Vie' },
                { clave: 'S', label: 'Sáb' },
                { clave: 'D', label: 'Dom' }
            ];

            const ventasSemana = diasSemana.map((dia, indice) => {
                const fecha = new Date(fechaInicioSemana);
                fecha.setDate(fechaInicioSemana.getDate() + indice);
                const fechaISO = formatearFechaISO(fecha);
                const total = Number(ventasPorFecha.get(fechaISO) || 0);

                return {
                    dia: dia.label,
                    fecha: fechaISO,
                    total
                };
            });

            const maxVenta = ventasSemana.reduce(
                (max, item) => Math.max(max, item.total),
                0
            );

            const ventasSemanaConPorcentaje = ventasSemana.map((item) => ({
                ...item,
                porcentaje: maxVenta > 0 ? Math.round((item.total / maxVenta) * 100) : 0,
                maximo: maxVenta > 0 && item.total === maxVenta
            }));

            const [topProductosSemanaRows] = await db.execute(`
                SELECT
                    detalle.producto_id AS productoId,
                    COALESCE(p.codigo_interno, detalle.codigo_producto) AS sku,
                    COALESCE(p.nombre, detalle.nombre_producto) AS nombre,
                    COALESCE(p.precio_venta_usd, 0) AS precioUnitarioUsd,
                    SUM(COALESCE(detalle.cantidad, 0) - COALESCE(detalle.cantidad_devuelta, 0)) AS unidades,
                    SUM(COALESCE(detalle.total_usd, 0)) AS ingresoTotal
                FROM ventas_detalles AS detalle
                LEFT JOIN productos AS p
                    ON p.id = detalle.producto_id
                WHERE detalle.creado_en BETWEEN ? AND ?
                GROUP BY detalle.producto_id, COALESCE(p.codigo_interno, detalle.codigo_producto), COALESCE(p.nombre, detalle.nombre_producto), COALESCE(p.precio_venta_usd, 0)
                ORDER BY unidades DESC, nombre ASC
                LIMIT 5
            `, [
                formatearFechaISO(fechaInicioSemana),
                formatearFechaISO(fechaFinSemana)
            ]);

            const estadoCaja = await obtenerEstadoCajaPrincipal();
            const cajasOperativas = Boolean(estadoCaja?.turnoActivo) ? 1 : 0;

            const tendenciaVentasDia = calcularCambioPorcentaje(
                Number(ventasDia?.[0]?.total_usd || 0),
                Number(ventasAyer?.[0]?.total_usd || 0)
            );

            const tendenciaClientesNuevos = calcularCambioPorcentaje(
                Number(clientesSemana?.[0]?.total || 0),
                Number(clientesSemanaAnterior?.[0]?.total || 0)
            );

            const resumen = {
                ventasDia: Number(ventasDia?.[0]?.total_usd || 0),
                transaccionesVenta: Number(ventasDia?.[0]?.transacciones || 0),
                stockCritico: Number(stockCritico?.[0]?.total || 0),
                cajasOperativas,
                cajaAbierta: cajasOperativas,
                clientesNuevos: Number(clientesSemana?.[0]?.total || 0),
                ventasSemana: ventasSemanaConPorcentaje,
                topProductosSemana: (topProductosSemanaRows || []).map((producto, indice) => ({
                    posicion: indice + 1,
                    productoId: producto.productoId,
                    sku: producto.sku || '',
                    nombre: producto.nombre || 'Producto',
                    unidades: Number(producto.unidades || 0),
                    ingresoTotal: Number(producto.ingresoTotal || 0),
                    precioUnitario: Number(producto.precioUnitarioUsd || 0)
                })),
                ultimasVentas: (ultimasVentas || []).map((venta) => ({
                    numeroFactura: venta.numeroFactura || venta.id,
                    clienteNombre: venta.clienteNombre || 'Cliente contado',
                    totalUsd: Number(venta.totalUsd || 0),
                    creadoEn: venta.creadoEn
                })),
                alertasProductos: (alertasProductos || []).map((producto) => ({
                    nombre: producto.nombre || 'Producto',
                    disponible: Number(producto.disponible || 0),
                    stockMinimo: Number(producto.stock_minimo || 0)
                })),
                tendencias: {
                    ventasDia: tendenciaVentasDia,
                    stockCritico: null,
                    cajasOperativas: null,
                    clientesNuevos: tendenciaClientesNuevos
                }
            };

            return res.status(200).json({
                ok: true,
                resumen
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error consultando el resumen del panel:'
            );
        }
    }
);

// Endpoint de debug: contar filas en ventas_detalles
app.get(
    '/api/debug/ventas-detalles-count',
    requerirSesion,
    permitirAccesoVentas,
    async (req, res) => {
        try {
            const [rows] = await db.execute(`SELECT COUNT(*) AS total FROM ventas_detalles`);
            const total = rows && rows[0] ? Number(rows[0].total || 0) : 0;
            return res.json({ ok: true, total });
        } catch (error) {
            return responderErrorControlado(res, error, 'Error contando ventas_detalles:');
        }
    }
);

/*
    Consulta una venta completa por ID.
*/
/*
    Lista historial de ventas usando clave de autorización.

    Esta ruta sirve para el POS:
    - Cajero puede solicitar historial.
    - Debe ingresar la clave del propietario.
    - Cada apertura del historial vuelve a pedir clave.
*/
app.post(
    '/api/ventas/historial-autorizado',
    requerirSesion,
    permitirAccesoVentas,
    async (req, res) => {
        try {
            await verificarClaveAutorizacion(
                req.body?.clave,
                req.usuario.id,
                'VER_HISTORIAL_VENTAS',
                'Apertura de historial de ventas desde Punto de Venta.'
            );

            const ventas =
                await listarVentas({
                    limite: req.body?.limite || 50
                });

            return res.json({
                ok: true,
                ventas
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error consultando historial autorizado de ventas:'
            );
        }
    }
);

/*
    Consulta detalle de factura usando clave de autorización.

    Se usará dentro del historial autorizado.
    La clave no se guarda en sesión; el frontend la mantiene
    solo mientras el modal esté abierto y la elimina al cerrar.
*/
app.post(
    '/api/ventas/detalle-autorizado',
    requerirSesion,
    permitirAccesoVentas,
    async (req, res) => {
        try {
            await verificarClaveAutorizacion(
                req.body?.clave,
                req.usuario.id,
                'VER_DETALLE_FACTURA',
                'Consulta de detalle de factura desde Punto de Venta.'
            );

            const ventaId =
                req.body?.ventaId ||
                req.body?.id;

            const numeroFactura =
                req.body?.numeroFactura;

            const venta = numeroFactura
                ? await obtenerVentaPorNumeroFactura(
                    numeroFactura
                )
                : await obtenerVentaPorId(
                    ventaId
                );

            return res.json({
                ok: true,
                venta
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error consultando detalle autorizado de venta:'
            );
        }
    }
);
app.get(
    '/api/ventas/:id',
    requerirSesion,
    permitirConsultaAdministrativaVentas,
    async (req, res) => {
        try {
            const venta =
                await obtenerVentaPorId(
                    req.params.id
                );

            return res.json({
                ok: true,
                venta
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error consultando venta:'
            );
        }
    }
);

/*
    Consulta una venta por número de factura.
    Ejemplo:
    /api/ventas/factura/FAC-000001
*/
app.get(
    '/api/ventas/factura/:numeroFactura',
    requerirSesion,
    permitirConsultaAdministrativaVentas,
    async (req, res) => {
        try {
            const venta =
                await obtenerVentaPorNumeroFactura(
                    req.params.numeroFactura
                );

            return res.json({
                ok: true,
                venta
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error consultando factura:'
            );
        }
    }
);
app.post(
    '/api/ventas/confirmar',
    requerirSesion,
    permitirAccesoVentas,
    async (req, res) => {
        try {
            const venta =
                await confirmarVenta(
                    req.body || {},
                    req.usuario.id
                );

            return res.status(201).json({
                ok: true,
                mensaje:
                    `Venta ${venta.numeroFactura} registrada correctamente.`,
                venta
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error confirmando venta:'
            );
        }
    }
);
app.get(
    '/api/caja/arqueos/:id',
    requerirSesion,
    permitirGestionCaja,
    async (req, res) => {
        try {
            const arqueo =
                await obtenerArqueoCajaPorId(
                    req.params.id
                );

            return res.json({
                ok: true,
                arqueo
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error consultando arqueo de Caja:'
            );
        }
    }
);

app.get(
    '/caja/arqueo/:id/imprimir',
    requerirSesion,
    permitirGestionCaja,
    (req, res) => {
        res.sendFile(
            path.join(
                __dirname,
                'public',
                'caja-arqueo-imprimir.html'
            )
        );
    }
);
/* =========================================================
   CAJA
   ========================================================= */

/*
    Por ahora Caja es una pantalla temporal para probar
    la redirección del rol CAJERO.

    Más adelante esta ruta tendrá:
    - cliente por cédula o RIF;
    - productos;
    - carrito;
    - pagos;
    - tasa aplicada;
    - apertura y cierre de caja.
*/
app.get(
    '/caja',
    requerirSesion,
    permitirGestionCaja,
    (_req, res) => {
        return res.sendFile(archivoCaja);
    }
);
/* =========================================================
   CAJA BÁSICA V1
   ========================================================= */

/*
    Estado de la Caja Principal.

    Devuelve:
    - datos de la caja;
    - turno abierto, si existe;
    - tasa vigente;
    - si se permite abrirla.
*/
app.get(
    '/api/caja/estado',
    requerirSesion,
    permitirGestionCaja,
    async (_req, res) => {
        try {
            const estadoCaja =
                await obtenerEstadoCajaPrincipal();

            return res.status(200).json({
                ok: true,
                ...estadoCaja
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error consultando el estado de Caja:'
            );
        }
    }
);
app.get(
    '/api/caja/arqueo',
    requerirSesion,
    permitirGestionCaja,
    async (_req, res) => {
        try {
            const arqueo =
                await obtenerResumenArqueoCajaPrincipal();

            return res.status(200).json({
                ok: true,
                arqueo
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error consultando arqueo de Caja:'
            );
        }
    }
);


app.post(
    '/api/caja/cuadrar',
    requerirSesion,
    permitirGestionCaja,
    async (req, res) => {
        try {
            // req.usuario viene del middleware requerirSesion
            const resultado = await finalizarArqueoCajaPrincipal(
                {
                    conteos: req.body.conteos,      // lo envía el frontend
                    ajustes: req.body.ajustes,      // ídem
                    notaFinal: req.body.notaFinal   // ídem
                },
                req.usuario.id
            );

            return res.status(201).json({
                success: true,
                mensaje: `Arqueo ${resultado.arqueo.numeroArqueo} generado correctamente. Puede abrir una nueva caja.`,
                arqueo: {
                    id: resultado.arqueo.id,
                    numeroArqueo: resultado.arqueo.numeroArqueo
                }
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error finalizando el arqueo de Caja:'
            );
        }
    }
);
// GET para abrir PDF de arqueo existente
app.get(
    '/api/caja/preview-pdf',
    requerirSesion,
    permitirGestionCaja,
    async (req, res) => {
        try {
            const arqueoId = req.query.arqueoId;
            if (!arqueoId) {
                return res.status(400).json({ error: 'Falta el ID del arqueo' });
            }

            // Obtener datos del arqueo guardado
            const arqueo = await obtenerArqueoCajaPorId(arqueoId);
            // --- Cálculo de devoluciones DV ---
            const metodosSistema = arqueo.sistema?.metodos || [];

            // Total de devoluciones en Bs (ya lo tienes, pero por claridad)
            const devolucionesRealizadasBs = Math.abs(Number(arqueo.resumen?.totalDevolucionesBs || 0));

            // Total de devoluciones en USD (sumando los equivalentes USD donde existan)
            const devolucionesRealizadasUsd = metodosSistema.reduce((total, metodo) => {
                return total + Math.abs(Number(metodo.devoluciones?.montoUsd || metodo.devoluciones?.montoOriginal || 0));
            }, 0);

            // Buscar el método DV
            const metodoDV = metodosSistema.find(m => m.codigo === 'DV') || {};

            // --- Detalle de devoluciones ---
            const detalleDevoluciones = [];
            for (const metodo of metodosSistema) {
                if (metodo.movimientos) {
                    for (const mov of metodo.movimientos) {
                        if (mov.tipo === 'DEVOLUCION') {
                            detalleDevoluciones.push({
                                factura: mov.documentoRelacionado || mov.documentoNumero || '—',
                                devolucion: mov.documentoNumero || '—',
                                metodoCodigo: mov.codigo || '—',
                                metodoNombre: mov.nombre || '—',
                                metodoMoneda: mov.moneda || '—',
                                turnoFacturaId: mov.turnoFacturaId || null,
                                montoBs: Math.abs(Number(mov.montoBs || 0)).toFixed(2),
                                montoUsd: Math.abs(Number(mov.montoUsd || 0)).toFixed(2)
                            });
                        }
                    }
                }
            }

            const esMetodoDV = (det = {}) => {
                const codigo = String(det.metodoCodigo || det.codigo || det.metodoNombre || '').toUpperCase();
                const moneda = String(det.metodoMoneda || det.moneda || '').toUpperCase();
                return codigo === 'DV' || codigo.includes('DV') || moneda === 'DV';
            };

            const dineroConsumidoBs = detalleDevoluciones.length > 0
                ? detalleDevoluciones.reduce((total, det) => {
                    return esMetodoDV(det) ? total + Number(det.montoBs || 0) : total;
                }, 0)
                : Math.abs(Number(metodoDV.devoluciones?.montoBs || 0));

            const dineroConsumidoUsd = detalleDevoluciones.length > 0
                ? detalleDevoluciones.reduce((total, det) => {
                    return esMetodoDV(det) ? total + Number(det.montoUsd || 0) : total;
                }, 0)
                : Math.abs(Number(metodoDV.devoluciones?.montoUsd || metodoDV.devoluciones?.montoOriginal || 0));

            // Diferencia devuelta al cliente
            const dineroDevueltoClienteBs = Math.max(0, devolucionesRealizadasBs - dineroConsumidoBs);
            const dineroDevueltoClienteUsd = Math.max(0, devolucionesRealizadasUsd - dineroConsumidoUsd);

            const negocio = await obtenerConfiguracionNegocio();

            // Construir datosParaPdf similar a como lo haces en el POST
            const metodosPago = (arqueo.sistema?.metodos || []).map(metodo => {
                const moneda = (metodo.moneda || 'VES').toUpperCase();
                const valorNeto = moneda === 'USD'
                    ? Number(metodo.neto?.montoOriginal || 0)
                    : Number(metodo.neto?.montoBs || 0);
                return {
                    nombre: metodo.nombre || metodo.codigo || 'Método',
                    moneda: moneda === 'USD' ? '$' : 'Bs.',
                    ventas: Number(metodo.ventas?.montoBs || metodo.ventas?.montoOriginal || 0),
                    devoluciones: Number(metodo.devoluciones?.montoBs || metodo.devoluciones?.montoOriginal || 0),
                    neto: valorNeto
                };
            });
            const datosParaPdf = {
                empresa: negocio?.nombreComercial || 'RYZE CORPORATION C.A.',
                rif: negocio?.rif || 'J-12345678-9',
                direccion: negocio?.direccion || 'Av. Principal, Edificio Central',
                turno: arqueo.numeroArqueo || `ARQ-${arqueo.id}`,
                fechaHora: new Date(arqueo.creadoEn).toLocaleString('es-VE'),
                cajero: arqueo.usuarioArqueo?.nombreCompleto || 'Cajero',
                supervisor: arqueo.usuarioCierre?.nombreCompleto || 'Supervisor',
                observaciones: arqueo.notaArqueo || 'Sin observaciones.',
                tasa: (() => {
                    const raw = arqueo.sistema?.turno?.tasa?.valorUsdVes;
                    const valor = Number(raw);
                    return Number.isFinite(valor) && valor > 0 ? valor.toFixed(2) : '0.00';
                })(),
                metodosPago,
                totalVentasBs: arqueo.resumen?.totalVentasBs || '0.00',
                totalDevolucionesBs: arqueo.resumen?.totalDevolucionesBs || '0.00',
                cantidadClientes: arqueo.resumen?.cantidadClientes || 0,
                cantidadDevoluciones: arqueo.resumen?.cantidadDevoluciones || 0,
                totalEfectivoEsperadoBs: arqueo.efectivo?.ves?.esperado || '0.00',
                totalEfectivoEsperadoUsd: arqueo.efectivo?.usd?.esperado || '0.00',
                totalEfectivoContadoBs: arqueo.efectivo?.ves?.contado || '0.00',
                totalEfectivoContadoUsd: arqueo.efectivo?.usd?.contado || '0.00',
                ajustes: arqueo.ajustes || [],
                conteos: arqueo.resumenJson?.conteosCliente || {},
                fondoInicialBs: arqueo.sistema?.efectivo?.ves?.apertura || '0.00',
                fondoInicialUsd: arqueo.sistema?.efectivo?.usd?.apertura || '0.00',
                netoOperativoBs: arqueo.resumen?.netoOperativoBs || '0.00',
                devolucionesBs: arqueo.resumen?.totalDevolucionesBs || '0.00',
                devolucionesUsd: '0.00',  // hasta que se pueda obtener del sistema
                devolucionesRealizadasBs: devolucionesRealizadasBs.toFixed(2),
                devolucionesRealizadasUsd: devolucionesRealizadasUsd.toFixed(2),
                detalleDevoluciones: detalleDevoluciones,
                dineroConsumidoBs: dineroConsumidoBs.toFixed(2),
                dineroConsumidoUsd: dineroConsumidoUsd.toFixed(2),
                dineroDevueltoClienteBs: dineroDevueltoClienteBs.toFixed(2),
                dineroDevueltoClienteUsd: dineroDevueltoClienteUsd.toFixed(2),
                consumosDevoluciones: arqueo.resumenJson?.consumosDevoluciones || {},
                turnoId: arqueo.turno?.id,
            };
            const pdfBuffer = await generarPdfArqueo(datosParaPdf);
            await guardarPdfArqueoEnDisco(pdfBuffer, {
                arqueoId: arqueo.id,
                turno: arqueo.numeroArqueo || `ARQ-${arqueo.id}`,
                fechaHora: arqueo.creadoEn || new Date()
            });
            res.setHeader('Content-Type', 'application/pdf');
            res.setHeader('Content-Disposition', `inline; filename="arqueo-${arqueo.numeroArqueo || arqueoId}.pdf"`);
            res.send(pdfBuffer);
        } catch (error) {
            console.error('Error generando PDF del arqueo:', error);
            res.status(500).json({ error: 'Error generando el documento' });
        }
    }
);
app.post(
    '/api/caja/preview-pdf',
    requerirSesion,
    permitirGestionCaja,
    async (req, res) => {
        try {

            const arqueo =
                await obtenerResumenArqueoCajaPrincipal();
            const metodos = arqueo.metodos || [];

            const devolucionesRealizadasBs = Math.abs(Number(arqueo.resumen?.totalDevolucionesBs || 0));
            const devolucionesRealizadasUsd = metodos.reduce((total, m) => total + Math.abs(Number(m.devoluciones?.montoUsd || m.devoluciones?.montoOriginal || 0)), 0);

            const metodoDV = metodos.find(m => m.codigo === 'DV') || {};

            const detalleDevoluciones = [];
            for (const metodo of metodos) {
                if (metodo.movimientos) {
                    for (const mov of metodo.movimientos) {
                        if (mov.tipo === 'DEVOLUCION') {
                            detalleDevoluciones.push({
                                factura: mov.documentoRelacionado || mov.documentoNumero || '—',
                                devolucion: mov.documentoNumero || '—',
                                metodoCodigo: mov.codigo || '—',
                                metodoNombre: mov.nombre || '—',
                                metodoMoneda: mov.moneda || '—',
                                turnoFacturaId: mov.turnoFacturaId || null,
                                montoBs: Math.abs(Number(mov.montoBs || 0)).toFixed(2),
                                montoUsd: Math.abs(Number(mov.montoUsd || 0)).toFixed(2)
                            });
                        }
                    }
                }
            }

            const esMetodoDV = (det = {}) => {
                const codigo = String(det.metodoCodigo || det.codigo || det.metodoNombre || '').toUpperCase();
                const moneda = String(det.metodoMoneda || det.moneda || '').toUpperCase();
                return codigo === 'DV' || codigo.includes('DV') || moneda === 'DV';
            };

            const dineroConsumidoBs = detalleDevoluciones.length > 0
                ? detalleDevoluciones.reduce((total, det) => {
                    return esMetodoDV(det) ? total + Number(det.montoBs || 0) : total;
                }, 0)
                : Math.abs(Number(metodoDV.devoluciones?.montoBs || 0));

            const dineroConsumidoUsd = detalleDevoluciones.length > 0
                ? detalleDevoluciones.reduce((total, det) => {
                    return esMetodoDV(det) ? total + Number(det.montoUsd || 0) : total;
                }, 0)
                : Math.abs(Number(metodoDV.devoluciones?.montoUsd || metodoDV.devoluciones?.montoOriginal || 0));

            const dineroDevueltoClienteBs = Math.max(0, devolucionesRealizadasBs - dineroConsumidoBs);
            const dineroDevueltoClienteUsd = Math.max(0, devolucionesRealizadasUsd - dineroConsumidoUsd);
            const negocio =
                await obtenerConfiguracionNegocio();

            const cajero =
                obtenerNombreUsuario(
                    arqueo.turno?.responsable ||
                    req.usuario || {}
                );

            const supervisor =
                obtenerNombreUsuario(
                    arqueo.turno?.usuarioCierre ||
                    req.usuario || {}
                );

            const metodosPago =
                (arqueo.metodos || []).map((metodo) => {
                    const moneda =
                        (metodo.moneda || 'VES').toUpperCase();

                    const valorNeto =
                        moneda === 'USD'
                            ? Number(metodo.neto?.montoOriginal || 0)
                            : Number(metodo.neto?.montoBs || 0);

                    return {
                        nombre: metodo.nombre || metodo.codigo || 'Método',
                        moneda:
                            moneda === 'USD' ? '$' : 'Bs.',
                        ventas: Number(metodo.ventas?.montoBs || metodo.ventas?.montoOriginal || 0),
                        devoluciones: Number(metodo.devoluciones?.montoBs || metodo.devoluciones?.montoOriginal || 0),
                        neto: valorNeto,
                        diferencia:
                            Number(metodo.neto?.montoBs || metodo.neto?.montoOriginal || 0) -
                            Number(metodo.ventas?.montoBs || metodo.ventas?.montoOriginal || 0) +
                            Number(metodo.devoluciones?.montoBs || metodo.devoluciones?.montoOriginal || 0)
                    };
                });
            const datosParaPdf = {
                empresa:
                    negocio?.nombreComercial ||
                    negocio?.nombre ||
                    'RYZE CORPORATION C.A.',
                rif:
                    negocio?.rif ||
                    negocio?.rif_negocio ||
                    'J-12345678-9',
                direccion:
                    negocio?.direccion ||
                    negocio?.direccionFiscal ||
                    'Av. Principal, Edificio Central',
                turno:
                    arqueo.turno?.id
                        ? `#Cuadre ${arqueo.turno.id}`
                        : '#Cuadre de prueba',
                fechaHora:
                    new Date().toLocaleString('es-VE'),
                cajero,
                supervisor,
                observaciones:
                    String(req.body.observaciones || 'Sin observaciones finales.'),
                tasa: (() => {
                    const raw =
                        arqueo.turno?.tasa?.valorUsdVes ||
                        arqueo.turno?.tasa?.baseUsdVes ||
                        arqueo.turno?.tasa?.tasaUsdVes ||
                        req.body.tasa ||
                        '';
                    const valor = Number(String(raw).replace(/[^0-9.-]+/g, ''));
                    return Number.isFinite(valor) && valor > 0 ? valor.toFixed(2) : '0.00';
                })(),
                totalVentasBs:
                    arqueo.resumen?.totalVentasBs || '0.00',
                totalDevolucionesBs:
                    arqueo.resumen?.totalDevolucionesBs || '0.00',
                netoOperativoBs:
                    arqueo.resumen?.netoOperativoBs || '0.00',
                cantidadClientes:
                    arqueo.resumen?.cantidadClientes || 0,
                cantidadDevoluciones:
                    arqueo.resumen?.cantidadDevoluciones || 0,
                totalEfectivoEsperadoBs:
                    arqueo.efectivo?.ves?.esperado || '0.00',
                totalEfectivoEsperadoUsd:
                    arqueo.efectivo?.usd?.esperado || '0.00',
                totalEfectivoContadoUsd: (() => {
                    const raw = String(req.body.contadoUsd || arqueo.efectivo?.usd?.contado || '0.00').trim();
                    let normalized = raw;

                    if (normalized.includes(',') && normalized.includes('.')) {
                        normalized = normalized.replace(/\./g, '').replace(/,/g, '.');
                    } else if (normalized.includes(',') && !normalized.includes('.')) {
                        normalized = normalized.replace(/,/g, '.');
                    }

                    const valor = Number(normalized.replace(/[^0-9.-]+/g, ''));
                    return Number.isFinite(valor) ? valor.toFixed(2) : '0.00';
                })(),
                totalEfectivoContadoBs: (() => {
                    const raw = String(req.body.contadoVes || arqueo.efectivo?.ves?.contado || '0.00').trim();
                    let normalized = raw;

                    if (normalized.includes(',') && normalized.includes('.')) {
                        normalized = normalized.replace(/\./g, '').replace(/,/g, '.');
                    } else if (normalized.includes(',') && !normalized.includes('.')) {
                        normalized = normalized.replace(/,/g, '.');
                    }

                    const valor = Number(normalized.replace(/[^0-9.-]+/g, ''));
                    return Number.isFinite(valor) ? valor.toFixed(2) : '0.00';
                })(),
                fondoInicialBs: req.body.fondoInicialBs || arqueo.efectivo?.ves?.apertura || '0.00',
                fondoInicialUsd: req.body.fondoInicialUsd || arqueo.efectivo?.usd?.apertura || '0.00',
                metodosPago,
                ajustes: Array.isArray(req.body.ajustes)
                    ? req.body.ajustes.filter((ajuste) => ajuste && ajuste.estado !== 'ANULADO')
                    : [],
                conteos: req.body.conteos && typeof req.body.conteos === 'object'
                    ? req.body.conteos
                    : {},
                devolucionesRealizadasBs: devolucionesRealizadasBs.toFixed(2),
                devolucionesRealizadasUsd: devolucionesRealizadasUsd.toFixed(2),
                dineroConsumidoBs: dineroConsumidoBs.toFixed(2),
                dineroConsumidoUsd: dineroConsumidoUsd.toFixed(2),
                dineroDevueltoClienteBs: dineroDevueltoClienteBs.toFixed(2),
                dineroDevueltoClienteUsd: dineroDevueltoClienteUsd.toFixed(2),
                detalleDevoluciones: detalleDevoluciones,
                consumosDevoluciones: req.body.consumosDevoluciones || {},
                turnoId: arqueo.turno?.id,   
            };

            const pdfBuffer = await generarPdfArqueo(datosParaPdf);
            await guardarPdfArqueoEnDisco(pdfBuffer, {
                arqueoId: arqueo?.id,
                turno: datosParaPdf.turno,
                fechaHora: datosParaPdf.fechaHora
            });

            res.setHeader('Content-Type', 'application/pdf');
            const filenameSafe = generarNombrePdfArqueo(datosParaPdf.turno, datosParaPdf.fechaHora);
            res.setHeader('Content-Disposition', `attachment; filename="${filenameSafe}.pdf"`);
            res.setHeader('Content-Length', pdfBuffer.length);

            return res.send(pdfBuffer);
        } catch (error) {
            console.error('Error generando preview del arqueo (POST) con Puppeteer:', error);
            return res.status(500).json({
                ok: false,
                mensaje: 'No fue posible generar la previsualización del PDF.'
            });
        }
    }
);

app.post(
    '/api/caja/abrir',
    requerirSesion,
    permitirGestionCaja,
    async (req, res) => {
        try {
            const turno = await abrirCajaPrincipal(
                req.body || {},
                req.usuario.id
            );

            return res.status(201).json({
                ok: true,
                mensaje:
                    'Caja Principal abierta correctamente.',
                turno
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error abriendo Caja:'
            );
        }
    }
);

app.post(
    '/api/caja/cerrar',
    requerirSesion,
    permitirGestionCaja,
    async (req, res) => {
        try {
            const turno = await cerrarCajaPrincipal(
                req.body || {},
                req.usuario.id
            );

            return res.status(200).json({
                ok: true,
                mensaje:
                    'Caja Principal cerrada correctamente.',
                turno
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error cerrando Caja:'
            );
        }
    }
);
/*
    La pantalla visual de Usuarios solo puede verla el
    PROPIETARIO.

    Desde aquí podrá crear y administrar Cajeros.
*/
app.get(
    '/usuarios',
    requerirSesion,
    permitirGestionUsuarios,
    (_req, res) => {
        return res.sendFile(archivoUsuarios);
    }
);
/* =========================================================
   USUARIOS
   ========================================================= */

/*
    Por ahora solamente PROPIETARIO puede administrar
    usuarios.

    Roles habilitados visualmente en esta fase:
    - PROPIETARIO
    - CAJERO
*/

/*
    Listado de propietario y cajeros.

    Ejemplo:
    /api/usuarios?busqueda=mar&estado=ACTIVO
*/
app.get(
    '/api/usuarios',
    requerirSesion,
    permitirGestionUsuarios,
    async (req, res) => {
        try {
            const usuarios = await listarUsuarios(
                {
                    busqueda:
                        req.query.busqueda || '',

                    estado:
                        req.query.estado || 'TODOS'
                },
                req.usuario.id
            );

            return res.status(200).json({
                ok: true,
                usuarios
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error listando usuarios:'
            );
        }
    }
);

/*
    Consulta los datos de un usuario específico.
*/
app.get(
    '/api/usuarios/:id',
    requerirSesion,
    permitirGestionUsuarios,
    async (req, res) => {
        try {
            const usuario =
                await obtenerUsuarioPorId(
                    req.params.id,
                    req.usuario.id
                );

            return res.status(200).json({
                ok: true,
                usuario
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error consultando usuario:'
            );
        }
    }
);

/*
    Crear cajero.

    Body esperado:

    {
        nombreCompleto,
        usuario,
        correo,
        contrasena,
        confirmarContrasena
    }
*/
app.post(
    '/api/usuarios/cajeros',
    requerirSesion,
    permitirGestionUsuarios,
    async (req, res) => {
        try {
            const cajero = await crearCajero(
                req.body || {},
                req.usuario.id
            );

            return res.status(201).json({
                ok: true,
                mensaje:
                    'Cajero creado correctamente.',
                usuario: cajero
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error creando cajero:'
            );
        }
    }
);

/*
    Editar datos generales de un cajero.

    No permite modificar rol, estado ni contraseña.
*/
app.put(
    '/api/usuarios/:id',
    requerirSesion,
    permitirGestionUsuarios,
    async (req, res) => {
        try {
            const cajero = await actualizarCajero(
                req.params.id,
                req.body || {},
                req.usuario.id
            );

            return res.status(200).json({
                ok: true,
                mensaje:
                    'Datos del cajero actualizados correctamente.',
                usuario: cajero
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error actualizando cajero:'
            );
        }
    }
);

/*
    Restablecer contraseña de un cajero.

    Todas sus sesiones actuales se cerrarán automáticamente.
*/
app.patch(
    '/api/usuarios/:id/contrasena',
    requerirSesion,
    permitirGestionUsuarios,
    async (req, res) => {
        try {
            const cajero =
                await restablecerContrasenaCajero(
                    req.params.id,
                    req.body || {},
                    req.usuario.id
                );

            return res.status(200).json({
                ok: true,
                mensaje:
                    'Contraseña restablecida y sesiones cerradas correctamente.',
                usuario: cajero
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error restableciendo contraseña:'
            );
        }
    }
);

/*
    Bloquear cajero.

    Se cierran todas sus sesiones abiertas de inmediato.
*/
app.patch(
    '/api/usuarios/:id/bloqueo',
    requerirSesion,
    permitirGestionUsuarios,
    async (req, res) => {
        try {
            const cajero = await bloquearCajero(
                req.params.id,
                req.body?.motivoBloqueo,
                req.usuario.id
            );

            return res.status(200).json({
                ok: true,
                mensaje:
                    'Cajero bloqueado y sesiones cerradas correctamente.',
                usuario: cajero
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error bloqueando cajero:'
            );
        }
    }
);

/*
    Reactivar cajero.

    No se abre una sesión automática: el cajero debe
    ingresar otra vez con sus credenciales.
*/
app.patch(
    '/api/usuarios/:id/reactivacion',
    requerirSesion,
    permitirGestionUsuarios,
    async (req, res) => {
        try {
            const cajero = await reactivarCajero(
                req.params.id,
                req.usuario.id
            );

            return res.status(200).json({
                ok: true,
                mensaje:
                    'Cajero reactivado correctamente.',
                usuario: cajero
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error reactivando cajero:'
            );
        }
    }
);
/* =========================================================
   CLIENTES
   ========================================================= */

/*
    Todas estas rutas requieren:

    - Licencia activa.
    - Negocio configurado.
    - Sesión válida.
    - Rol PROPIETARIO, ADMINISTRADOR o CAJERO.
*/

/*
    La vista visual se creará después.
*/
app.get(
    '/clientes',
    requerirSesion,
    permitirGestionAdministrativaClientes,
    (_req, res) => {
        return res.sendFile(
            path.join(
                carpetaPublica,
                'clientes.html'
            )
        );
    }
);

/*
    Listado administrativo de clientes.

    Ejemplo:
    /api/clientes?busqueda=jose&estado=ACTIVO&pagina=1
*/
app.get(
    '/api/clientes',
    requerirSesion,
    permitirGestionAdministrativaClientes,
    async (req, res) => {
        try {
            const resultado =
                await listarClientes({
                    busqueda:
                        req.query.busqueda || '',

                    estado:
                        req.query.estado || 'ACTIVO',

                    pagina:
                        req.query.pagina || 1,

                    limite:
                        req.query.limite || 20,

                    soloSemana:
                        req.query.soloSemana === 'true' ||
                        req.query.soloSemana === '1' ||
                        req.query.soloSemana === 'yes'
                });

            return res.status(200).json({
                ok: true,
                ...resultado
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error listando clientes:'
            );
        }
    }
);

/*
    Búsqueda rápida para la futura Caja.

    Ejemplo:
    /api/clientes/busqueda-rapida?q=V-12345678

    Si existe una coincidencia exacta por cédula o RIF,
    devuelve:

    coincidenciaExacta: true
*/
app.get(
    '/api/clientes/busqueda-rapida',
    requerirSesion,
    permitirAccesoVentas,
    async (req, res) => {
        try {
            const resultado =
                await buscarClientesRapido(
                    req.query.q || '',
                    {
                        limite:
                            req.query.limite || 8
                    }
                );

            return res.status(200).json({
                ok: true,
                ...resultado
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error realizando búsqueda rápida de clientes:'
            );
        }
    }
);
/* =========================================================
   REGISTRO RÁPIDO DE CLIENTE DESDE VENTAS
   ========================================================= */

/*
    Esta ruta permite que Propietario o Cajero registren
    un cliente desde el Punto de Venta.

    No entrega acceso al módulo administrativo /clientes.
    Solo crea el cliente mínimo necesario para la venta.
*/
app.post(
    '/api/ventas/clientes-rapido',
    requerirSesion,
    permitirAccesoVentas,
    async (req, res) => {
        try {
            const datosEntrada =
                req.body || {};

            /*
                Enviamos las propiedades principales que usa
                el servicio de Clientes. También conservamos
                nombres alternativos por compatibilidad.
            */
            const datosCliente = {
                tipoPersona:
                    datosEntrada.tipoPersona ||
                    datosEntrada.tipo_persona ||
                    'NATURAL',

                tipo_persona:
                    datosEntrada.tipoPersona ||
                    datosEntrada.tipo_persona ||
                    'NATURAL',
                nombreORazonSocial:
                    datosEntrada.nombreCompleto ||
                    datosEntrada.nombreORazonSocial ||
                    datosEntrada.nombreOrazonSocial ||
                    datosEntrada.nombre_completo ||
                    datosEntrada.nombre ||
                    '',
                nombreCompleto:
                    datosEntrada.nombreCompleto ||
                    datosEntrada.nombre_completo ||
                    datosEntrada.nombre ||
                    '',

                nombre_completo:
                    datosEntrada.nombreCompleto ||
                    datosEntrada.nombre_completo ||
                    datosEntrada.nombre ||
                    '',
                nombreOrazonSocial:
                    datosEntrada.nombreCompleto ||
                    datosEntrada.nombreORazonSocial ||
                    datosEntrada.nombreOrazonSocial ||
                    datosEntrada.nombre_completo ||
                    datosEntrada.nombre ||
                    '',

                nombre_o_razon_social:
                    datosEntrada.nombreCompleto ||
                    datosEntrada.nombreORazonSocial ||
                    datosEntrada.nombreOrazonSocial ||
                    datosEntrada.nombre_completo ||
                    datosEntrada.nombre ||
                    '',
                nombre:
                    datosEntrada.nombreCompleto ||
                    datosEntrada.nombre_completo ||
                    datosEntrada.nombre ||
                    '',

                identificacion:
                    datosEntrada.identificacion ||
                    datosEntrada.identificacionFiscal ||
                    datosEntrada.identificacion_fiscal ||
                    '',

                identificacionFiscal:
                    datosEntrada.identificacion ||
                    datosEntrada.identificacionFiscal ||
                    datosEntrada.identificacion_fiscal ||
                    '',

                identificacion_fiscal:
                    datosEntrada.identificacion ||
                    datosEntrada.identificacionFiscal ||
                    datosEntrada.identificacion_fiscal ||
                    '',

                telefono:
                    datosEntrada.telefono || '',

                correo:
                    datosEntrada.correo || '',

                direccion:
                    datosEntrada.direccion ||
                    datosEntrada.direccionFiscal ||
                    datosEntrada.direccion_fiscal ||
                    '',

                notas: '',

                notasInternas: '',

                notas_internas: ''
            };

            const cliente = await crearCliente(
                datosCliente,
                req.usuario.id
            );

            return res.status(201).json({
                ok: true,
                mensaje:
                    'Cliente registrado y seleccionado correctamente.',
                cliente
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error registrando cliente rápido desde Ventas:'
            );
        }
    }
);
/* =========================================================
   PERFIL DE CLIENTE DESDE PUNTO DE VENTA
   ========================================================= */

/*
    Permite que Propietario o Cajero consulten los datos
    completos del cliente seleccionado dentro de Ventas.

    No concede acceso al módulo administrativo de Clientes.
*/
app.get(
    '/api/ventas/clientes/:id',
    requerirSesion,
    permitirAccesoVentas,
    async (req, res) => {
        try {
            const cliente = await obtenerClientePorId(
                req.params.id
            );

            if (!cliente) {
                return res.status(404).json({
                    ok: false,
                    codigo: 'CLIENTE_NO_ENCONTRADO',
                    mensaje:
                        'El cliente indicado no existe.'
                });
            }

            return res.status(200).json({
                ok: true,
                cliente
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error consultando cliente desde Punto de Venta:'
            );
        }
    }
);

/* =========================================================
   ACTUALIZACIÓN RÁPIDA DE CLIENTE DESDE VENTAS
   ========================================================= */

/*
    El cajero puede actualizar solamente:
    - nombre o razón social;
    - dirección;
    - teléfono;
    - correo.

    Por seguridad no puede cambiar:
    - identificación;
    - tipo de persona;
    - estado.
*/
app.put(
    '/api/ventas/clientes/:id',
    requerirSesion,
    permitirAccesoVentas,
    async (req, res) => {
        try {
            const clienteActual =
                await obtenerClientePorId(
                    req.params.id
                );

            if (!clienteActual) {
                return res.status(404).json({
                    ok: false,
                    codigo: 'CLIENTE_NO_ENCONTRADO',
                    mensaje:
                        'El cliente indicado no existe.'
                });
            }

            const datosEntrada =
                req.body || {};

            const tipoPersona =
                clienteActual.tipo_persona ||
                clienteActual.tipoPersona ||
                'NATURAL';

            const identificacion =
                clienteActual.identificacion ||
                clienteActual.identificacion_fiscal ||
                clienteActual.identificacionFiscal ||
                '';

            const nombreCompleto =
                datosEntrada.nombreCompleto ||
                datosEntrada.nombre_completo ||
                datosEntrada.nombre_o_razon_social ||
                datosEntrada.nombre ||
                '';

            const direccion =
                datosEntrada.direccion ||
                datosEntrada.direccion_fiscal ||
                datosEntrada.direccionFiscal ||
                '';

            const telefono =
                datosEntrada.telefono || '';

            const correo =
                datosEntrada.correo || '';

            const datosCliente = {
                /*
                    Se conservan los datos protegidos.
                */
                tipoPersona,
                tipo_persona: tipoPersona,

                identificacion,
                identificacionFiscal: identificacion,
                identificacion_fiscal: identificacion,

                /*
                    Datos que sí puede actualizar el cajero.
                */
                nombreORazonSocial: nombreCompleto,

                nombreOrazonSocial: nombreCompleto,

                nombreCompleto,

                nombre_completo: nombreCompleto,

                nombre_o_razon_social: nombreCompleto,

                direccion,
                direccionFiscal: direccion,
                direccion_fiscal: direccion,

                telefono,
                correo,

                notas: '',
                notasInternas: '',
                notas_internas: ''
            };

            const cliente =
                await actualizarCliente(
                    req.params.id,
                    datosCliente,
                    req.usuario.id
                );

            return res.status(200).json({
                ok: true,
                mensaje:
                    'Datos del cliente actualizados correctamente.',
                cliente
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error actualizando cliente desde Punto de Venta:'
            );
        }
    }
);
/*
    Consulta un cliente específico.
*/
app.get(
    '/api/clientes/:id',
    requerirSesion,
    permitirGestionAdministrativaClientes,
    async (req, res) => {
        try {
            const cliente =
                await obtenerClientePorId(
                    req.params.id
                );

            if (!cliente) {
                return res.status(404).json({
                    ok: false,
                    codigo: 'CLIENTE_NO_ENCONTRADO',
                    mensaje:
                        'El cliente indicado no existe.'
                });
            }

            return res.status(200).json({
                ok: true,
                cliente
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error consultando cliente:'
            );
        }
    }
);

/*
    Crear cliente.

    req.usuario.id viene de requerirSesion.
    Ese usuario queda guardado como creador y editor inicial.
*/
app.post(
    '/api/clientes',
    requerirSesion,
    permitirGestionAdministrativaClientes,
    async (req, res) => {
        try {
            const cliente =
                await crearCliente(
                    req.body || {},
                    req.usuario.id
                );

            return res.status(201).json({
                ok: true,
                mensaje:
                    'Cliente registrado correctamente.',
                cliente
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error creando cliente:'
            );
        }
    }
);

/*
    Editar cliente existente.
*/
app.put(
    '/api/clientes/:id',
    requerirSesion,
    permitirGestionAdministrativaClientes,
    async (req, res) => {
        try {
            const cliente =
                await actualizarCliente(
                    req.params.id,
                    req.body || {},
                    req.usuario.id
                );

            return res.status(200).json({
                ok: true,
                mensaje:
                    'Cliente actualizado correctamente.',
                cliente
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error actualizando cliente:'
            );
        }
    }
);

/*
    Inactivar o reactivar sin borrar historial.
*/
app.patch(
    '/api/clientes/:id/estado',
    requerirSesion,
    permitirGestionAdministrativaClientes,
    async (req, res) => {
        try {
            const cliente =
                await cambiarEstadoCliente(
                    req.params.id,
                    req.body?.estado,
                    req.usuario.id
                );

            return res.status(200).json({
                ok: true,
                mensaje:
                    cliente.estado === 'ACTIVO'
                        ? 'Cliente reactivado correctamente.'
                        : 'Cliente inactivado correctamente.',
                cliente
            });
        } catch (error) {
            return responderErrorControlado(
                res,
                error,
                'Error cambiando estado del cliente:'
            );
        }
    }
);
/*
    Ruta de diagnóstico protegida.
*/
app.get('/api/sistema/estado', (_req, res) => {
    return res.status(200).json({
        ok: true,
        aplicacion: APP_NAME,
        entorno:
            process.env.NODE_ENV || 'development',
        servidor: 'activo',
        migraciones: {
            habilitadas:
                estadoMigraciones.habilitado,
            total: estadoMigraciones.total,
            aplicadasAhora:
                estadoMigraciones.aplicadasAhora
        }
    });
});

app.get(
    '/api/sistema/actualizacion',
    requerirSesion,
    permitirConfiguracionFinanciera,
    async (_req, res) => {
        try {
            const estado =
                await obtenerEstadoActualizacion();

            return res.status(200).json({
                ok: true,
                estado
            });
        } catch (error) {
            console.error(
                'Error consultando actualización:',
                error.message
            );

            return res.status(500).json({
                ok: false,
                mensaje:
                    'No fue posible consultar el estado de actualización.'
            });
        }
    }
);

app.post(
    '/api/sistema/actualizacion/buscar',
    requerirSesion,
    permitirConfiguracionFinanciera,
    async (_req, res) => {
        try {
            const estado =
                await buscarActualizacion();

            return res.status(200).json({
                ok: true,
                estado
            });
        } catch (error) {
            console.error(
                'Error buscando actualización:',
                error.message
            );

            return res.status(500).json({
                ok: false,
                mensaje:
                    'No fue posible buscar actualizaciones.'
            });
        }
    }
);

app.post(
    '/api/sistema/actualizacion/aplicar',
    requerirSesion,
    permitirConfiguracionFinanciera,
    async (_req, res) => {
        try {
                // Iniciar la actualización en background y responder inmediatamente
                aplicarActualizacion()
                    .then((estado) => {
                        console.log('[Actualización] finalizada');
                    })
                    .catch((err) => {
                        console.error('[Actualización] error:', err.message);
                    });

                return res.status(202).json({
                    ok: true,
                    mensaje: 'Actualización iniciada'
                });
            } catch (error) {
            console.error(
                'Error aplicando actualización:',
                error.message
            );

            return res.status(500).json({
                ok: false,
                mensaje:
                    'No fue posible aplicar la actualización.'
            });
        }
    }
);

/*
    Archivos visibles:
    CSS, JavaScript, imágenes y favicon.

    El middleware de licencia debe permitir /assets/ y
    /favicon.ico cuando la licencia esté vencida, para que
    /activacion pueda mostrarse correctamente.
*/
app.use(express.static(carpetaPublica, {
    maxAge: 0
}));

app.use((req, res) => {
    if (req.path.startsWith('/api/')) {
        return res.status(404).json({
            ok: false,
            mensaje: 'Ruta de API no encontrada.'
        });
    }

    return res.status(404).send(
        'Página no encontrada.'
    );
});

/* =========================================================
   INICIO Y CIERRE
   ========================================================= */

async function iniciarServidor() {
    try {
        const estadoBaseDeDatos =
            await verificarConexionBaseDeDatos();

        estadoMigraciones =
            await aplicarMigraciones();

        const estadoIdentidadInicio =
            await asegurarIdentidadInstalacion();

        const estadoHistorialInicio =
            await asegurarHistorialLicenciasPersistente();

        const estadoRespaldoLicenciaInicio =
            await asegurarRespaldoLicenciaFirmada();

        /*
            En cada arranque de runtime, invalidamos el contexto de sesión que pueda
            quedar vivo en la base de datos. Esto evita que el navegador, al reabrirse
            con cookies de sesión que siguen en el almacenamiento, pueda reutilizar
            una sesión del servidor anterior.
        */
        const sesionesCerradasAlArrancar =
            await cerrarSesionesAbiertas();

        /*
            Limpieza silenciosa de sesiones ya vencidas.
        */
        const sesionesCerradas =
            await cerrarSesionesVencidas();

        await actualizarUltimoInicio();

        const estadoLicenciaInicio =
            await validarLicenciaLocal();

        console.log(
            '--------------------------------------------'
        );

        console.log(
            `${APP_NAME} iniciado correctamente`
        );

        console.log(
            `Entorno: ${process.env.NODE_ENV || 'development'}`
        );

        console.log(
            `Base de datos: ${estadoBaseDeDatos.base_de_datos}`
        );

        console.log(
            `Motor MySQL: ${estadoBaseDeDatos.version_mysql}`
        );

        console.log(
            `Migraciones: ${estadoMigraciones.aplicadasAhora.length} aplicadas ahora / ${estadoMigraciones.total} disponibles`
        );

        console.log(
            `Identidad: ${estadoIdentidadInicio.estado} · ${estadoIdentidadInicio.mensaje}`
        );

        console.log(
            `Historial: ${estadoHistorialInicio.estado} · ${estadoHistorialInicio.mensaje}`
        );

        console.log(
            `Respaldo licencia: ${estadoRespaldoLicenciaInicio.estado} · ${estadoRespaldoLicenciaInicio.mensaje}`
        );

        if (sesionesCerradas > 0) {
            console.log(
                `Sesiones: ${sesionesCerradas} vencida(s) cerrada(s).`
            );
        }

        if (estadoLicenciaInicio.reloj) {
            console.log(
                `Reloj: ${estadoLicenciaInicio.reloj.estado} · ${estadoLicenciaInicio.reloj.mensaje}`
            );
        }

        console.log(
            `Licencia: ${estadoLicenciaInicio.licencia.estado} · ${estadoLicenciaInicio.permiteAcceso
                ? 'acceso permitido'
                : 'acceso bloqueado'
            }`
        );

        await iniciarRevisionAutomaticaActualizaciones();

        console.log(
            `Local: http://localhost:${APP_PORT}`
        );

        console.log(
            `Red local: http://IP-DEL-SERVIDOR:${APP_PORT}`
        );

        console.log(
            '--------------------------------------------'
        );

        const servidorWeb = app.listen(APP_PORT, APP_HOST, () => {
            console.log(
                'Servidor web listo para recibir conexiones.'
            );
        });

        process.__TENVIK_HTTP_SERVER = servidorWeb;
    } catch (error) {
        console.error(
            '--------------------------------------------'
        );

        console.error(
            'No fue posible iniciar Tenvik.'
        );

        console.error(error.message);

        console.error(
            '--------------------------------------------'
        );

        process.exit(1);
    }
}

async function cerrarAplicacion() {
    try {
        console.log('\nCerrando Tenvik...');

        await cerrarConexionesBaseDeDatos();

        process.exit(0);
    } catch (error) {
        console.error(
            'Error al cerrar conexiones:',
            error.message
        );

        process.exit(1);
    }
}

process.on('SIGINT', cerrarAplicacion);
process.on('SIGTERM', cerrarAplicacion);

iniciarServidor();